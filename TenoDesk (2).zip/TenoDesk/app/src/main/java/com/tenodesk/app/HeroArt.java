package com.tenodesk.app;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.PathInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Builds the floating card pictures for the intro slides, using the app's own look. */
final class HeroArt {
    private HeroArt() {}

    static FrameLayout build(Context c, int index) {
        FrameLayout hero = new FrameLayout(c);
        hero.setClipChildren(false);
        switch (index) {
            case 0:
                rooms(c, hero);
                break;
            case 1:
                status(c, hero);
                break;
            case 2:
                bills(c, hero);
                break;
            default:
                reminders(c, hero);
                break;
        }
        return hero;
    }

    /**
     * The cards float up from below and settle gently, back layer first.
     * Call it once, before the first frame is drawn, so nothing flashes.
     */
    static void enter(ViewGroup root) {
        Context c = root.getContext();
        if (Motion.isReduced(c)) return;

        PathInterpolator ease = new PathInterpolator(0.2f, 0.9f, 0.25f, 1f);
        for (int i = 0; i < root.getChildCount(); i++) {
            View layerView = root.getChildAt(i);
            if (!(layerView instanceof ViewGroup)) continue;
            ViewGroup layer = (ViewGroup) layerView;
            long delay = 180L + i * 160L;

            for (int k = 0; k < layer.getChildCount(); k++) {
                View card = layer.getChildAt(k);
                float baseY = card.getTranslationY();
                float baseAlpha = card.getAlpha();

                card.setTranslationY(baseY + dp(c, 120 + 40 * i));
                card.setAlpha(0f);

                card.animate().translationY(baseY)
                        .setStartDelay(delay).setDuration(1100)
                        .setInterpolator(ease).start();

                ObjectAnimator fade = ObjectAnimator.ofFloat(card, View.ALPHA, 0f, baseAlpha);
                fade.setStartDelay(delay);
                fade.setDuration(700);
                fade.start();
            }
        }
    }

    // ------------------------------------------------------------------ slide 1

    private static void rooms(Context c, FrameLayout hero) {
        FrameLayout back = layer(c, hero, 0.12f);
        LinearLayout other = card(c, R.drawable.bg_card, 16);
        add(other, text(c, "Single room 2", 16, R.color.td_text_primary, true), 0, 0);
        add(other, text(c, "UGX 120,000 / month", 13, R.color.td_text_secondary, false), 2, 0);
        put(back, other, 240, 0, Gravity.CENTER, 0, -112, -3f, 0.5f);

        FrameLayout mid = layer(c, hero, 0.28f);
        LinearLayout main = card(c, R.drawable.bg_card_frost, 18);
        add(main, row(c, stack(c, "Single room 1", 17, "Grace Nabirye"),
                badge(c, "Paid", R.color.td_paid, R.drawable.bg_badge_paid)), 0, 0);
        add(main, bar(c, 62, c.getColor(R.color.td_paid)), 16, 6);
        add(main, row(c, text(c, "Joined 1 Oct  \u00B7  Day 19", 12, R.color.td_text_secondary, false),
                text(c, "Renews 1 Nov", 12, R.color.td_text_secondary, false)), 8, 0);
        put(mid, main, 270, 0, Gravity.CENTER, 0, -6, 0f, 1f);

        FrameLayout front = layer(c, hero, 0.5f);
        TextView chip = text(c, "UGX 1.8M collected", 14, R.color.td_on_accent, true);
        chip.setBackgroundResource(R.drawable.bg_card_gold);
        chip.setPadding(dp(c, 18), dp(c, 12), dp(c, 18), dp(c, 12));
        put(front, chip, 0, 0, Gravity.CENTER, 0, 100, -2f, 1f);
    }

    // ------------------------------------------------------------------ slide 2

    private static void status(Context c, FrameLayout hero) {
        FrameLayout back = layer(c, hero, 0.12f);
        LinearLayout paid = card(c, R.drawable.bg_card, 16);
        add(paid, row(c, stack(c, "River Dale", 16, "Single 4"),
                badge(c, "Paid", R.color.td_paid, R.drawable.bg_badge_paid)), 0, 0);
        put(back, paid, 250, 0, Gravity.CENTER, 0, 100, 0f, 0.5f);

        FrameLayout mid = layer(c, hero, 0.28f);
        LinearLayout urgent = card(c, R.drawable.bg_card_urgent, 16);
        LinearLayout head = new LinearLayout(c);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView mark = text(c, "!", 13, R.color.td_on_accent, true);
        mark.setGravity(Gravity.CENTER);
        mark.setBackgroundResource(R.drawable.bg_exclaim_urgent);
        head.addView(mark, new LinearLayout.LayoutParams(dp(c, 24), dp(c, 24)));
        LinearLayout.LayoutParams names = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        names.setMarginStart(dp(c, 12));
        names.setMarginEnd(dp(c, 8));
        head.addView(stack(c, "Sarah Kirabo", 16, "Single 6"), names);
        head.addView(badge(c, "Due tomorrow", R.color.td_overdue, R.drawable.bg_badge_overdue));
        add(urgent, head, 0, 0);
        add(urgent, bar(c, 96, c.getColor(R.color.td_overdue)), 16, 6);
        add(urgent, row(c, text(c, "Joined 10 Sep  \u00B7  Day 30", 12, R.color.td_text_secondary, false),
                text(c, "Due 10 Oct", 12, R.color.td_text_secondary, false)), 8, 0);
        put(mid, urgent, 270, 0, Gravity.CENTER, 0, -4, 0f, 1f);

        FrameLayout front = layer(c, hero, 0.5f);
        put(front, notif(c, "Rent reminder", "2 tenants need your attention", R.drawable.bg_card_frost),
                260, 0, Gravity.CENTER, 0, -124, 0f, 1f);
    }

    // ------------------------------------------------------------------ slide 3

    private static void bills(Context c, FrameLayout hero) {
        FrameLayout back = layer(c, hero, 0.12f);
        LinearLayout shares = card(c, R.drawable.bg_card, 14);
        add(shares, shareRow(c, "GN", "Grace", "UGX 18,000"), 0, 0);
        add(shares, shareRow(c, "PO", "Peter", "UGX 18,000"), 10, 0);
        add(shares, shareRow(c, "SK", "Sarah", "UGX 18,000"), 10, 0);
        put(back, shares, 240, 0, Gravity.CENTER, 0, 96, 0f, 0.6f);

        FrameLayout mid = layer(c, hero, 0.28f);
        LinearLayout bill = card(c, R.drawable.bg_card_frost, 18);
        add(bill, row(c, stack(c, "Water bill", 17, "5 tenants"),
                text(c, "UGX 90,000", 16, R.color.td_text_primary, true)), 0, 0);
        TextView each = text(c, "UGX 18,000 each", 14, R.color.td_on_accent, true);
        each.setGravity(Gravity.CENTER);
        each.setBackgroundResource(R.drawable.bg_pill_button);
        each.setPadding(dp(c, 18), dp(c, 12), dp(c, 18), dp(c, 12));
        add(bill, each, 16, 0);
        put(mid, bill, 270, 0, Gravity.CENTER, 0, -58, 0f, 1f);

        FrameLayout front = layer(c, hero, 0.5f);
        TextView divide = text(c, "\u00F75", 16, R.color.td_on_accent, true);
        divide.setGravity(Gravity.CENTER);
        divide.setBackgroundResource(R.drawable.bg_avatar);
        put(front, divide, 52, 52, Gravity.CENTER, 0, -142, 0f, 1f);
    }

    // ------------------------------------------------------------------ slide 4

    private static void reminders(Context c, FrameLayout hero) {
        FrameLayout back = layer(c, hero, 0.12f);
        put(back, notif(c, "Last week of the month", "Time to collect rent. 3 are due soon.",
                R.drawable.bg_card), 250, 0, Gravity.CENTER, 0, -112, 0f, 0.5f);

        FrameLayout mid = layer(c, hero, 0.28f);
        put(mid, notif(c, "Rent reminder", "Peter's rent is due in 3 days",
                R.drawable.bg_card_frost), 270, 0, Gravity.CENTER, 0, 0, 0f, 1f);

        FrameLayout front = layer(c, hero, 0.5f);
        put(front, notif(c, "Rent reminder", "Sarah is overdue by 2 days",
                R.drawable.bg_card_frost), 270, 0, Gravity.CENTER, 0, 112, 0f, 1f);
    }

    // ------------------------------------------------------------------ pieces

    private static LinearLayout notif(Context c, String title, String body, int bgRes) {
        LinearLayout card = card(c, bgRes, 14);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);

        TextView icon = text(c, "T", 15, R.color.td_on_accent, true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackgroundResource(R.drawable.bg_avatar);
        card.addView(icon, new LinearLayout.LayoutParams(dp(c, 38), dp(c, 38)));

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(text(c, "TenoDesk  \u00B7  now", 11, R.color.td_text_secondary, false));
        add(col, text(c, title, 14, R.color.td_text_primary, true), 2, 0);
        add(col, text(c, body, 13, R.color.td_text_secondary, false), 2, 0);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMarginStart(dp(c, 12));
        card.addView(col, lp);
        return card;
    }

    private static View shareRow(Context c, String initials, String name, String amount) {
        LinearLayout r = new LinearLayout(c);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);

        TextView circle = text(c, initials, 11, R.color.td_on_accent, true);
        circle.setGravity(Gravity.CENTER);
        circle.setBackgroundResource(R.drawable.bg_avatar);
        r.addView(circle, new LinearLayout.LayoutParams(dp(c, 30), dp(c, 30)));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMarginStart(dp(c, 10));
        r.addView(text(c, name, 14, R.color.td_text_primary, true), lp);
        r.addView(text(c, amount, 13, R.color.td_text_secondary, false));
        return r;
    }

    private static LinearLayout stack(Context c, String title, int titleSp, String sub) {
        LinearLayout v = new LinearLayout(c);
        v.setOrientation(LinearLayout.VERTICAL);
        v.addView(text(c, title, titleSp, R.color.td_text_primary, true));
        add(v, text(c, sub, 13, R.color.td_text_secondary, false), 2, 0);
        return v;
    }

    private static LinearLayout row(Context c, View left, View right) {
        LinearLayout r = new LinearLayout(c);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (right != null) {
            r.addView(right, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        return r;
    }

    private static View bar(Context c, int percent, int color) {
        LinearLayout track = new LinearLayout(c);
        track.setBackground(round(c, c.getColor(R.color.td_surface_alt), 6));
        View fill = new View(c);
        fill.setBackground(round(c, color, 6));
        track.addView(fill, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.MATCH_PARENT, percent));
        track.addView(new View(c), new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.MATCH_PARENT, 100 - percent));
        return track;
    }

    private static TextView badge(Context c, String text, int colorRes, int bgRes) {
        TextView t = text(c, text, 12, colorRes, true);
        t.setBackgroundResource(bgRes);
        t.setPadding(dp(c, 12), dp(c, 5), dp(c, 12), dp(c, 5));
        return t;
    }

    private static LinearLayout card(Context c, int bgRes, int padDp) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackgroundResource(bgRes);
        int p = dp(c, padDp);
        l.setPadding(p, p, p, p);
        return l;
    }

    private static TextView text(Context c, String s, int sp, int colorRes, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(c.getColor(colorRes));
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private static GradientDrawable round(Context c, int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(c, radiusDp));
        return d;
    }

    /** One full-size layer. Each layer moves at its own speed while swiping (the depth tag). */
    private static FrameLayout layer(Context c, FrameLayout hero, float depth) {
        FrameLayout l = new FrameLayout(c);
        l.setClipChildren(false);
        l.setTag(Float.valueOf(depth));
        if (depth <= 0.15f && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // phones with Android 12 or newer can blur the cards at the back
            l.setRenderEffect(RenderEffect.createBlurEffect(5f, 5f, Shader.TileMode.DECAL));
        }
        hero.addView(l, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return l;
    }

    private static void put(FrameLayout layer, View v, int wDp, int hDp, int gravity,
                            int dx, int dy, float rotation, float alpha) {
        Context c = layer.getContext();
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                wDp > 0 ? dp(c, wDp) : ViewGroup.LayoutParams.WRAP_CONTENT,
                hDp > 0 ? dp(c, hDp) : ViewGroup.LayoutParams.WRAP_CONTENT,
                gravity);
        v.setTranslationX(dp(c, dx));
        v.setTranslationY(dp(c, dy));
        v.setRotation(rotation);
        v.setAlpha(alpha);
        layer.addView(v, lp);
    }

    private static void add(LinearLayout parent, View child, int topDp, int heightDp) {
        Context c = parent.getContext();
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                heightDp > 0 ? dp(c, heightDp) : ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(c, topDp);
        parent.addView(child, lp);
    }

    private static int dp(Context c, float v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }
}