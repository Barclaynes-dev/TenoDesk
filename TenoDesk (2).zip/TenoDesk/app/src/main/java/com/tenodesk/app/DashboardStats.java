package com.tenodesk.app;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class DashboardStats {

    public static final class RecentPayment {
        public String name;
        public long amount;
        public String date;
        public String month;
    }

    public int tenantCount;
    public int roomCount;
    public int overdueCount;
    public int dueSoonCount;
    public int vacantCount;
    public long collectedThisMonth;
    public long weekTotal;
    public final long[] week = new long[7];          // oldest first, today last
    public final String[] weekLabels = new String[7];
    public List<Tenant> topTenants = new ArrayList<>();
    public List<Tenant> upcoming = new ArrayList<>();
    public List<Room> vacantRooms = new ArrayList<>();
    public List<RecentPayment> recent = new ArrayList<>();
    public Bill latestBill;

    private DashboardStats() {}

    public static DashboardStats load(Context ctx) {
        DatabaseHelper helper = DatabaseHelper.get(ctx);
        DashboardStats s = new DashboardStats();
        SQLiteDatabase db = helper.getReadableDatabase();

        // money collected this calendar month
        Cursor c = db.rawQuery(
                "SELECT IFNULL(SUM(amount), 0) FROM payments WHERE substr(date_paid, 1, 7) = ?",
                new String[]{RentEngine.currentMonth()});
        try {
            if (c.moveToFirst()) s.collectedThisMonth = c.getLong(0);
        } finally {
            c.close();
        }

        // last 7 days
        SimpleDateFormat dayFmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        SimpleDateFormat nameFmt = new SimpleDateFormat("EEE", Locale.US);
        String[] dates = new String[7];
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, -6);
        for (int i = 0; i < 7; i++) {
            dates[i] = dayFmt.format(cal.getTime());
            s.weekLabels[i] = nameFmt.format(cal.getTime());
            cal.add(Calendar.DAY_OF_MONTH, 1);
        }

        Map<String, Long> byDay = new HashMap<>();
        c = db.rawQuery(
                "SELECT date_paid, SUM(amount) FROM payments WHERE date_paid >= ? GROUP BY date_paid",
                new String[]{dates[0]});
        try {
            while (c.moveToNext()) byDay.put(c.getString(0), c.getLong(1));
        } finally {
            c.close();
        }
        for (int i = 0; i < 7; i++) {
            Long v = byDay.get(dates[i]);
            s.week[i] = v == null ? 0 : v;
            s.weekTotal += s.week[i];
        }

        // recent payments
        c = db.rawQuery(
                "SELECT p.amount, p.date_paid, p.month_covered, IFNULL(t.name, '') "
                        + "FROM payments p LEFT JOIN tenants t ON t.id = p.tenant_id "
                        + "ORDER BY p.id DESC LIMIT 4", null);
        try {
            while (c.moveToNext()) {
                RecentPayment p = new RecentPayment();
                p.amount = c.getLong(0);
                p.date = c.getString(1);
                p.month = c.getString(2);
                p.name = c.getString(3);
                s.recent.add(p);
            }
        } finally {
            c.close();
        }

        // tenants
        List<Tenant> tenants = helper.getTenants();
        s.tenantCount = tenants.size();
        for (Tenant t : tenants) {
            if (RentEngine.OVERDUE.equals(t.status)) s.overdueCount++;
            else if (RentEngine.DUE.equals(t.status)) s.dueSoonCount++;

            if (RentEngine.DUE.equals(t.status) && t.daysLeft <= 7) s.upcoming.add(t);
        }
        Collections.sort(s.upcoming, (a, b) -> a.daysLeft - b.daysLeft);

        TenantSort.sort(tenants);
        s.topTenants = tenants.size() > 3
                ? new ArrayList<>(tenants.subList(0, 3)) : tenants;

        // rooms
        List<Room> rooms = helper.getRooms();
        s.roomCount = rooms.size();
        for (Room r : rooms) {
            if (r.isVacant()) s.vacantRooms.add(r);
        }
        s.vacantCount = s.vacantRooms.size();

        // latest bill
        List<Bill> bills = new BillsRepo(ctx).getBills();
        if (!bills.isEmpty()) s.latestBill = bills.get(0);

        return s;
    }
}