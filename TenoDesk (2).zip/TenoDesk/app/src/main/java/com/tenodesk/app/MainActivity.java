package com.tenodesk.app;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public class MainActivity extends AppCompatActivity {

    private LinearLayout[] tabs;
    private DrawView[] icons;
    private int current = -1;

    private final ActivityResultLauncher<String> notificationPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> { });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_main);

        // a fresh open of the app (not a rotation or theme change) plays the intro
        boolean fresh = savedInstanceState == null;
        if (fresh) Shapes.homePending = true;
        boolean intro = fresh && !Motion.isReduced(this);

        // keep the screen out from under the status and navigation bars
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.mainRoot), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        tabs = new LinearLayout[]{
                findViewById(R.id.navHome),
                findViewById(R.id.navTenants),
                findViewById(R.id.navRooms),
                findViewById(R.id.navBills)};
        icons = new DrawView[tabs.length];

        for (int i = 0; i < tabs.length; i++) {
            final int index = i;
            tabs[i].setOnClickListener((View v) -> select(index));
            swapIcon(i, intro);
        }

        if (intro) {
            View bar = findViewById(R.id.navBar);
            bar.setTranslationY(dp(90));
            bar.setAlpha(0f);
            bar.animate().translationY(0f).alpha(1f).setDuration(520)
                    .setInterpolator(new DecelerateInterpolator(2f)).start();
        }

        if (savedInstanceState == null) {
            select(0);
        } else {
            current = savedInstanceState.getInt("tab", 0);
            highlight(false);
        }

        askForNotifications();
    }

    /** Replaces the plain picture with one that can draw itself. */
    private void swapIcon(int i, boolean animate) {
        LinearLayout tab = tabs[i];
        DrawView icon = Shapes.navIcon(this, i);
        tab.removeViewAt(0);
        tab.addView(icon, 0, new LinearLayout.LayoutParams(dp(22), dp(22)));
        icons[i] = icon;
        if (animate) icon.play(380 + i * 140L, 900);
        else icon.showComplete();
    }

    /** Lets other screens switch tabs, for example "See all" on Home. */
    public void openTab(int index) {
        select(index);
    }

    private Fragment createFragment(int index) {
        if (index == 0) return new HomeFragment();
        if (index == 1) return new TenantsFragment();
        if (index == 2) return new RoomsFragment();
        return new BillsFragment();
    }

    private void select(int index) {
        if (index == current) return;
        boolean first = current == -1;
        current = index;
        getSupportFragmentManager().beginTransaction()
                .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
                .replace(R.id.fragmentContainer, createFragment(index))
                .commit();
        highlight(!first);
    }

    private void highlight(boolean animate) {
        int active = getColor(R.color.td_accent);
        int idle = getColor(R.color.td_text_secondary);
        for (int i = 0; i < tabs.length; i++) {
            boolean on = (i == current);
            LinearLayout tab = tabs[i];
            icons[i].setColor(on ? active : idle);
            ((TextView) tab.getChildAt(1)).setTextColor(on ? active : idle);
            tab.setBackgroundResource(on ? R.drawable.bg_nav_active : 0);

            if (on && animate && !Motion.isReduced(this)) {
                tab.setScaleX(0.86f);
                tab.setScaleY(0.86f);
                tab.animate().scaleX(1f).scaleY(1f).setDuration(380)
                        .setInterpolator(new OvershootInterpolator(2.5f)).start();
            }
        }
    }

    /** Android 13 and above ask permission before an app may show notifications. We ask once, politely. */
    private void askForNotifications() {
        if (Build.VERSION.SDK_INT < 33) return;
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED) return;

        SharedPreferences prefs = getSharedPreferences("tenodesk_prefs", Context.MODE_PRIVATE);
        if (prefs.getBoolean("asked_notifications", false)) return;
        prefs.edit().putBoolean("asked_notifications", true).apply();

        new MaterialAlertDialogBuilder(this)
                .setTitle("Rent reminders")
                .setMessage("TenoDesk can remind you when a tenant's rent is almost due or overdue, "
                        + "and in the last week of each month. Allow notifications on the next screen.")
                .setNegativeButton("Not now", null)
                .setPositiveButton("Continue", (d, w) ->
                        notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS))
                .show();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("tab", current);
    }
}