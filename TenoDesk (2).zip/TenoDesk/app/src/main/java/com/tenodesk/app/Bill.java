package com.tenodesk.app;

public class Bill {
    public long id;
    public String billType;
    public long totalAmount;
    public String date;
    public long splitAmount;
    public int shareCount;
}