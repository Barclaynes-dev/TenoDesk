package com.tenodesk.app;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class PaymentsAdapter extends RecyclerView.Adapter<PaymentsAdapter.VH> {

    private final List<Payment> items = new ArrayList<>();

    public void submit(List<Payment> newItems) {
        items.clear();
        items.addAll(newItems);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_payment, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Payment p = items.get(position);
        h.month.setText(RentEngine.label(p.monthCovered));
        h.date.setText("Paid on " + DateUi.pretty(p.datePaid));
        h.amount.setText(Money.format(p.amount));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        final TextView month, date, amount;

        VH(@NonNull View v) {
            super(v);
            month = v.findViewById(R.id.payMonth);
            date = v.findViewById(R.id.payDate);
            amount = v.findViewById(R.id.payAmount);
        }
    }
}