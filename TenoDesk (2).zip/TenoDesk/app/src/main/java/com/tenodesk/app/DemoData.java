package com.tenodesk.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class DemoData {
    private DemoData() {}

    public static boolean hasData(Context ctx) {
        return !DatabaseHelper.get(ctx).getCategories().isEmpty();
    }

    private static String daysAgo(int n) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_MONTH, -n);
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.getTime());
    }

    // name, phone, room, joined N days ago, paid N days ago (-1 means not paid yet)
    private static final Object[][] PEOPLE = {
            {"Grace Nabirye",    "0772100201", "Single room 1", 3,  3},
            {"Peter Okello",     "0701100202", "Single room 2", 24, -1},
            {"Sarah Kirabo",     "0752100203", "Single room 3", 28, -1},
            {"David Mugisha",    "0782100204", "Single room 4", 12, 6},
            {"Ruth Atim",        "0700100205", "Single room 5", 8,  -1},
            {"Joseph Ssemakula", "0772100206", "Double room 1", 20, 5},
            {"Esther Namukasa",  "0759100207", "Double room 2", 2,  1}};

    public static void load(Context ctx) {
        DatabaseHelper db = DatabaseHelper.get(ctx);

        long single = db.addCategory("Single room", 120000);
        long dbl = db.addCategory("Double room", 200000);
        db.addRoomsAuto(single, "Single room", 6);
        db.addRoomsAuto(dbl, "Double room", 3);

        Map<String, Room> byName = new HashMap<>();
        for (Room r : db.getRooms()) byName.put(r.roomNumber, r);

        for (Object[] p : PEOPLE) {
            Room room = byName.get((String) p[2]);
            if (room == null) continue;
            long id = db.addTenant((String) p[0], (String) p[1], room.id, daysAgo((Integer) p[3]));
            int paidAgo = (Integer) p[4];
            if (id > 0 && paidAgo >= 0) {
                Tenant t = db.getTenant(id);
                if (t != null && !t.unpaidMonths.isEmpty()) {
                    ContentValues v = new ContentValues();
                    v.put("tenant_id", id);
                    v.put("amount", t.monthlyRent);
                    v.put("date_paid", daysAgo(paidAgo));
                    v.put("month_covered", t.unpaidMonths.get(0));
                    db.getWritableDatabase().insert("payments", null, v);
                }
            }
        }

        List<Tenant> all = db.getTenants();
        List<Tenant> sharing = new ArrayList<>(all.subList(0, Math.min(5, all.size())));
        if (!sharing.isEmpty()) {
            new BillsRepo(ctx).addBill("Water", 90000, daysAgo(4), sharing);
        }
    }

    public static void clearAll(Context ctx) {
        new BillsRepo(ctx).getBills();     // makes sure the bill table exists
        SQLiteDatabase d = DatabaseHelper.get(ctx).getWritableDatabase();
        d.beginTransaction();
        try {
            d.delete("bill_shares", null, null);
            d.delete("payments", null, null);
            d.delete("tenants", null, null);
            d.delete("rooms", null, null);
            d.delete("categories", null, null);
            d.delete("utility_bills", null, null);
            d.setTransactionSuccessful();
        } finally {
            d.endTransaction();
        }
        ctx.getSharedPreferences("tenodesk_reminders", Context.MODE_PRIVATE).edit().clear().apply();
    }
}