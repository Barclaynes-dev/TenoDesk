package com.tenodesk.app;

import android.content.Context;
import android.text.InputFilter;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;

import androidx.appcompat.app.AlertDialog;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public final class NameDialog {
    private NameDialog() {}

    public static void show(Context ctx, Runnable onSaved) {
        float d = ctx.getResources().getDisplayMetrics().density;

        EditText input = new EditText(ctx);
        input.setText(AppPrefs.getLandlordName(ctx));
        input.setSelection(input.getText().length());
        input.setSingleLine(true);
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(24)});
        input.setBackgroundResource(R.drawable.bg_input);
        input.setTextColor(ctx.getColor(R.color.td_text_primary));
        input.setPadding((int) (14 * d), 0, (int) (14 * d), 0);

        FrameLayout box = new FrameLayout(ctx);
        box.setPadding((int) (24 * d), (int) (8 * d), (int) (24 * d), 0);
        box.addView(input, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, (int) (52 * d)));

        AlertDialog dialog = new MaterialAlertDialogBuilder(ctx)
                .setTitle("What should we call you?")
                .setView(box)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null)
                .create();
        dialog.show();

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(x -> {
            String n = input.getText().toString().trim();
            if (n.isEmpty()) {
                input.setError("Enter a name");
                return;
            }
            AppPrefs.setLandlordName(ctx, n);
            dialog.dismiss();
            if (onSaved != null) onSaved.run();
        });
    }
}