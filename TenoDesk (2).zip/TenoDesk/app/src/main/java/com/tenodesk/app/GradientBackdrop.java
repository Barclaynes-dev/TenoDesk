package com.tenodesk.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.Choreographer;
import android.view.View;

/**
 * A slow, flowing colour field: gold light rising from the bottom, a violet rim on the right,
 * and a drifting band of light. It is drawn small and scaled up smoothly, so it stays light
 * on the phone and never flickers during screen changes.
 */
public class GradientBackdrop extends View {

    // ---- things you can tune --------------------------------------------------
    private static final int LOW_W = 72;          // drawing width; bigger = smoother but heavier
    private static final long FRAME_MS = 33;      // 33 = about 30 frames per second
    private static final float SPEED = 1.0f;      // 2.0 = twice as fast, 0.5 = half
    private static final float GOLD = 0.85f;      // strength of the gold light
    private static final float VIOLET = 1.0f;     // strength of the violet light

    private static final int LUT = 1024;
    private static final float[] SIN = new float[LUT];

    static {
        for (int i = 0; i < LUT; i++) SIN[i] = (float) Math.sin(i * 2.0 * Math.PI / LUT);
    }

    private int w, h;
    private int[] pixels;
    private Bitmap bitmap;
    private float[] colL, colR, colU, colPh1, colPh2;
    private float[] rowY, rowBottom, rowEdge, rowPh1, rowPh2, rowSideG, rowSideV, rowTop, rowAurora;

    private final int[] goldRamp = new int[256];
    private final int[] violetRamp = new int[256];
    private int baseR, baseG, baseB;

    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Rect dst = new Rect();

    private boolean running;
    private long lastMs;
    private float clock = 4f;
    private float page = 0f;

    public GradientBackdrop(Context context) {
        super(context);
        initRamps();
    }

    public GradientBackdrop(Context context, AttributeSet attrs) {
        super(context, attrs);
        initRamps();
    }

    public GradientBackdrop(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initRamps();
    }

    // -------------------------------------------------------------------- colours

    private void initRamps() {
        boolean night = (getResources().getConfiguration().uiMode
                & android.content.res.Configuration.UI_MODE_NIGHT_MASK)
                == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        int base = getContext().getColor(R.color.td_background);
        baseR = Color.red(base);
        baseG = Color.green(base);
        baseB = Color.blue(base);

        float[] pos = {0f, 0.30f, 0.62f, 1f};
        if (night) {
            fillRamp(goldRamp, pos, new int[]{base, 0xFF2B200A, 0xFF9E761E, 0xFFE8C466});
            fillRamp(violetRamp, new float[]{0f, 0.5f, 1f}, new int[]{base, 0xFF241A55, 0xFF7B5CE6});
        } else {
            fillRamp(goldRamp, pos, new int[]{base, 0xFFF3E4B8, 0xFFEBCB78, 0xFFD9A92E});
            fillRamp(violetRamp, new float[]{0f, 0.5f, 1f}, new int[]{base, 0xFFE6DEF8, 0xFFB9A6F2});
        }
    }

    private static void fillRamp(int[] out, float[] pos, int[] colors) {
        for (int i = 0; i < 256; i++) {
            float t = i / 255f;
            int k = 0;
            while (k < pos.length - 2 && t > pos[k + 1]) k++;
            float f = (t - pos[k]) / (pos[k + 1] - pos[k]);
            f = Math.max(0f, Math.min(1f, f));
            int a = colors[k];
            int b = colors[k + 1];
            int r = (int) (Color.red(a) + (Color.red(b) - Color.red(a)) * f);
            int g = (int) (Color.green(a) + (Color.green(b) - Color.green(a)) * f);
            int bl = (int) (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f);
            out[i] = (r << 16) | (g << 8) | bl;
        }
    }

    // -------------------------------------------------------------------- control

    /** The onboarding calls this while you swipe, so the colours flow with your finger. */
    public void setPage(float p) {
        page = p;
        if (!running && bitmap != null) {
            render(clock);
            invalidate();
        }
    }

    private void start() {
        if (running || bitmap == null) return;
        if (Motion.isReduced(getContext())) {       // keep the look, drop the movement
            render(clock);
            invalidate();
            return;
        }
        running = true;
        lastMs = 0;
        Choreographer.getInstance().postFrameCallback(tick);
    }

    private void stop() {
        running = false;
        Choreographer.getInstance().removeFrameCallback(tick);
    }

    private final Choreographer.FrameCallback tick = new Choreographer.FrameCallback() {
        @Override
        public void doFrame(long frameTimeNanos) {
            if (!running) return;
            long now = frameTimeNanos / 1_000_000L;
            if (lastMs == 0) lastMs = now;
            long dt = now - lastMs;
            if (dt >= FRAME_MS) {
                lastMs = now;
                clock += Math.min(dt, 100L) / 1000f;
                render(clock);
                invalidate();
            }
            Choreographer.getInstance().postFrameCallback(this);
        }
    };

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        start();
    }

    @Override
    protected void onDetachedFromWindow() {
        stop();
        super.onDetachedFromWindow();
    }

    @Override
    public void onVisibilityAggregated(boolean isVisible) {
        super.onVisibilityAggregated(isVisible);
        if (isVisible) start();
        else stop();
    }

    @Override
    protected void onSizeChanged(int newW, int newH, int oldw, int oldh) {
        super.onSizeChanged(newW, newH, oldw, oldh);
        if (newW <= 0 || newH <= 0) return;
        w = LOW_W;
        h = Math.max(16, Math.round(LOW_W * newH / (float) newW));
        pixels = new int[w * h];
        bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        colL = new float[w];
        colR = new float[w];
        colU = new float[w];
        colPh1 = new float[w];
        colPh2 = new float[w];
        rowY = new float[h];
        rowBottom = new float[h];
        rowEdge = new float[h];
        rowPh1 = new float[h];
        rowPh2 = new float[h];
        rowSideG = new float[h];
        rowSideV = new float[h];
        rowTop = new float[h];
        rowAurora = new float[h];
        render(clock);
        start();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (bitmap == null) return;
        dst.set(0, 0, getWidth(), getHeight());
        canvas.drawBitmap(bitmap, null, dst, paint);
    }

    // ------------------------------------------------------------------ drawing

    private static float sinC(float cycles) {
        float f = cycles - (int) cycles;
        if (f < 0f) f += 1f;
        return SIN[(int) (f * LUT) & (LUT - 1)];
    }

    private static int clamp255(int v) {
        return v < 0 ? 0 : Math.min(v, 255);
    }

    private void render(float t) {
        if (pixels == null) return;
        float tt = t * SPEED;
        float pg = page;

        for (int x = 0; x < w; x++) {
            float u = x / (float) (w - 1);
            float l = 1f - u;
            float l2 = l * l;
            float l4 = l2 * l2;
            float u2 = u * u;
            float u4 = u2 * u2;
            colL[x] = l4 * l4 * l4;                       // thin glow hugging the left edge
            colR[x] = u4 * u4 * u4;                       // thin glow hugging the right edge
            colU[x] = u;
            colPh1[x] = u * 0.55f + tt * 0.040f + pg * 0.20f;
            colPh2[x] = u * 0.90f - tt * 0.050f + pg * 0.32f;
        }

        for (int y = 0; y < h; y++) {
            float v = y / (float) (h - 1);
            float v2 = v * v;
            float v3 = v2 * v;
            float v6 = v3 * v3;
            float top = 1f - v;
            float top2 = top * top;
            float d = v - (0.90f + 0.04f * sinC(tt * 0.030f));
            rowY[y] = v;
            rowBottom[y] = v6;                            // gold rises only near the bottom
            rowEdge[y] = v6 * v2;
            rowPh1[y] = 0.35f * sinC(v * 0.40f + tt * 0.035f);
            rowPh2[y] = 0.25f * sinC(v * 0.70f - tt * 0.040f + 0.30f);
            rowSideG[y] = 0.5f + 0.5f * sinC(v * 0.80f - tt * 0.045f);
            rowSideV[y] = 0.5f + 0.5f * sinC(v * 0.70f + tt * 0.040f + 0.40f);
            rowTop[y] = top2 * top2 * top2;
            rowAurora[y] = (float) Math.exp(-d * d * 60f);
        }

        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                float wave = 0.5f + 0.5f * sinC(colPh1[x] + rowPh1[y]);
                float aur = 0.5f + 0.5f * sinC(colPh2[x] + rowPh2[y]);

                float ig = rowBottom[y] * (0.42f + 0.62f * wave)
                        + 0.30f * rowEdge[y]
                        + colL[x] * (0.30f + 0.50f * rowSideG[y]) * (0.25f + 0.75f * rowY[y])
                        + 0.32f * rowAurora[y] * (0.35f + 0.65f * aur);
                float iv = colR[x] * (0.35f + 0.65f * rowSideV[y])
                        + rowTop[y] * colU[x] * (0.30f + 0.55f * wave);

                int gi = clamp255((int) (ig * GOLD * 255f));
                int vi = clamp255((int) (iv * VIOLET * 255f));
                int gc = goldRamp[gi];
                int vc = violetRamp[vi];

                int r = clamp255(((gc >> 16) & 255) + ((vc >> 16) & 255) - baseR);
                int g = clamp255(((gc >> 8) & 255) + ((vc >> 8) & 255) - baseG);
                int b = clamp255((gc & 255) + (vc & 255) - baseB);
                pixels[y * w + x] = 0xFF000000 | (r << 16) | (g << 8) | b;
            }
        }
        bitmap.setPixels(pixels, 0, w, 0, 0, w, h);
    }
}