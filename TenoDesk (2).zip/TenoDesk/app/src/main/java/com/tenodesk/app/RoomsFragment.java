package com.tenodesk.app;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RoomsFragment extends Fragment implements RoomsAdapter.Listener {

    private static final int MAX_ROOMS_AT_ONCE = 200;

    private DatabaseHelper db;
    private RoomsAdapter adapter;
    private View emptyState;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_rooms, container, false);
        db = DatabaseHelper.get(requireContext());

        RecyclerView list = v.findViewById(R.id.roomsList);
        list.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new RoomsAdapter(this);
        list.setAdapter(adapter);
        if (!Motion.isReduced(requireContext())) {
            list.setLayoutAnimation(android.view.animation.AnimationUtils.loadLayoutAnimation(
                    requireContext(), R.anim.layout_slide_up));
        }

        emptyState = v.findViewById(R.id.roomsEmpty);
        View.OnClickListener add = x -> showCategoryDialog(null);
        v.findViewById(R.id.btnAddCategory).setOnClickListener(add);
        v.findViewById(R.id.btnEmptyAdd).setOnClickListener(add);
        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        List<Category> cats = db.getCategories();
        List<Room> rooms = db.getRooms();

        Map<Long, Tenant> tenants = new HashMap<>();
        for (Tenant t : db.getTenants()) tenants.put(t.id, t);
        for (Room r : rooms) {
            Tenant t = tenants.get(r.tenantId);
            if (t != null) {
                r.status = t.status;
                r.owed = t.amountOwed();
            }
        }

        List<Object> items = new ArrayList<>();
        for (Category c : cats) {
            items.add(c);
            for (Room r : rooms) {
                if (r.categoryId == c.id) items.add(r);
            }
        }
        adapter.submit(items);
        emptyState.setVisibility(cats.isEmpty() ? View.VISIBLE : View.GONE);
    }

    // ---------------------------------------------------------- adapter callbacks

    @Override
    public void onCategoryClick(Category category) {
        showCategoryDialog(category);
    }

    @Override
    public void onAddRooms(Category category) {
        showMoreRoomsDialog(category);
    }

    @Override
    public void onRoomClick(Room room) {
        if (room.isVacant()) {
            showRoomSheet(room);
        } else {
            Intent i = new Intent(requireContext(), TenantDetailActivity.class);
            i.putExtra("tenant_id", room.tenantId);
            startActivity(i);
        }
    }

    // ------------------------------------------------------------ category dialog

    /** existing == null creates a new category with its rooms; otherwise edits it. */
    private void showCategoryDialog(@Nullable Category existing) {
        View view = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_category, null);
        EditText name = view.findViewById(R.id.catName);
        EditText price = view.findViewById(R.id.catPrice);
        EditText count = view.findViewById(R.id.catCount);
        View countGroup = view.findViewById(R.id.catCountGroup);
        TextView preview = view.findViewById(R.id.catPreview);

        if (existing != null) {
            name.setText(existing.name);
            price.setText(String.valueOf(existing.monthlyPrice));
            countGroup.setVisibility(View.GONE);
        } else {
            TextWatcher w = watcher(() -> preview.setText(previewText(name, count)));
            name.addTextChangedListener(w);
            count.addTextChangedListener(w);
        }

        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(requireContext())
                .setTitle(existing == null ? "Add rooms" : "Edit category")
                .setView(view)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null);
        if (existing != null) builder.setNeutralButton("Delete", null);

        AlertDialog dialog = builder.create();
        dialog.show();

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(x -> {
            String n = name.getText().toString().trim();
            long p = parseLong(price, 0);
            long howMany = parseLong(count, 0);

            if (n.isEmpty()) {
                name.setError("Enter a name, for example Single room");
                return;
            }
            if (db.categoryNameExists(n, existing == null ? 0 : existing.id)) {
                name.setError("You already have a category with this name");
                return;
            }
            if (p <= 0) {
                price.setError("Enter the monthly rent");
                return;
            }

            if (existing == null) {
                if (howMany < 1 || howMany > MAX_ROOMS_AT_ONCE) {
                    count.setError("Enter a number from 1 to " + MAX_ROOMS_AT_ONCE);
                    return;
                }
                long id = db.addCategory(n, p);
                int made = db.addRoomsAuto(id, n, (int) howMany);
                toast(made + (made == 1 ? " room created" : " rooms created"));
            } else {
                db.updateCategory(existing.id, n, p);
            }
            dialog.dismiss();
            refresh();
        });

        if (existing != null) {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(x -> {
                if (db.deleteCategory(existing.id)) {
                    dialog.dismiss();
                    refresh();
                } else {
                    toast("This category still has rooms. Delete its rooms first.");
                }
            });
        }
    }

    private void showMoreRoomsDialog(Category category) {
        View view = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_count, null);
        EditText input = view.findViewById(R.id.countInput);

        AlertDialog dialog = new MaterialAlertDialogBuilder(requireContext())
                .setTitle("Add more " + category.name + " rooms")
                .setView(view)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Add rooms", null)
                .create();
        dialog.show();

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(x -> {
            long howMany = parseLong(input, 0);
            if (howMany < 1 || howMany > MAX_ROOMS_AT_ONCE) {
                input.setError("Enter a number from 1 to " + MAX_ROOMS_AT_ONCE);
                return;
            }
            int made = db.addRoomsAuto(category.id, category.name, (int) howMany);
            toast(made + (made == 1 ? " room created" : " rooms created"));
            dialog.dismiss();
            refresh();
        });
    }

    // ----------------------------------------------------------------- room sheet

    private void showRoomSheet(Room room) {
        BottomSheetDialog sheet = new BottomSheetDialog(requireContext());
        View v = LayoutInflater.from(requireContext()).inflate(R.layout.sheet_room, null);
        sheet.setContentView(v);
        ((View) v.getParent()).setBackgroundColor(Color.TRANSPARENT);

        ((TextView) v.findViewById(R.id.sheetTitle)).setText(room.roomNumber);
        ((TextView) v.findViewById(R.id.sheetSub)).setText(
                room.categoryName + "  \u00B7  " + Money.format(room.monthlyPrice) + " / month");

        v.findViewById(R.id.btnRename).setOnClickListener(x -> showRenameDialog(room, sheet));
        renderSheet(sheet, v, room, room.tenantId);
        sheet.show();
    }

    /** Shows either the "add tenant" form or the tenant's details, depending on the room. */
    private void renderSheet(BottomSheetDialog sheet, View v, Room room, long tenantId) {
        View vacant = v.findViewById(R.id.sheetVacant);
        View occupied = v.findViewById(R.id.sheetOccupied);
        Tenant t = tenantId != 0 ? db.getTenant(tenantId) : null;

        if (t == null) {
            vacant.setVisibility(View.VISIBLE);
            occupied.setVisibility(View.GONE);

            EditText nameIn = v.findViewById(R.id.tenantName);
            EditText phoneIn = v.findViewById(R.id.tenantPhone);

            v.findViewById(R.id.btnAddTenant).setOnClickListener(x -> {
                String n = nameIn.getText().toString().trim();
                if (n.isEmpty()) {
                    nameIn.setError("Enter the tenant's name");
                    return;
                }
                long id = db.addTenant(n, phoneIn.getText().toString().trim(),
                        room.id, RentEngine.today());
                if (id == -1) {
                    toast("This room already has a tenant");
                    return;
                }
                sheet.dismiss();
                refresh();
            });

            v.findViewById(R.id.btnDeleteRoom).setOnClickListener(x ->
                    new MaterialAlertDialogBuilder(requireContext())
                            .setTitle("Delete " + room.roomNumber + "?")
                            .setNegativeButton("Cancel", null)
                            .setPositiveButton("Delete", (d, w) -> {
                                db.deleteRoom(room.id);
                                sheet.dismiss();
                                refresh();
                            })
                            .show());
            return;
        }

        vacant.setVisibility(View.GONE);
        occupied.setVisibility(View.VISIBLE);

        ((TextView) v.findViewById(R.id.occName)).setText(t.name);
        StatusUi.apply(v.findViewById(R.id.occBadge), t.status);
        ((TextView) v.findViewById(R.id.occPhone)).setText(
                (t.phone == null || t.phone.isEmpty()) ? "No phone number saved" : t.phone);

        TextView owed = v.findViewById(R.id.occOwed);
        int months = t.unpaidMonths.size();
        if (months == 0) {
            owed.setText("Everything is paid up");
            owed.setTextColor(requireContext().getColor(R.color.td_paid));
        } else {
            owed.setText("Owes " + Money.format(t.amountOwed()) + " for " + months
                    + (months == 1 ? " month" : " months"));
            owed.setTextColor(requireContext().getColor(
                    RentEngine.OVERDUE.equals(t.status) ? R.color.td_overdue : R.color.td_accent));
        }

        TextView collect = v.findViewById(R.id.btnCollect);
        if (months == 0) {
            collect.setText("All paid up \u2713");
            collect.setEnabled(false);
            collect.setAlpha(0.5f);
        } else {
            collect.setText("Mark " + RentEngine.label(t.unpaidMonths.get(0)) + " as paid");
            collect.setEnabled(true);
            collect.setAlpha(1f);
            collect.setOnClickListener(x -> {
                db.collectRent(t.id);
                refresh();
                renderSheet(sheet, v, room, t.id);
            });
        }

        View undo = v.findViewById(R.id.btnUndo);
        undo.setVisibility(db.getPayments(t.id).isEmpty() ? View.GONE : View.VISIBLE);
        undo.setOnClickListener(x -> {
            db.undoLastPayment(t.id);
            refresh();
            renderSheet(sheet, v, room, t.id);
        });

        v.findViewById(R.id.btnMoveOut).setOnClickListener(x ->
                new MaterialAlertDialogBuilder(requireContext())
                        .setTitle("Move " + t.name + " out?")
                        .setMessage("The room becomes empty. Their payment history is kept.")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Move out", (d, w) -> {
                            db.moveOutTenant(t.id);
                            sheet.dismiss();
                            refresh();
                        })
                        .show());
    }

    private void showRenameDialog(Room room, BottomSheetDialog sheet) {
        EditText input = new EditText(requireContext());
        input.setText(room.roomNumber);
        input.setSelection(input.getText().length());
        input.setSingleLine(true);
        input.setBackgroundResource(R.drawable.bg_input);
        input.setTextColor(requireContext().getColor(R.color.td_text_primary));
        input.setPadding(dp(14), 0, dp(14), 0);

        FrameLayout box = new FrameLayout(requireContext());
        box.setPadding(dp(24), dp(8), dp(24), 0);
        box.addView(input, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        AlertDialog dialog = new MaterialAlertDialogBuilder(requireContext())
                .setTitle("Rename room")
                .setView(box)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null)
                .create();
        dialog.show();

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(x -> {
            String n = input.getText().toString().trim();
            if (n.isEmpty()) {
                input.setError("Enter a name");
                return;
            }
            if (!db.renameRoom(room.id, n)) {
                input.setError("Another room already has this name");
                return;
            }
            dialog.dismiss();
            sheet.dismiss();
            refresh();
        });
    }

    // ------------------------------------------------------------------- helpers

    private String previewText(EditText name, EditText count) {
        long n = parseLong(count, 0);
        String base = name.getText().toString().trim();
        if (n <= 0 || base.isEmpty()) return "";
        if (n == 1) return "Will create: " + base + " 1";
        return "Will create: " + base + " 1 to " + base + " " + n + "  (" + n + " rooms)";
    }

    private TextWatcher watcher(Runnable onChange) {
        return new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {}

            @Override
            public void afterTextChanged(Editable s) {
                onChange.run();
            }
        };
    }

    private long parseLong(EditText field, long fallback) {
        try {
            return Long.parseLong(field.getText().toString().trim());
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    private void toast(String message) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
    }
}