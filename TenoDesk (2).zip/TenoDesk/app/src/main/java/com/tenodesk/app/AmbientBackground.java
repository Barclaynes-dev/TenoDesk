package com.tenodesk.app;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Property;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.FrameLayout;

import androidx.core.graphics.ColorUtils;

import java.util.ArrayList;
import java.util.List;

public class AmbientBackground extends FrameLayout {

    private final List<View> blobs = new ArrayList<>();
    private final List<ObjectAnimator> animators = new ArrayList<>();

    public AmbientBackground(Context context) {
        super(context);
        init(context);
    }

    public AmbientBackground(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public AmbientBackground(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    /** The glows are built here, before the first layout, so they can never be skipped. */
    private void init(Context c) {
        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        float w = dm.widthPixels;
        float h = dm.heightPixels;

        boolean night = (c.getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        float strength = night ? 0.55f : 0.42f;
        int diameter = (int) (w * 1.5f);

        addBlob(c, R.color.td_glow_gold,   strength,        diameter, w * 0.05f, h * 0.06f, w * 0.14f, h * 0.04f, 19000, 23000);
        addBlob(c, R.color.td_glow_violet, strength,        diameter, w * 1.00f, h * 0.46f, w * 0.12f, h * 0.06f, 23000, 29000);
        addBlob(c, R.color.td_glow_teal,   strength * 0.9f, diameter, w * 0.08f, h * 0.97f, w * 0.16f, h * 0.04f, 27000, 21000);
    }

    private void addBlob(Context c, int colorRes, float strength, int diameter,
                         float cx, float cy, float dx, float dy, long durX, long durY) {
        int color = ColorUtils.setAlphaComponent(c.getColor(colorRes), (int) (255 * strength));

        BlobView blob = new BlobView(c, color);
        LayoutParams lp = new LayoutParams(diameter, diameter);
        lp.leftMargin = (int) (cx - diameter / 2f);
        lp.topMargin = (int) (cy - diameter / 2f);
        addView(blob, lp);
        blobs.add(blob);

        animators.add(drift(blob, View.TRANSLATION_X, -dx, dx, durX));
        animators.add(drift(blob, View.TRANSLATION_Y, -dy, dy, durY));
    }

    private ObjectAnimator drift(View v, Property<View, Float> property,
                                 float from, float to, long duration) {
        ObjectAnimator a = ObjectAnimator.ofFloat(v, property, from, to);
        a.setDuration(duration);
        a.setRepeatCount(ObjectAnimator.INFINITE);
        a.setRepeatMode(ObjectAnimator.REVERSE);
        a.setInterpolator(new AccelerateDecelerateInterpolator());
        return a;
    }

    private void startAnimators() {
        if (Motion.isReduced(getContext())) {            // keep the look, drop the movement
            for (ObjectAnimator a : animators) a.cancel();
            for (View b : blobs) {
                b.setTranslationX(0f);
                b.setTranslationY(0f);
            }
            return;
        }
        for (ObjectAnimator a : animators) {
            if (a.isPaused()) a.resume();
            else if (!a.isStarted()) a.start();
        }
    }

    private void pauseAnimators() {
        for (ObjectAnimator a : animators) {
            if (a.isRunning() && !a.isPaused()) a.pause();
        }
    }

    @Override
    public void onVisibilityAggregated(boolean isVisible) {
        super.onVisibilityAggregated(isVisible);
        if (isVisible) startAnimators();
        else pauseAnimators();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        startAnimators();
    }

    @Override
    protected void onDetachedFromWindow() {
        for (ObjectAnimator a : animators) a.cancel();
        super.onDetachedFromWindow();
    }

    /** One soft glow: a circle that is solid in the middle and fades out smoothly. */
    private static class BlobView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int color;

        BlobView(Context context, int color) {
            super(context);
            this.color = color;
            setLayerType(LAYER_TYPE_HARDWARE, null);   // drawn once, then the GPU only moves it
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            float r = Math.min(w, h) / 2f;
            int a = Color.alpha(color);
            int rgb = color & 0x00FFFFFF;
            int[] colors = {
                    (a << 24) | rgb,
                    ((a * 55 / 100) << 24) | rgb,
                    ((a * 18 / 100) << 24) | rgb,
                    rgb};
            float[] stops = {0f, 0.35f, 0.7f, 1f};
            paint.setShader(new RadialGradient(w / 2f, h / 2f, r, colors, stops, Shader.TileMode.CLAMP));
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float r = Math.min(getWidth(), getHeight()) / 2f;
            canvas.drawCircle(getWidth() / 2f, getHeight() / 2f, r, paint);
        }
    }
}