package com.tenodesk.app;

public class Category {
    public long id;
    public String name;
    public long monthlyPrice;
    public int roomCount;
}