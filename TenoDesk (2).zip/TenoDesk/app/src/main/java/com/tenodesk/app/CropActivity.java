package com.tenodesk.app;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

public class CropActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_crop);

        // this screen is always dark, so the status bar icons must be light
        WindowInsetsControllerCompat controller =
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        controller.setAppearanceLightStatusBars(false);
        controller.setAppearanceLightNavigationBars(false);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.cropOverlay), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        Bitmap source = BitmapFactory.decodeFile(ProfilePhoto.sourceFile(this).getAbsolutePath());
        if (source == null) {
            setResult(RESULT_CANCELED);
            finish();
            return;
        }

        CropView cropView = findViewById(R.id.cropView);
        cropView.setBitmap(source);

        findViewById(R.id.cropCancel).setOnClickListener(v -> {
            ProfilePhoto.sourceFile(this).delete();
            setResult(RESULT_CANCELED);
            finish();
        });

        findViewById(R.id.cropUse).setOnClickListener(v -> {
            ProfilePhoto.saveCropped(this, cropView.crop(512));
            setResult(RESULT_OK);
            finish();
        });
    }
}