package com.tenodesk.app;

import android.content.Context;
import android.view.View;
import android.widget.TextView;

public final class StatusUi {
    private StatusUi() {}

    /** Simple badge from a status word (used on the Rooms screen). */
    public static void apply(TextView badge, String status) {
        if (status == null) {
            badge.setVisibility(View.GONE);
            return;
        }
        badge.setVisibility(View.VISIBLE);
        if (RentEngine.PAID.equals(status)) {
            style(badge, "Paid", R.color.td_paid, R.drawable.bg_badge_paid);
        } else if (RentEngine.ACTIVE.equals(status)) {
            style(badge, "Active", R.color.td_text_secondary, R.drawable.bg_badge_due);
        } else if (RentEngine.DUE.equals(status)) {
            style(badge, "Due soon", R.color.td_accent, R.drawable.bg_badge_due);
        } else {
            style(badge, "Overdue", R.color.td_overdue, R.drawable.bg_badge_overdue);
        }
    }

    /** Day-aware badge: "Due in 8 days", "Overdue 2 days", and so on. */
    public static void apply(TextView badge, Tenant t) {
        badge.setVisibility(View.VISIBLE);
        String text = badgeText(t);
        if (RentEngine.PAID.equals(t.status)) {
            style(badge, text, R.color.td_paid, R.drawable.bg_badge_paid);
        } else if (t.level == 2) {
            style(badge, text, R.color.td_overdue, R.drawable.bg_badge_overdue);
        } else if (t.level == 1) {
            style(badge, text, R.color.td_accent, R.drawable.bg_badge_due);
        } else {
            style(badge, text, R.color.td_text_secondary, R.drawable.bg_badge_due);
        }
    }

    public static String badgeText(Tenant t) {
        if (RentEngine.PAID.equals(t.status)) return "Paid";
        if (RentEngine.ACTIVE.equals(t.status)) return t.daysLeft + " days left";
        if (RentEngine.DUE.equals(t.status)) {
            if (t.daysLeft == 0) return "Due today";
            if (t.daysLeft == 1) return "Due tomorrow";
            return "Due in " + t.daysLeft + " days";
        }
        int d = -t.daysLeft;
        return "Overdue " + d + (d == 1 ? " day" : " days");
    }

    /** Red card when the payment is urgent or overdue. */
    public static void styleCard(View card, Tenant t) {
        card.setBackgroundResource(t.level == 2 ? R.drawable.bg_card_urgent : R.drawable.bg_card);
    }

    /** The "!" circle: hidden normally, gold when almost due, red when urgent. */
    public static void styleExclaim(TextView mark, Tenant t) {
        if (t.level == 0) {
            mark.setVisibility(View.GONE);
            return;
        }
        mark.setVisibility(View.VISIBLE);
        mark.setBackgroundResource(t.level == 2
                ? R.drawable.bg_exclaim_urgent : R.drawable.bg_exclaim_warn);
    }

    public static int levelColor(Context c, Tenant t) {
        if (RentEngine.PAID.equals(t.status)) return c.getColor(R.color.td_paid);
        if (t.level == 2) return c.getColor(R.color.td_overdue);
        return c.getColor(R.color.td_accent);
    }

    private static void style(TextView b, String text, int colorRes, int bgRes) {
        b.setText(text);
        b.setTextColor(b.getContext().getColor(colorRes));
        b.setBackgroundResource(bgRes);
    }
}