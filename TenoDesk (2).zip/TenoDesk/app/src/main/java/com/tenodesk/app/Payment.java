package com.tenodesk.app;

public class Payment {
    public long id;
    public long tenantId;
    public long amount;
    public String datePaid;      // "2026-10-09"
    public String monthCovered;  // "2026-10"
}