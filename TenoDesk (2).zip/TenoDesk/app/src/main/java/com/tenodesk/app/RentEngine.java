package com.tenodesk.app;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;

public final class RentEngine {
    public static final String PAID = "PAID";
    public static final String ACTIVE = "ACTIVE";
    public static final String DUE = "DUE";
    public static final String OVERDUE = "OVERDUE";

    public static final int WARN_DAYS = 10;     // exclamation mark and alert
    public static final int URGENT_DAYS = 3;    // card turns red

    private static final long DAY_MS = 86400000L;

    private static final String[] MONTH_NAMES = {
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"};

    private RentEngine() {}

    public static String currentMonth() {
        return new SimpleDateFormat("yyyy-MM", Locale.US).format(Calendar.getInstance().getTime());
    }

    public static String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Calendar.getInstance().getTime());
    }

    /** addMonths("2026-10", -2) gives "2026-08" */
    public static String addMonths(String month, int delta) {
        int y = Integer.parseInt(month.substring(0, 4));
        int m = Integer.parseInt(month.substring(5, 7)) - 1 + delta;
        y += Math.floorDiv(m, 12);
        m = Math.floorMod(m, 12);
        return String.format(Locale.US, "%04d-%02d", y, m + 1);
    }

    /** "2026-10" gives "October 2026" */
    public static String label(String month) {
        int m = Integer.parseInt(month.substring(5, 7)) - 1;
        return MONTH_NAMES[m] + " " + month.substring(0, 4);
    }

    /** True during the last 7 days of the month (used by the reminder later). */
    public static boolean isLastWeekOfMonth() {
        Calendar c = Calendar.getInstance();
        return c.get(Calendar.DAY_OF_MONTH) > c.getActualMaximum(Calendar.DAY_OF_MONTH) - 7;
    }

    // ------------------------------------------------------------ date helpers

    private static int daysInMonth(String ym) {
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c.clear();
        c.set(Integer.parseInt(ym.substring(0, 4)), Integer.parseInt(ym.substring(5, 7)) - 1, 1);
        return c.getActualMaximum(Calendar.DAY_OF_MONTH);
    }

    private static long dayNumber(String ymd) {
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c.clear();
        c.set(Integer.parseInt(ymd.substring(0, 4)),
                Integer.parseInt(ymd.substring(5, 7)) - 1,
                Integer.parseInt(ymd.substring(8, 10)));
        return c.getTimeInMillis() / DAY_MS;
    }

    public static int daysBetween(String from, String to) {
        return (int) (dayNumber(to) - dayNumber(from));
    }

    /** The day a monthly cycle starts: same day-of-month the tenant moved in (clamped for short months). */
    public static String cycleStart(String moveInDate, String ym) {
        int anchor = Integer.parseInt(moveInDate.substring(8, 10));
        int day = Math.min(anchor, daysInMonth(ym));
        return String.format(Locale.US, "%s-%02d", ym, day);
    }

    /** The month of the latest monthly date that is not in the future. Older months are not counted. */
    public static String firstCycleMonth(String moveInDate, String today) {
        String ym = today.substring(0, 7);
        if (cycleStart(moveInDate, ym).compareTo(today) > 0) ym = addMonths(ym, -1);
        String joinMonth = moveInDate.substring(0, 7);
        if (ym.compareTo(joinMonth) < 0) ym = joinMonth;
        return ym;
    }

    // ------------------------------------------------------------- the rules

    /** Fills in status, days left, progress and the unpaid list for one tenant. */
    public static void evaluate(Tenant t, Set<String> paid) {
        String today = today();
        t.unpaidMonths = new ArrayList<>();
        t.dueCount = 0;

        String running = t.moveInMonth;
        String ym = t.moveInMonth;
        while (cycleStart(t.moveInDate, ym).compareTo(today) <= 0) {
            running = ym;
            if (!paid.contains(ym)) {
                t.unpaidMonths.add(ym);
                if (cycleStart(t.moveInDate, addMonths(ym, 1)).compareTo(today) <= 0) {
                    t.dueCount++;
                }
            }
            ym = addMonths(ym, 1);
        }

        String runStart = cycleStart(t.moveInDate, running);
        String runEnd = cycleStart(t.moveInDate, addMonths(running, 1));
        int length = Math.max(1, daysBetween(runStart, runEnd));
        int elapsed = Math.max(0, daysBetween(runStart, today));
        int runPercent = Math.min(100, elapsed * 100 / length);
        t.cycleLength = length;
        t.dayOfCycle = Math.min(length, elapsed + 1);

        if (t.unpaidMonths.isEmpty()) {
            t.status = PAID;
            t.level = 0;
            t.nextDueDate = runEnd;
            t.daysLeft = daysBetween(today, runEnd);
            t.progress = runPercent;
            return;
        }

        String oldest = t.unpaidMonths.get(0);
        t.nextDueDate = cycleStart(t.moveInDate, addMonths(oldest, 1));
        t.daysLeft = daysBetween(today, t.nextDueDate);
        t.progress = oldest.equals(running) ? runPercent : 100;

        if (t.daysLeft < 0) {
            t.status = OVERDUE;
            t.level = 2;
        } else if (t.daysLeft <= URGENT_DAYS) {
            t.status = DUE;
            t.level = 2;
        } else if (t.daysLeft <= WARN_DAYS) {
            t.status = DUE;
            t.level = 1;
        } else {
            t.status = ACTIVE;
            t.level = 0;
        }
    }
}