package com.tenodesk.app;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatDelegate;

public final class ThemeManager {
    private static final String PREFS = "tenodesk_prefs";
    private static final String KEY_DARK = "dark_mode";

    private ThemeManager() {}

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** Dark is the default, since it is the brand look. */
    public static boolean isDark(Context c) {
        return prefs(c).getBoolean(KEY_DARK, true);
    }

    public static void apply(Context c) {
        AppCompatDelegate.setDefaultNightMode(
                isDark(c) ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);
    }

    public static void setDark(Context c, boolean dark) {
        prefs(c).edit().putBoolean(KEY_DARK, dark).apply();
        apply(c);
    }
}