package com.tenodesk.app;

import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import java.util.List;

public final class Notifier {
    public static final String CHANNEL_ID = "rent_reminders";

    private Notifier() {}

    public static void ensureChannel(Context ctx) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Rent reminders", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Tells you when rent is almost due or overdue");
            ctx.getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
    }

    /** lines: optional list shown when the notification is expanded. */
    @SuppressLint("MissingPermission")
    public static void show(Context ctx, int id, String title, String text, List<String> lines) {
        ensureChannel(ctx);
        NotificationManagerCompat manager = NotificationManagerCompat.from(ctx);
        if (!manager.areNotificationsEnabled()) return;     // the landlord said no

        Intent open = new Intent(ctx, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pending = PendingIntent.getActivity(ctx, id, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setColor(ctx.getColor(R.color.td_accent))
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(pending)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        if (lines != null && lines.size() > 1) {
            NotificationCompat.InboxStyle style = new NotificationCompat.InboxStyle();
            for (String line : lines) style.addLine(line);
            b.setStyle(style);
        } else {
            b.setStyle(new NotificationCompat.BigTextStyle().bigText(text));
        }

        try {
            manager.notify(id, b.build());
        } catch (SecurityException ignored) {
            // notifications not allowed on this phone
        }
    }
}