package com.tenodesk.app;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class HomeFragment extends Fragment implements TenantsAdapter.Listener {

    private static final int[] WIDGET_IDS = {
            R.id.wStats, R.id.wChart, R.id.wAttention,
            R.id.wUpcoming, R.id.wVacant, R.id.wRecent, R.id.wBill};

    private TenantsAdapter adapter;
    private View root;
    private ScrollView scroll;
    private Anim.Reveal reveal;
    private ViewTreeObserver.OnGlobalLayoutListener layoutListener;
    private boolean firstBind = true;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.fragment_home, container, false);
        Context ctx = requireContext();
        scroll = root.findViewById(R.id.homeScroll);
        Shapes.homeArt(root);

        RecyclerView list = root.findViewById(R.id.homeTenants);
        list.setLayoutManager(new LinearLayoutManager(ctx));
        list.setNestedScrollingEnabled(false);
        adapter = new TenantsAdapter(this);
        list.setAdapter(adapter);

        // theme toggle (long-press sends a test reminder)
        ImageView toggle = root.findViewById(R.id.homeToggle);
        toggle.setImageResource(ThemeManager.isDark(ctx) ? R.drawable.ic_moon : R.drawable.ic_sun);
        toggle.setOnClickListener(v -> ThemeManager.setDark(ctx, !ThemeManager.isDark(ctx)));
        toggle.setOnLongClickListener(v -> {
            Reminders.runNow(ctx);
            android.widget.Toast.makeText(ctx, "Test reminder sent",
                    android.widget.Toast.LENGTH_SHORT).show();
            return true;
        });

        root.findViewById(R.id.homeGear).setOnClickListener(v ->
                startActivity(new Intent(ctx, SettingsActivity.class)));
        root.findViewById(R.id.homeAvatar).setOnClickListener(v ->
                startActivity(new Intent(ctx, SettingsActivity.class)));
        root.findViewById(R.id.homeName).setOnClickListener(v ->
                NameDialog.show(ctx, this::refresh));
        root.findViewById(R.id.homeSeeAll).setOnClickListener(v ->
                ((MainActivity) requireActivity()).openTab(1));

        // motion: sections glide in as they appear, the profile drifts slower than the page
        final Anim.Reveal r = new Anim.Reveal(scroll);
        reveal = r;
        r.add(root.findViewById(R.id.homeProfile));
        for (int id : WIDGET_IDS) r.add(root.findViewById(id));

        final View inner = root.findViewById(R.id.profileInner);
        final float fadeDistance = 280f * getResources().getDisplayMetrics().density;
        scroll.setOnScrollChangeListener((v, x, y, ox, oy) -> {
            inner.setTranslationY(y * 0.3f);
            inner.setAlpha(Math.max(0f, 1f - y / fadeDistance));
            r.check();
        });
        layoutListener = r::check;
        scroll.getViewTreeObserver().addOnGlobalLayoutListener(layoutListener);

        return root;
    }

    @Override
    public void onDestroyView() {
        if (scroll != null && layoutListener != null) {
            ViewTreeObserver vto = scroll.getViewTreeObserver();
            if (vto.isAlive()) vto.removeOnGlobalLayoutListener(layoutListener);
        }
        super.onDestroyView();
    }

    @Override
    public void onResume() {
        super.onResume();
        refresh();
    }

    private String greeting() {
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (hour < 12) return "Good morning";
        if (hour < 17) return "Good afternoon";
        return "Good evening";
    }

    private void number(TextView tv, long value, Anim.TextFormat fmt) {
        if (firstBind) Anim.countUp(tv, value, fmt);
        else tv.setText(fmt.format(value));
    }

    private void refresh() {
        Context ctx = requireContext();
        DashboardStats s = DashboardStats.load(ctx);

        // widgets the landlord switched on or off in Settings
        for (int i = 0; i < WIDGET_IDS.length; i++) {
            root.findViewById(WIDGET_IDS[i]).setVisibility(
                    HomeWidgets.isOn(ctx, HomeWidgets.KEYS[i]) ? View.VISIBLE : View.GONE);
        }

        // profile
        String name = AppPrefs.getLandlordName(ctx);
        ((TextView) root.findViewById(R.id.homeGreeting)).setText(greeting());
        ((TextView) root.findViewById(R.id.homeName)).setText(name);
        ProfilePhoto.bindAvatar((TextView) root.findViewById(R.id.homeAvatar), name);
        ((TextView) root.findViewById(R.id.homeDate)).setText(
                new SimpleDateFormat("EEEE, d MMMM", Locale.US).format(new Date()));
        number((TextView) root.findViewById(R.id.pTenants), s.tenantCount, v -> String.valueOf(v));
        number((TextView) root.findViewById(R.id.pRooms), s.roomCount, v -> String.valueOf(v));
        number((TextView) root.findViewById(R.id.pVacant), s.vacantCount, v -> String.valueOf(v));

        // stats
        number((TextView) root.findViewById(R.id.statCollected), s.collectedThisMonth, Money::compact);
        ((TextView) root.findViewById(R.id.statWeek)).setText(Money.format(s.weekTotal) + " this week");

        TextView overdue = root.findViewById(R.id.statOverdue);
        number(overdue, s.overdueCount, v -> String.valueOf(v));
        overdue.setTextColor(ctx.getColor(
                s.overdueCount > 0 ? R.color.td_overdue : R.color.td_text_primary));
        root.findViewById(R.id.cardOverdue).setBackgroundResource(
                s.overdueCount > 0 ? R.drawable.bg_card_urgent : R.drawable.bg_card);
        number((TextView) root.findViewById(R.id.statDueSoon), s.dueSoonCount, v -> String.valueOf(v));

        // chart
        ((BarChartView) root.findViewById(R.id.weekChart)).setData(s.week, s.weekLabels);
        ((TextView) root.findViewById(R.id.weekTotal)).setText(Money.format(s.weekTotal));

        // needs attention
        adapter.submit(s.topTenants);
        root.findViewById(R.id.homeEmpty).setVisibility(
                s.topTenants.isEmpty() ? View.VISIBLE : View.GONE);
        root.findViewById(R.id.homeSeeAll).setVisibility(
                s.topTenants.isEmpty() ? View.GONE : View.VISIBLE);

        // due in the next 7 days
        LinearLayout upcoming = root.findViewById(R.id.upcomingList);
        upcoming.removeAllViews();
        int n = 0;
        for (Tenant t : s.upcoming) {
            addRow(upcoming, t.name, t.roomNumber + "  \u00B7  " + Money.format(t.monthlyRent),
                    StatusUi.badgeText(t),
                    t.level == 2 ? R.color.td_overdue : R.color.td_accent, n++ == 0);
        }
        root.findViewById(R.id.upcomingEmpty).setVisibility(
                s.upcoming.isEmpty() ? View.VISIBLE : View.GONE);

        // vacant rooms
        LinearLayout vacant = root.findViewById(R.id.vacantList);
        vacant.removeAllViews();
        n = 0;
        for (Room r : s.vacantRooms) {
            if (n == 5) break;
            addRow(vacant, r.roomNumber, r.categoryName,
                    Money.format(r.monthlyPrice) + " / month", R.color.td_text_secondary, n++ == 0);
        }
        if (s.vacantRooms.size() > 5) {
            addRow(vacant, "+ " + (s.vacantRooms.size() - 5) + " more", "See the Rooms tab",
                    "", R.color.td_text_secondary, false);
        }
        root.findViewById(R.id.vacantEmpty).setVisibility(
                s.vacantRooms.isEmpty() ? View.VISIBLE : View.GONE);

        // recent payments
        LinearLayout recent = root.findViewById(R.id.recentList);
        recent.removeAllViews();
        n = 0;
        for (DashboardStats.RecentPayment p : s.recent) {
            addRow(recent, p.name,
                    "For " + RentEngine.label(p.month) + "  \u00B7  " + DateUi.pretty(p.date),
                    "+ " + Money.format(p.amount), R.color.td_paid, n++ == 0);
        }
        root.findViewById(R.id.recentEmpty).setVisibility(
                s.recent.isEmpty() ? View.VISIBLE : View.GONE);

        // latest bill
        LinearLayout bill = root.findViewById(R.id.billBox);
        bill.removeAllViews();
        if (s.latestBill != null) {
            Bill b = s.latestBill;
            addRow(bill, b.billType + " bill",
                    DateUi.pretty(b.date) + "  \u00B7  split between " + b.shareCount,
                    Money.format(b.splitAmount) + " each", R.color.td_accent, true);
        }
        root.findViewById(R.id.billEmpty).setVisibility(
                s.latestBill == null ? View.VISIBLE : View.GONE);

        firstBind = false;
    }

    private void addRow(LinearLayout box, String title, String sub, String value,
                        int valueColorRes, boolean first) {
        View row = LayoutInflater.from(requireContext()).inflate(R.layout.item_mini_row, box, false);
        ((TextView) row.findViewById(R.id.miniTitle)).setText(title);
        ((TextView) row.findViewById(R.id.miniSub)).setText(sub);
        TextView v = row.findViewById(R.id.miniValue);
        v.setText(value);
        v.setTextColor(requireContext().getColor(valueColorRes));
        row.findViewById(R.id.miniDivider).setVisibility(first ? View.GONE : View.VISIBLE);
        box.addView(row);
    }

    @Override
    public void onTenantClick(Tenant tenant) {
        Intent i = new Intent(requireContext(), TenantDetailActivity.class);
        i.putExtra("tenant_id", tenant.id);
        startActivity(i);
    }
}