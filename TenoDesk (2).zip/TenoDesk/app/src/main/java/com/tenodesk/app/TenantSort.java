package com.tenodesk.app;

import java.util.Collections;
import java.util.List;

public final class TenantSort {
    private TenantSort() {}

    /** Overdue first, then due soon, then active, then paid. */
    public static void sort(List<Tenant> list) {
        Collections.sort(list, (a, b) -> {
            int r = rank(a) - rank(b);
            if (r != 0) return r;
            if (a.daysLeft != b.daysLeft) return a.daysLeft - b.daysLeft;
            return a.name.compareToIgnoreCase(b.name);
        });
    }

    private static int rank(Tenant t) {
        if (RentEngine.OVERDUE.equals(t.status)) return 0;
        if (RentEngine.DUE.equals(t.status)) return 1;
        if (RentEngine.ACTIVE.equals(t.status)) return 2;
        return 3;
    }
}