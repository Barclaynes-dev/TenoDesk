package com.tenodesk.app;

import android.animation.ValueAnimator;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class Anim {
    private Anim() {}

    public interface TextFormat {
        String format(long value);
    }

    /** Numbers count up from zero. Skipped when motion is reduced. */
    public static void countUp(final TextView view, final long to, final TextFormat fmt) {
        if (Motion.isReduced(view.getContext()) || to <= 0) {
            view.setText(fmt.format(to));
            return;
        }
        ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
        a.setDuration(900);
        a.setInterpolator(new DecelerateInterpolator(2f));
        a.addUpdateListener(an ->
                view.setText(fmt.format((long) (to * (float) an.getAnimatedValue()))));
        a.start();
    }

    /** Sections start hidden and glide up the first time they scroll into view. */
    public static final class Reveal {
        private final ScrollView scroll;
        private final boolean enabled;
        private final float rise;
        private final List<View> views = new ArrayList<>();
        private final Set<View> done = new HashSet<>();

        public Reveal(ScrollView scroll) {
            this.scroll = scroll;
            this.enabled = !Motion.isReduced(scroll.getContext());
            this.rise = 36f * scroll.getResources().getDisplayMetrics().density;
        }

        public void add(View v) {
            views.add(v);
            if (enabled) {
                v.setAlpha(0f);
                v.setTranslationY(rise);
            }
        }

        public void check() {
            if (!enabled) return;
            int edge = scroll.getScrollY() + scroll.getHeight() - (int) (40 * scroll.getResources().getDisplayMetrics().density);
            int index = 0;
            for (View v : views) {
                if (done.contains(v) || v.getVisibility() != View.VISIBLE) continue;
                if (topInScroll(v) < edge) {
                    done.add(v);
                    v.animate().alpha(1f).translationY(0f)
                            .setStartDelay(index * 80L)
                            .setDuration(520)
                            .setInterpolator(new DecelerateInterpolator(2f))
                            .start();
                    index++;
                }
            }
        }

        private int topInScroll(View v) {
            int top = 0;
            View cur = v;
            while (cur != scroll && cur.getParent() instanceof View) {
                top += cur.getTop();
                cur = (View) cur.getParent();
            }
            return top;
        }
    }
}