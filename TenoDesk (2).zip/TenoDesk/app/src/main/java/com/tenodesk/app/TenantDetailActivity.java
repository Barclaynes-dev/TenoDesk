package com.tenodesk.app;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.util.List;

public class TenantDetailActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private long tenantId;
    private PaymentsAdapter adapter;
    private View paymentsEmpty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tenant_detail);
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        Ambient.attach(this);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.detailRoot), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        db = DatabaseHelper.get(this);
        tenantId = getIntent().getLongExtra("tenant_id", 0);

        findViewById(R.id.detailBack).setOnClickListener(v -> finish());

        RecyclerView list = findViewById(R.id.paymentsList);
        list.setLayoutManager(new LinearLayoutManager(this));
        adapter = new PaymentsAdapter();
        list.setAdapter(adapter);
        paymentsEmpty = findViewById(R.id.paymentsEmpty);

        refresh();
    }

    private String days(int n) {
        return n + (n == 1 ? " day" : " days");
    }

    private void refresh() {
        Tenant t = db.getTenant(tenantId);
        if (t == null) {          // moved out
            finish();
            return;
        }

        ((TextView) findViewById(R.id.detailName)).setText(t.name);
        ((TextView) findViewById(R.id.detailRoom)).setText(
                t.roomNumber + "  \u00B7  " + Money.format(t.monthlyRent) + " / month");
        StatusUi.apply((TextView) findViewById(R.id.detailBadge), t);

        // phone: tap to call
        TextView phone = findViewById(R.id.detailPhone);
        if (t.phone != null && !t.phone.isEmpty()) {
            phone.setText("Call  " + t.phone);
            phone.setTextColor(getColor(R.color.td_accent));
            phone.setOnClickListener(v -> startActivity(
                    new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(t.phone)))));
        } else {
            phone.setText("No phone number saved");
            phone.setTextColor(getColor(R.color.td_text_secondary));
            phone.setOnClickListener(null);
            phone.setClickable(false);
        }

        showAlert(t);

        // headline and detail line
        TextView headline = findViewById(R.id.detailOwed);
        TextView sub = findViewById(R.id.detailMonths);
        if (RentEngine.PAID.equals(t.status)) {
            headline.setText("Paid up");
            headline.setTextColor(getColor(R.color.td_paid));
            sub.setText("Next month starts " + DateUi.pretty(t.nextDueDate)
                    + " (in " + days(t.daysLeft) + ")");
        } else if (RentEngine.OVERDUE.equals(t.status)) {
            headline.setText("Overdue by " + days(-t.daysLeft));
            headline.setTextColor(getColor(R.color.td_overdue));
            StringBuilder sb = new StringBuilder("Owes " + Money.format(t.amountOwed()) + " for ");
            for (int i = 0; i < t.dueCount; i++) {
                if (i > 0) sb.append(", ");
                sb.append(RentEngine.label(t.unpaidMonths.get(i)));
            }
            sub.setText(sb.toString());
        } else {
            headline.setText(t.daysLeft == 0
                    ? "Rent is due today" : "Rent due " + DateUi.pretty(t.nextDueDate));
            headline.setTextColor(getColor(t.level == 2 ? R.color.td_overdue
                    : t.level == 1 ? R.color.td_accent : R.color.td_text_primary));
            sub.setText(Money.format(t.monthlyRent) + " for "
                    + RentEngine.label(t.unpaidMonths.get(0)) + "  \u00B7  " + StatusUi.badgeText(t));
        }

        // progress for the month
        ProgressBar bar = findViewById(R.id.detailProgress);
        bar.setProgress(t.progress);
        bar.setProgressTintList(ColorStateList.valueOf(StatusUi.levelColor(this, t)));
        ((TextView) findViewById(R.id.detailJoined)).setText("Joined " + DateUi.pretty(t.moveInDate));
        ((TextView) findViewById(R.id.detailDay)).setText(
                "Day " + t.dayOfCycle + " of " + t.cycleLength);

        // the tick
        TextView collect = findViewById(R.id.detailCollect);
        if (t.unpaidMonths.isEmpty()) {
            collect.setText("All paid up \u2713");
            collect.setEnabled(false);
            collect.setAlpha(0.5f);
            collect.setOnClickListener(null);
        } else {
            collect.setText("Mark " + RentEngine.label(t.unpaidMonths.get(0)) + " as paid");
            collect.setEnabled(true);
            collect.setAlpha(1f);
            collect.setOnClickListener(v -> {
                db.collectRent(t.id);
                refresh();
                v.performHapticFeedback(android.view.HapticFeedbackConstants.CONTEXT_CLICK);
                if (!Motion.isReduced(this)) {
                    View badge = findViewById(R.id.detailBadge);
                    badge.setScaleX(0.5f);
                    badge.setScaleY(0.5f);
                    badge.animate().scaleX(1f).scaleY(1f).setDuration(480)
                            .setInterpolator(new android.view.animation.OvershootInterpolator(3f)).start();
                }
            });
        }

        // history
        List<Payment> payments = db.getPayments(t.id);
        adapter.submit(payments);
        paymentsEmpty.setVisibility(payments.isEmpty() ? View.VISIBLE : View.GONE);

        View undo = findViewById(R.id.detailUndo);
        undo.setVisibility(payments.isEmpty() ? View.INVISIBLE : View.VISIBLE);
        undo.setOnClickListener(v -> {
            db.undoLastPayment(t.id);
            refresh();
        });

        findViewById(R.id.detailEdit).setOnClickListener(v -> showEditDialog(t));

        findViewById(R.id.detailMoveOut).setOnClickListener(v ->
                new MaterialAlertDialogBuilder(this)
                        .setTitle("Move " + t.name + " out?")
                        .setMessage("The room becomes empty. Their payment history is kept.")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Move out", (d, w) -> {
                            db.moveOutTenant(t.id);
                            finish();
                        })
                        .show());
    }

    /** The "almost due" alert: gold from 10 days, red from 3 days, until marked paid. */
    private void showAlert(Tenant t) {
        View alert = findViewById(R.id.detailAlert);
        if (t.level == 0) {
            alert.setVisibility(View.GONE);
            return;
        }
        alert.setVisibility(View.VISIBLE);
        alert.setBackgroundResource(t.level == 2 ? R.drawable.bg_alert_urgent : R.drawable.bg_alert_warn);
        StatusUi.styleExclaim((TextView) findViewById(R.id.detailAlertIcon), t);

        String first = t.name.trim().split(" ")[0];
        String message;
        if (RentEngine.OVERDUE.equals(t.status)) {
            message = first + "'s rent is overdue by " + days(-t.daysLeft)
                    + ". Collect it, then tap Mark as paid.";
        } else if (t.daysLeft == 0) {
            message = first + "'s rent is due today. Collect it, then tap Mark as paid.";
        } else if (t.level == 2) {
            message = first + "'s rent is due in " + days(t.daysLeft)
                    + ". Collect it, then tap Mark as paid.";
        } else {
            message = first + "'s monthly payment is almost due: " + days(t.daysLeft)
                    + " left (" + DateUi.pretty(t.nextDueDate) + ").";
        }
        ((TextView) findViewById(R.id.detailAlertText)).setText(message);
    }

    private void showEditDialog(Tenant t) {
        View view = getLayoutInflater().inflate(R.layout.dialog_add_tenant, null);
        view.findViewById(R.id.addRoomGroup).setVisibility(View.GONE);
        EditText name = view.findViewById(R.id.addName);
        EditText phone = view.findViewById(R.id.addPhone);
        TextView dateView = view.findViewById(R.id.addDate);
        name.setText(t.name);
        phone.setText(t.phone);

        final String[] date = {t.moveInDate};
        dateView.setText(DateUi.pretty(date[0]));
        dateView.setOnClickListener(x -> DateUi.showPicker(this, date[0], picked -> {
            date[0] = picked;
            dateView.setText(DateUi.pretty(picked));
        }));

        AlertDialog dialog = new MaterialAlertDialogBuilder(this)
                .setTitle("Edit details")
                .setView(view)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", null)
                .create();
        dialog.show();

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(x -> {
            String n = name.getText().toString().trim();
            if (n.isEmpty()) {
                name.setError("Enter the tenant's name");
                return;
            }
            db.updateTenant(t.id, n, phone.getText().toString().trim(), t.roomId, date[0]);
            dialog.dismiss();
            refresh();
        });
    }
}