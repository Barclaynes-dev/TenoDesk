package com.tenodesk.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

import java.util.Arrays;

public class BarChartView extends View {

    private long[] values = new long[0];
    private String[] labels = new String[0];
    private float progress = 1f;
    private ValueAnimator animator;

    private final Paint barPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint highlightPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint valuePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    private int secondary;
    private int accent;

    public BarChartView(Context context) {
        super(context);
        init();
    }

    public BarChartView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public BarChartView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        secondary = getContext().getColor(R.color.td_text_secondary);
        accent = getContext().getColor(R.color.td_accent);

        barPaint.setColor(secondary);
        barPaint.setAlpha(60);
        highlightPaint.setColor(accent);

        labelPaint.setTextAlign(Paint.Align.CENTER);
        labelPaint.setTextSize(sp(11));
        valuePaint.setTextAlign(Paint.Align.CENTER);
        valuePaint.setTextSize(sp(10));
        valuePaint.setColor(secondary);
    }

    public void setData(long[] newValues, String[] newLabels) {
        boolean changed = !Arrays.equals(values, newValues);
        values = newValues;
        labels = newLabels;

        if (animator != null) animator.cancel();
        if (changed && !Motion.isReduced(getContext())) {
            progress = 0f;
            animator = ValueAnimator.ofFloat(0f, 1f);
            animator.setStartDelay(250);
            animator.setDuration(750);
            animator.setInterpolator(new DecelerateInterpolator(2f));
            animator.addUpdateListener(a -> {
                progress = (float) a.getAnimatedValue();
                invalidate();
            });
            animator.start();
        } else {
            progress = 1f;
            invalidate();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        if (animator != null) animator.cancel();
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int n = values.length;
        if (n == 0) return;

        float w = getWidth();
        float h = getHeight();
        float labelArea = dp(24);
        float chartH = h - labelArea;
        float gap = dp(10);
        float barW = (w - gap * (n - 1)) / n;
        float radius = dp(8);

        long max = 1;
        for (long v : values) max = Math.max(max, v);

        valuePaint.setAlpha((int) (255 * progress));

        for (int i = 0; i < n; i++) {
            boolean today = (i == n - 1);
            float left = i * (barW + gap);
            float minBar = values[i] == 0 ? dp(6) : dp(12);
            float fullBar = values[i] == 0
                    ? dp(6)
                    : Math.max(dp(12), values[i] / (float) max * (chartH - dp(20)));
            float barH = minBar + (fullBar - minBar) * progress;
            float top = chartH - barH;

            rect.set(left, top, left + barW, chartH);
            canvas.drawRoundRect(rect, radius, radius, today ? highlightPaint : barPaint);

            if (values[i] > 0) {
                canvas.drawText(Money.compact(values[i]), left + barW / 2f, top - dp(4), valuePaint);
            }

            labelPaint.setColor(today ? accent : secondary);
            if (i < labels.length) {
                canvas.drawText(labels[i], left + barW / 2f, h - dp(6), labelPaint);
            }
        }
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    private float sp(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v,
                getResources().getDisplayMetrics());
    }
}