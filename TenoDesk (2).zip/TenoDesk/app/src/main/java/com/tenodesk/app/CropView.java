package com.tenodesk.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

/** Shows a picture under a circle. Drag to move it, pinch to zoom. */
public class CropView extends View {

    private static final float MAX_ZOOM = 5f;

    private Bitmap bitmap;
    private final Matrix matrix = new Matrix();
    private final float[] values = new float[9];
    private final Paint bitmapPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Paint dimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path dimPath = new Path();

    private float cx, cy, radius, coverScale = 1f;
    private ScaleGestureDetector scaleDetector;
    private GestureDetector panDetector;

    public CropView(Context context) {
        super(context);
        init(context);
    }

    public CropView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public CropView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        dimPaint.setColor(0xB3000000);
        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setStrokeWidth(2f * getResources().getDisplayMetrics().density);
        ringPaint.setColor(context.getColor(R.color.td_accent));

        scaleDetector = new ScaleGestureDetector(context,
                new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                    @Override
                    public boolean onScale(ScaleGestureDetector d) {
                        matrix.postScale(d.getScaleFactor(), d.getScaleFactor(),
                                d.getFocusX(), d.getFocusY());
                        constrain();
                        invalidate();
                        return true;
                    }
                });

        panDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDown(MotionEvent e) {
                return true;
            }

            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float dx, float dy) {
                if (scaleDetector.isInProgress()) return false;
                matrix.postTranslate(-dx, -dy);
                constrain();
                invalidate();
                return true;
            }
        });
    }

    public void setBitmap(Bitmap b) {
        bitmap = b;
        if (getWidth() > 0 && getHeight() > 0) setup();
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (bitmap != null) setup();
    }

    /** The picture starts centred and just big enough to fill the circle. */
    private void setup() {
        cx = getWidth() / 2f;
        cy = getHeight() * 0.46f;
        radius = Math.min(getWidth(), getHeight()) * 0.40f;

        float bw = bitmap.getWidth();
        float bh = bitmap.getHeight();
        coverScale = Math.max(2f * radius / bw, 2f * radius / bh);

        matrix.reset();
        matrix.postScale(coverScale, coverScale);
        matrix.postTranslate(cx - bw * coverScale / 2f, cy - bh * coverScale / 2f);
        constrain();
    }

    /** Keeps the circle always inside the picture, and the zoom within limits. */
    private void constrain() {
        if (bitmap == null) return;

        matrix.getValues(values);
        float scale = values[Matrix.MSCALE_X];
        if (scale < coverScale) {
            float f = coverScale / scale;
            matrix.postScale(f, f, cx, cy);
        } else if (scale > coverScale * MAX_ZOOM) {
            float f = coverScale * MAX_ZOOM / scale;
            matrix.postScale(f, f, cx, cy);
        }

        matrix.getValues(values);
        float s = values[Matrix.MSCALE_X];
        float left = values[Matrix.MTRANS_X];
        float top = values[Matrix.MTRANS_Y];
        float w = bitmap.getWidth() * s;
        float h = bitmap.getHeight() * s;

        float dx = 0f;
        float dy = 0f;
        if (left > cx - radius) dx = (cx - radius) - left;
        else if (left + w < cx + radius) dx = (cx + radius) - (left + w);
        if (top > cy - radius) dy = (cy - radius) - top;
        else if (top + h < cy + radius) dy = (cy + radius) - (top + h);
        if (dx != 0f || dy != 0f) matrix.postTranslate(dx, dy);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event);
        panDetector.onTouchEvent(event);
        return true;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (bitmap == null) return;
        canvas.drawBitmap(bitmap, matrix, bitmapPaint);

        dimPath.reset();
        dimPath.setFillType(Path.FillType.EVEN_ODD);
        dimPath.addRect(0f, 0f, getWidth(), getHeight(), Path.Direction.CW);
        dimPath.addCircle(cx, cy, radius, Path.Direction.CW);
        canvas.drawPath(dimPath, dimPaint);
        canvas.drawCircle(cx, cy, radius, ringPaint);
    }

    /** The square the circle covers, as a picture of the size you ask for. */
    public Bitmap crop(int outSize) {
        Bitmap result = Bitmap.createBitmap(outSize, outSize, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        Matrix m = new Matrix(matrix);
        m.postTranslate(-(cx - radius), -(cy - radius));
        float s = outSize / (2f * radius);
        m.postScale(s, s);
        canvas.drawBitmap(bitmap, m, bitmapPaint);
        return result;
    }
}