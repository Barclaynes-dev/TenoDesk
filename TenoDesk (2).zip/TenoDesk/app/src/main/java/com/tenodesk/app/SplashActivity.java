package com.tenodesk.app;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SplashActivity extends AppCompatActivity {

    private static final String WORD = "TenoDesk";

    // the loading words that play first, in the spot where TenoDesk appears
    private static final String[] LOADING = {"RENT", "TENANTS", "UTILITIES"};

    // pace of the loading words, in milliseconds (make these bigger for slower)
    private static final long WORDS_START = 600;   // wait before the first word
    private static final long W_IN = 380;          // fade in
    private static final long W_HOLD = 220;        // stay
    private static final long W_OUT = 340;         // fade out
    private static final long W_GAP = 60;          // pause before the next word

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable goNext = this::openNextScreen;

    private LinearLayout row;
    private TextView loadWord;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_splash);

        row = findViewById(R.id.wordRow);
        lockRowHeight();
        animateMark();

        long goNextAt;
        if (Motion.isReduced(this)) {
            showTenoDesk(450);                       // no loading words, straight to TenoDesk
            goNextAt = 2000;
        } else {
            long tenoStart = WORDS_START + LOADING.length * (W_IN + W_HOLD + W_OUT + W_GAP);
            startLoadingWords();
            handler.postDelayed(() -> showTenoDesk(120), tenoStart);
            goNextAt = tenoStart + 1700;
        }
        handler.postDelayed(goNext, goNextAt);
    }

    // ---- the mark: unchanged -------------------------------------------------

    private void animateMark() {
        ImageView mark = findViewById(R.id.splashMark);
        mark.setAlpha(0f);
        mark.setScaleX(0.7f);
        mark.setScaleY(0.7f);
        mark.animate()
                .alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(550)
                .setInterpolator(new DecelerateInterpolator(1.6f))
                .start();
    }

    /** Keeps the row as tall as TenoDesk will be, so nothing jumps when the words are swapped. */
    private void lockRowHeight() {
        TextView probe = new TextView(this);
        probe.setTextSize(TypedValue.COMPLEX_UNIT_SP, 34);
        probe.setTypeface(Typeface.DEFAULT_BOLD);
        probe.setText("Teno");
        probe.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        row.setMinimumHeight(probe.getMeasuredHeight());
    }

    // ---- loading words: one by one, fade in and out, same spot ---------------

    private void startLoadingWords() {
        loadWord = new TextView(this);
        loadWord.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        loadWord.setTypeface(Typeface.DEFAULT_BOLD);
        loadWord.setLetterSpacing(0.32f);
        loadWord.setTextColor(ContextCompat.getColor(this, R.color.td_text_secondary));
        loadWord.setAlpha(0f);
        row.addView(loadWord);
        showWord(0, WORDS_START);
    }

    private void showWord(int index, long delay) {
        if (loadWord == null || index >= LOADING.length) return;

        float rise = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, 8, getResources().getDisplayMetrics());
        loadWord.setText(LOADING[index]);
        loadWord.setAlpha(0f);
        loadWord.setTranslationY(rise);

        loadWord.animate()
                .alpha(1f).translationY(0f)
                .setStartDelay(delay)
                .setDuration(W_IN)
                .setInterpolator(new DecelerateInterpolator(1.6f))
                .withEndAction(() -> {
                    if (loadWord == null) return;
                    loadWord.animate()
                            .alpha(0f)
                            .setStartDelay(W_HOLD)
                            .setDuration(W_OUT)
                            .withEndAction(() -> showWord(index + 1, W_GAP))
                            .start();
                })
                .start();
    }

    // ---- the TenoDesk intro: same motion as before ---------------------------

    private void showTenoDesk(long baseDelay) {
        if (loadWord != null) {
            loadWord.animate().cancel();
            loadWord = null;
        }
        row.removeAllViews();

        float rise = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, 18, getResources().getDisplayMetrics());
        int white = ContextCompat.getColor(this, R.color.td_text_primary);
        int gold = ContextCompat.getColor(this, R.color.td_accent);

        for (int i = 0; i < WORD.length(); i++) {
            TextView letter = new TextView(this);
            letter.setText(String.valueOf(WORD.charAt(i)));
            letter.setTextSize(TypedValue.COMPLEX_UNIT_SP, 34);
            letter.setTypeface(Typeface.DEFAULT_BOLD);
            letter.setTextColor(i < 4 ? white : gold);   // "Teno" + "Desk"
            letter.setAlpha(0f);
            letter.setTranslationY(rise);
            row.addView(letter);

            letter.animate()
                    .alpha(1f).translationY(0f)
                    .setStartDelay(baseDelay + i * 55L)
                    .setDuration(420)
                    .setInterpolator(new DecelerateInterpolator(1.8f))
                    .start();
        }
    }

    private void openNextScreen() {
        Class<?> next = AppPrefs.isOnboardingDone(this)
                ? MainActivity.class
                : OnboardingActivity.class;
        startActivity(new Intent(this, next));
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (loadWord != null) loadWord.animate().cancel();
        super.onDestroy();
    }
}