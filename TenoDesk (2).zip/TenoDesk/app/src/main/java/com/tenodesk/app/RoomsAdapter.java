package com.tenodesk.app;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class RoomsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public interface Listener {
        void onCategoryClick(Category category);
        void onAddRooms(Category category);
        void onRoomClick(Room room);
    }

    private static final int TYPE_HEADER = 0;
    private static final int TYPE_ROOM = 1;

    private final List<Object> items = new ArrayList<>();
    private final Listener listener;

    public RoomsAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submit(List<Object> newItems) {
        items.clear();
        items.addAll(newItems);
        notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        return items.get(position) instanceof Category ? TYPE_HEADER : TYPE_ROOM;
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        if (viewType == TYPE_HEADER) {
            return new HeaderVH(inflater.inflate(R.layout.item_room_header, parent, false));
        }
        return new RoomVH(inflater.inflate(R.layout.item_room, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Object item = items.get(position);

        if (holder instanceof HeaderVH) {
            HeaderVH h = (HeaderVH) holder;
            Category c = (Category) item;
            h.name.setText(c.name);
            h.sub.setText(Money.format(c.monthlyPrice) + " / month  \u00B7  "
                    + c.roomCount + (c.roomCount == 1 ? " room" : " rooms"));
            h.itemView.setOnClickListener(v -> listener.onCategoryClick(c));
            h.add.setOnClickListener(v -> listener.onAddRooms(c));
        } else {
            RoomVH h = (RoomVH) holder;
            Room r = (Room) item;
            h.number.setText(r.roomNumber);
            if (r.isVacant()) {
                h.sub.setText("Empty \u00B7 tap to add a tenant");
                h.sub.setTextColor(h.itemView.getContext().getColor(R.color.td_accent));
                h.badge.setVisibility(View.GONE);
            } else {
                h.sub.setText(r.tenantName);
                h.sub.setTextColor(h.itemView.getContext().getColor(R.color.td_text_secondary));
                StatusUi.apply(h.badge, r.status);
            }
            h.itemView.setOnClickListener(v -> listener.onRoomClick(r));
        }
    }

    static class HeaderVH extends RecyclerView.ViewHolder {
        final TextView name, sub, add;

        HeaderVH(@NonNull View v) {
            super(v);
            name = v.findViewById(R.id.hdrName);
            sub = v.findViewById(R.id.hdrSub);
            add = v.findViewById(R.id.hdrAdd);
        }
    }

    static class RoomVH extends RecyclerView.ViewHolder {
        final TextView number, sub, badge;

        RoomVH(@NonNull View v) {
            super(v);
            number = v.findViewById(R.id.roomNumber);
            sub = v.findViewById(R.id.roomSub);
            badge = v.findViewById(R.id.roomBadge);
        }
    }
}