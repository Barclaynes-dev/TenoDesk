package com.tenodesk.app;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

import java.util.Random;

public class GrainView extends View {

    private final Paint paint = new Paint();

    public GrainView(Context context) {
        super(context);
        init();
    }

    public GrainView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        // one small noise tile, repeated across the screen; drawn once, never animated
        int size = 160;
        int[] pixels = new int[size * size];
        Random random = new Random(7);
        for (int i = 0; i < pixels.length; i++) {
            int g = random.nextBoolean() ? 255 : 0;          // light and dark specks
            pixels[i] = Color.argb(6 + random.nextInt(10), g, g, g);
        }
        Bitmap tile = Bitmap.createBitmap(pixels, size, size, Bitmap.Config.ARGB_8888);
        paint.setShader(new BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT));

        boolean night = (getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        setAlpha(night ? 1f : 0.5f);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawPaint(paint);
    }
}