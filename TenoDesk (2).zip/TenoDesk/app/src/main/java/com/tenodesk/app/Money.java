package com.tenodesk.app;

import java.text.NumberFormat;
import java.util.Locale;

public final class Money {
    private Money() {}

    /** 150000 gives "UGX 150,000" */
    public static String format(long value) {
        return "UGX " + NumberFormat.getIntegerInstance(Locale.US).format(value);
    }

    /** 1800000 gives "1.8M", 150000 gives "150K" */
    public static String compact(long value) {
        if (value >= 1_000_000) {
            return String.format(Locale.US, "%.1fM", value / 1_000_000.0).replace(".0M", "M");
        }
        if (value >= 1_000) {
            return String.format(Locale.US, "%.1fK", value / 1_000.0).replace(".0K", "K");
        }
        return String.valueOf(value);
    }
}