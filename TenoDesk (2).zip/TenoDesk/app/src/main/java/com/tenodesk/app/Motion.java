package com.tenodesk.app;

import android.content.Context;
import android.provider.Settings;

public final class Motion {
    private Motion() {}

    /**
     * True when animations should be skipped: the "Reduce motion" switch in Settings,
     * or the phone's own "Remove animations" accessibility setting.
     * Battery saver no longer turns the animations off.
     */
    public static boolean isReduced(Context c) {
        if (c.getSharedPreferences("tenodesk_prefs", Context.MODE_PRIVATE)
                .getBoolean("reduce_motion", false)) {
            return true;
        }
        float scale = Settings.Global.getFloat(
                c.getContentResolver(), Settings.Global.ANIMATOR_DURATION_SCALE, 1f);
        return scale == 0f;
    }
}