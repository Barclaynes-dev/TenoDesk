package com.tenodesk.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

import androidx.core.graphics.ColorUtils;
import androidx.core.graphics.PathParser;

import java.util.ArrayList;
import java.util.List;

/** Draws vector shapes that trace themselves like a pen, then fill in. */
public class DrawView extends View {

    private static final int STROKE = 0;   // an open line that is traced
    private static final int FILL = 1;     // a shape: outline is traced, then it fills
    private static final int AREA = 2;     // a shape that simply fades in

    private static final class Layer {
        int type;
        Path path;
        PathMeasure measure;
        float total;
        int color;
        float width;
        float from, to;
        float fillFrom, fillTo;
    }

    private final List<Layer> layers = new ArrayList<>();
    private final float vw, vh;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path piece = new Path();
    private float t = 1f;
    private ValueAnimator animator;

    public DrawView(Context context, float viewportW, float viewportH) {
        super(context);
        vw = viewportW;
        vh = viewportH;
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
    }

    private DrawView add(int type, String d, int color, float width, float from, float to) {
        Layer l = new Layer();
        l.type = type;
        l.path = PathParser.createPathFromPathData(d);
        l.measure = new PathMeasure(l.path, false);
        float sum = 0f;
        do {
            sum += l.measure.getLength();
        } while (l.measure.nextContour());
        l.total = Math.max(sum, 0.001f);
        l.color = color;
        l.width = width;
        l.from = from;
        l.to = to;
        if (type == AREA) {
            l.fillFrom = from;
            l.fillTo = to;
        } else {
            l.fillFrom = Math.max(0f, to - 0.1f);
            l.fillTo = Math.min(1f, to + 0.2f);
        }
        layers.add(l);
        return this;
    }

    /** A line traced between timeline positions from and to (0 to 1). */
    public DrawView stroke(String d, int color, float width, float from, float to) {
        return add(STROKE, d, color, width, from, to);
    }

    /** A shape whose outline is traced between from and to, then filled in. */
    public DrawView fill(String d, int color, float outlineWidth, float from, float to) {
        return add(FILL, d, color, outlineWidth, from, to);
    }

    /** A shape that fades in between from and to. */
    public DrawView area(String d, int color, float from, float to) {
        return add(AREA, d, color, 0f, from, to);
    }

    public void setColor(int color) {
        for (Layer l : layers) l.color = color;
        invalidate();
    }

    public void showComplete() {
        cancel();
        t = 1f;
        invalidate();
    }

    public void play(long delayMs, long durationMs) {
        cancel();
        t = 0f;
        invalidate();
        animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setStartDelay(delayMs);
        animator.setDuration(durationMs);
        animator.setInterpolator(new DecelerateInterpolator(1.2f));
        animator.addUpdateListener(a -> {
            t = (float) a.getAnimatedValue();
            invalidate();
        });
        animator.start();
    }

    private void cancel() {
        if (animator != null) {
            animator.cancel();
            animator = null;
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        cancel();
        t = 1f;
        super.onDetachedFromWindow();
    }

    private static float frac(float t, float from, float to) {
        if (to <= from) return t >= to ? 1f : 0f;
        return Math.max(0f, Math.min(1f, (t - from) / (to - from)));
    }

    private int withAlpha(int color, float a) {
        return ColorUtils.setAlphaComponent(color, (int) (Color.alpha(color) * a));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (getWidth() == 0 || getHeight() == 0) return;
        canvas.save();
        canvas.scale(getWidth() / vw, getHeight() / vh);

        for (Layer l : layers) {
            if (l.type == STROKE) {
                float f = frac(t, l.from, l.to);
                if (f > 0f) drawTrace(canvas, l, f, 1f);

            } else if (l.type == FILL) {
                float f = frac(t, l.from, l.to);
                float fa = frac(t, l.fillFrom, l.fillTo);
                if (f > 0f && fa < 1f) drawTrace(canvas, l, f, 1f - fa);
                if (fa > 0f) drawFill(canvas, l, fa);

            } else {
                float fa = frac(t, l.fillFrom, l.fillTo);
                if (fa > 0f) drawFill(canvas, l, fa);
            }
        }
        canvas.restore();
    }

    private void drawFill(Canvas canvas, Layer l, float alpha) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(withAlpha(l.color, alpha));
        canvas.drawPath(l.path, paint);
    }

    private void drawTrace(Canvas canvas, Layer l, float f, float alpha) {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(l.width);
        paint.setColor(withAlpha(l.color, alpha));

        if (f >= 1f) {
            canvas.drawPath(l.path, paint);
            return;
        }
        l.measure.setPath(l.path, false);
        float remaining = l.total * f;
        piece.reset();
        do {
            float len = l.measure.getLength();
            if (remaining <= 0f) break;
            l.measure.getSegment(0f, Math.min(len, remaining), piece, true);
            remaining -= len;
        } while (l.measure.nextContour());
        canvas.drawPath(piece, paint);
    }
}