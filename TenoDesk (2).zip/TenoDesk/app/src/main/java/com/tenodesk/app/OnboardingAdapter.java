package com.tenodesk.app;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class OnboardingAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_INFO = 0;
    private static final int TYPE_NAME = 1;

    private final String[] titles = {
            "Every shilling,\ntracked.",
            "Know who\nhas paid.",
            "Split bills\nfairly.",
            "Never miss\na due date."};

    private final String[] descs = {
            "Manage tenants, rent and shared utility bills, all from your phone, even offline.",
            "See who is almost due or overdue at a glance, and mark rent as paid in one tap.",
            "Divide water or electricity between your tenants, and send each share by SMS.",
            "Get reminders as rent gets close, on the day, and every morning while it is overdue."};

    private String name = "";
    private boolean typing = false;
    private EditText nameField;
    private ImageView nameIcon;
    private TextView nameDesc;
    private TextView nameHint;
    private ScrollView nameScroll;
    private Runnable onDone;
    private Runnable onPhotoClick;

    public void setOnDone(Runnable onDone) {
        this.onDone = onDone;
    }

    public void setOnPhotoClick(Runnable onPhotoClick) {
        this.onPhotoClick = onPhotoClick;
    }

    /** Called after a photo was chosen, so the circle shows it. */
    public void refreshPhoto() {
        notifyItemChanged(titles.length);
    }

    public String getName() {
        return name.trim();
    }

    public void showNameError(String message) {
        if (nameField != null) {
            nameField.setError(message);
            nameField.requestFocus();
        }
    }

    /** While the keyboard is open the name page shows only the title and the box. */
    public void setTyping(boolean on) {
        typing = on;
        applyTyping();
    }

    private void applyTyping() {
        int v = typing ? View.GONE : View.VISIBLE;
        if (nameIcon != null) nameIcon.setVisibility(v);
        if (nameHint != null) nameHint.setVisibility(v);
        if (nameDesc != null) nameDesc.setVisibility(v);
        if (typing && nameScroll != null) {
            nameScroll.post(() -> nameScroll.fullScroll(View.FOCUS_DOWN));
        }
    }

    @Override
    public int getItemViewType(int position) {
        return position < titles.length ? TYPE_INFO : TYPE_NAME;
    }

    @Override
    public int getItemCount() {
        return titles.length + 1;   // the slides, plus the name page
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        if (viewType == TYPE_NAME) {
            return new NameVH(inflater.inflate(R.layout.item_onboarding_name, parent, false));
        }
        return new InfoVH(inflater.inflate(R.layout.item_onboarding, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof InfoVH) {
            InfoVH h = (InfoVH) holder;
            h.hero.removeAllViews();
            h.hero.addView(HeroArt.build(h.itemView.getContext(), position),
                    new FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            h.title.setText(titles[position]);
            h.desc.setText(descs[position]);
        } else {
            NameVH h = (NameVH) holder;
            nameField = h.field;
            nameIcon = h.icon;
            nameDesc = h.desc;
            nameHint = h.hint;
            nameScroll = h.scroll;
            if (!h.field.getText().toString().equals(name)) h.field.setText(name);

            ProfilePhoto.bindIcon(h.icon);
            h.hint.setText(ProfilePhoto.exists(h.itemView.getContext())
                    ? "Change photo" : "Add a photo (optional)");
            applyTyping();
        }
    }

    static class InfoVH extends RecyclerView.ViewHolder {
        final FrameLayout hero;
        final TextView title, desc;

        InfoVH(@NonNull View v) {
            super(v);
            hero = v.findViewById(R.id.obHero);
            title = v.findViewById(R.id.obTitle);
            desc = v.findViewById(R.id.obDesc);
        }
    }

    class NameVH extends RecyclerView.ViewHolder {
        final EditText field;
        final ImageView icon;
        final TextView desc;
        final TextView hint;
        final ScrollView scroll;

        NameVH(@NonNull View v) {
            super(v);
            field = v.findViewById(R.id.obNameInput);
            icon = v.findViewById(R.id.obIcon);
            desc = v.findViewById(R.id.obDesc);
            hint = v.findViewById(R.id.obPhotoHint);
            scroll = v.findViewById(R.id.obNameScroll);

            View.OnClickListener pick = x -> {
                if (onPhotoClick != null) onPhotoClick.run();
            };
            icon.setOnClickListener(pick);
            hint.setOnClickListener(pick);

            field.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int a, int b, int c) {}

                @Override
                public void onTextChanged(CharSequence s, int a, int b, int c) {}

                @Override
                public void afterTextChanged(Editable s) {
                    name = s.toString();
                }
            });
            field.setOnEditorActionListener((tv, actionId, event) -> {
                if (actionId == EditorInfo.IME_ACTION_DONE && onDone != null) {
                    onDone.run();
                    return true;
                }
                return false;
            });
        }
    }
}