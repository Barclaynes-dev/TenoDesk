package com.tenodesk.app;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class BillsAdapter extends RecyclerView.Adapter<BillsAdapter.VH> {

    public interface Listener {
        void onBillClick(Bill bill);
    }

    private final List<Bill> items = new ArrayList<>();
    private final Listener listener;

    public BillsAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submit(List<Bill> newItems) {
        items.clear();
        items.addAll(newItems);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_bill, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Bill b = items.get(position);
        h.type.setText(b.billType);
        h.total.setText(Money.format(b.totalAmount));
        h.sub.setText(DateUi.pretty(b.date) + "  \u00B7  split between " + b.shareCount
                + (b.shareCount == 1 ? " tenant" : " tenants"));
        h.each.setText(Money.format(b.splitAmount) + " each");
        h.itemView.setOnClickListener(v -> listener.onBillClick(b));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        final TextView type, total, sub, each;

        VH(@NonNull View v) {
            super(v);
            type = v.findViewById(R.id.billType);
            total = v.findViewById(R.id.billTotal);
            sub = v.findViewById(R.id.billSub);
            each = v.findViewById(R.id.billEach);
        }
    }
}