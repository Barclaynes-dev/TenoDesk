package com.tenodesk.app;

import android.content.Context;

import androidx.work.Data;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.Calendar;
import java.util.concurrent.TimeUnit;

public final class Reminders {
    private static final String WORK_NAME = "daily_rent_check";

    private Reminders() {}

    /** Safe to call every time the app starts; it never creates duplicates. */
    public static void schedule(Context ctx) {
        PeriodicWorkRequest request = new PeriodicWorkRequest.Builder(
                ReminderWorker.class, 24, TimeUnit.HOURS)
                .setInitialDelay(millisUntil(8, 0), TimeUnit.MILLISECONDS)
                .build();
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
                WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request);
    }

    /** Runs the check right now and shows every reminder, so you can see how they look. */
    public static void runNow(Context ctx) {
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(ReminderWorker.class)
                .setInputData(new Data.Builder().putBoolean("force", true).build())
                .build();
        WorkManager.getInstance(ctx).enqueue(request);
    }

    private static long millisUntil(int hour, int minute) {
        Calendar now = Calendar.getInstance();
        Calendar target = Calendar.getInstance();
        target.set(Calendar.HOUR_OF_DAY, hour);
        target.set(Calendar.MINUTE, minute);
        target.set(Calendar.SECOND, 0);
        target.set(Calendar.MILLISECOND, 0);
        if (!target.after(now)) target.add(Calendar.DAY_OF_MONTH, 1);
        return target.getTimeInMillis() - now.getTimeInMillis();
    }
}