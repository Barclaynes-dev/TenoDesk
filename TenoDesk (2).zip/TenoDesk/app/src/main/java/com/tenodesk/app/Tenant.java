package com.tenodesk.app;

import java.util.ArrayList;
import java.util.List;

public class Tenant {
    public long id;
    public String name;
    public String phone;
    public long roomId;
    public String roomNumber;
    public String categoryName;
    public long monthlyRent;

    public String moveInDate;                        // "2026-10-09"
    public String moveInMonth;                       // month of the first counted cycle
    public List<String> unpaidMonths = new ArrayList<>();   // started months not yet paid, oldest first
    public int dueCount;                             // how many of those are already due

    public String status;                            // PAID, ACTIVE, DUE or OVERDUE
    public int level;                                // 0 normal, 1 almost due, 2 urgent or overdue
    public int daysLeft;                             // days to the due date (negative = overdue)
    public String nextDueDate;
    public int progress;                             // 0 to 100
    public int dayOfCycle;
    public int cycleLength;

    public long amountOwed() {
        return monthlyRent * dueCount;
    }
}