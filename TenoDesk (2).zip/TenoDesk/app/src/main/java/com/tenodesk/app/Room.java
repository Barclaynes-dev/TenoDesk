package com.tenodesk.app;

public class Room {
    public long id;
    public long categoryId;
    public String roomNumber;
    public String categoryName;
    public long monthlyPrice;
    public long tenantId;        // 0 means vacant
    public String tenantName;
    public String status;        // PAID, DUE, OVERDUE (only when occupied)
    public long owed;

    public boolean isVacant() {
        return tenantId == 0;
    }
}