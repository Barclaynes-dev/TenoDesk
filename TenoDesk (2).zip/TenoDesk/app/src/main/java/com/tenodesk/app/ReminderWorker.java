package com.tenodesk.app;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.util.ArrayList;
import java.util.List;

public class ReminderWorker extends Worker {

    public ReminderWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        boolean force = getInputData().getBoolean("force", false);   // true for the test button
        Context ctx = getApplicationContext();
        DatabaseHelper db = DatabaseHelper.get(ctx);
        SharedPreferences prefs = ctx.getSharedPreferences("tenodesk_reminders", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = prefs.edit();

        List<Tenant> tenants = db.getTenants();
        TenantSort.sort(tenants);

        // 1. rent milestones: 10 days, 3 days, due today, then every day while overdue
        List<String> lines = new ArrayList<>();
        int needAttention = 0;
        for (Tenant t : tenants) {
            if (t.level >= 1) needAttention++;

            String milestone = milestoneOf(t);
            if (milestone == null) continue;

            String key = "ms_" + t.id;
            String stamp = t.nextDueDate + "|" + milestone;
            if (force || !stamp.equals(prefs.getString(key, ""))) {
                lines.add(t.name + "  \u00B7  " + t.roomNumber + ": " + StatusUi.badgeText(t));
                if (!force) ed.putString(key, stamp);
            }
        }

        if (!lines.isEmpty()) {
            String title = lines.size() == 1 ? "Rent reminder" : lines.size() + " rent reminders";
            String text = lines.size() == 1 ? lines.get(0) : "Tap to see who needs attention";
            Notifier.show(ctx, 1, title, text, lines);
        } else if (force) {
            Notifier.show(ctx, 1, "All on track", "No rent needs your attention today.", null);
        }

        // 2. last week of the month, once a month
        if (force || RentEngine.isLastWeekOfMonth()) {
            String key = "lastweek_" + RentEngine.currentMonth();
            if (force || !prefs.getBoolean(key, false)) {
                if (needAttention > 0) {
                    Notifier.show(ctx, 2, "Last week of the month",
                            "Time to collect rent. " + needAttention
                                    + (needAttention == 1 ? " tenant has" : " tenants have")
                                    + " rent due soon or overdue.", null);
                } else if (force) {
                    Notifier.show(ctx, 2, "Last week of the month",
                            "Time to collect rent. (This is how the monthly reminder looks.)", null);
                }
                if (!force) ed.putBoolean(key, true);
            }
        }

        ed.apply();
        return Result.success();
    }

    /** null means no reminder is needed for this tenant today. */
    private String milestoneOf(Tenant t) {
        if (RentEngine.OVERDUE.equals(t.status)) return "OD" + RentEngine.today();
        if (!RentEngine.DUE.equals(t.status)) return null;
        if (t.daysLeft == 0) return "D0";
        if (t.daysLeft <= RentEngine.URGENT_DAYS) return "D3";
        return "D10";
    }
}