package com.tenodesk.app;

import android.app.DatePickerDialog;
import android.content.Context;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class DateUi {
    private DateUi() {}

    public interface OnPicked {
        void onPicked(String ymd);
    }

    /** "2026-10-09" gives "9 Oct 2026" */
    public static String pretty(String ymd) {
        return reformat(ymd, "d MMM yyyy");
    }

    /** "2026-10-09" gives "9 Oct" */
    public static String shortPretty(String ymd) {
        return reformat(ymd, "d MMM");
    }

    private static String reformat(String ymd, String pattern) {
        try {
            Date d = new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(ymd);
            return new SimpleDateFormat(pattern, Locale.US).format(d);
        } catch (ParseException e) {
            return ymd;
        }
    }

    /** Opens a calendar. Dates in the future are not allowed. */
    public static void showPicker(Context ctx, String currentYmd, OnPicked callback) {
        int y = Integer.parseInt(currentYmd.substring(0, 4));
        int m = Integer.parseInt(currentYmd.substring(5, 7)) - 1;
        int d = Integer.parseInt(currentYmd.substring(8, 10));
        DatePickerDialog dialog = new DatePickerDialog(ctx,
                (view, year, month, day) -> callback.onPicked(
                        String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day)),
                y, m, d);
        dialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        dialog.show();
    }
}