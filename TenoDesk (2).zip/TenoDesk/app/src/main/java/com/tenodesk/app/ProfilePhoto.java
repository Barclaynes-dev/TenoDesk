package com.tenodesk.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.RoundedBitmapDrawable;
import androidx.core.graphics.drawable.RoundedBitmapDrawableFactory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Locale;

public final class ProfilePhoto {
    private ProfilePhoto() {}

    private static final int MAX_SIDE = 1280;

    private static Bitmap cache;
    private static long cacheStamp = -1;

    public static File sourceFile(Context c) {
        return new File(c.getFilesDir(), "crop_source.jpg");
    }

    public static File photoFile(Context c) {
        return new File(c.getFilesDir(), "profile.jpg");
    }

    public static boolean exists(Context c) {
        return photoFile(c).exists();
    }

    public static void remove(Context c) {
        photoFile(c).delete();
        cache = null;
    }

    public static Bitmap load(Context c) {
        File f = photoFile(c);
        if (!f.exists()) return null;
        long stamp = f.lastModified();
        if (cache == null || stamp != cacheStamp) {
            cache = BitmapFactory.decodeFile(f.getAbsolutePath());
            cacheStamp = stamp;
        }
        return cache;
    }

    /** Reads the chosen picture, shrinks it, fixes its rotation and keeps a working copy for the crop screen. */
    public static boolean saveSource(Context c, Uri uri) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (InputStream in = c.getContentResolver().openInputStream(uri)) {
                if (in == null) return false;
                BitmapFactory.decodeStream(in, null, bounds);
            }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false;

            int sample = 1;
            int longest = Math.max(bounds.outWidth, bounds.outHeight);
            while (longest / (sample * 2) >= MAX_SIDE) sample *= 2;

            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            Bitmap bmp;
            try (InputStream in = c.getContentResolver().openInputStream(uri)) {
                if (in == null) return false;
                bmp = BitmapFactory.decodeStream(in, null, opts);
            }
            if (bmp == null) return false;

            float scale = Math.min(1f, MAX_SIDE / (float) Math.max(bmp.getWidth(), bmp.getHeight()));
            int rotation = rotationOf(c, uri);
            Bitmap fixed = bmp;
            if (scale < 1f || rotation != 0) {
                Matrix m = new Matrix();
                if (scale < 1f) m.postScale(scale, scale);
                if (rotation != 0) m.postRotate(rotation);
                fixed = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
            }
            try (FileOutputStream out = new FileOutputStream(sourceFile(c))) {
                fixed.compress(Bitmap.CompressFormat.JPEG, 92, out);
            }
            return true;
        } catch (Exception | OutOfMemoryError e) {
            return false;
        }
    }

    private static int rotationOf(Context c, Uri uri) {
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            if (in == null) return 0;
            ExifInterface exif = new ExifInterface(in);
            int o = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL);
            if (o == ExifInterface.ORIENTATION_ROTATE_90) return 90;
            if (o == ExifInterface.ORIENTATION_ROTATE_180) return 180;
            if (o == ExifInterface.ORIENTATION_ROTATE_270) return 270;
            return 0;
        } catch (Exception e) {
            return 0;
        }
    }

    /** Saves the final square picture. It is shown as a circle everywhere. */
    public static void saveCropped(Context c, Bitmap bitmap) {
        try (FileOutputStream out = new FileOutputStream(photoFile(c))) {
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
        } catch (Exception ignored) {
            // nothing more to do
        }
        cache = null;
        sourceFile(c).delete();
    }

    /** A round photo inside a thin gold ring. */
    public static Drawable circle(Context c, Bitmap bitmap, int ringDp) {
        RoundedBitmapDrawable photo = RoundedBitmapDrawableFactory.create(c.getResources(), bitmap);
        photo.setCircular(true);
        photo.setAntiAlias(true);
        Drawable ring = ContextCompat.getDrawable(c, R.drawable.bg_avatar);
        LayerDrawable layers = new LayerDrawable(new Drawable[]{ring, photo});
        int inset = (int) (ringDp * c.getResources().getDisplayMetrics().density);
        layers.setLayerInset(1, inset, inset, inset, inset);
        return layers;
    }

    /** The avatar on Home: the photo if there is one, otherwise the first letter of the name. */
    public static void bindAvatar(TextView view, String name) {
        Context c = view.getContext();
        Bitmap b = load(c);
        if (b != null) {
            view.setText("");
            view.setBackground(circle(c, b, 3));
        } else {
            view.setText(name == null || name.isEmpty()
                    ? "T" : name.substring(0, 1).toUpperCase(Locale.US));
            view.setBackgroundResource(R.drawable.bg_avatar);
        }
    }

    /** The picker circle on the intro's name page. */
    public static void bindIcon(ImageView view) {
        Context c = view.getContext();
        Bitmap b = load(c);
        if (b != null) {
            view.setPadding(0, 0, 0, 0);
            view.setBackground(null);
            view.setImageDrawable(circle(c, b, 3));
        } else {
            int p = (int) (28 * c.getResources().getDisplayMetrics().density);
            view.setPadding(p, p, p, p);
            view.setBackgroundResource(R.drawable.bg_icon_tile);
            view.setImageResource(R.drawable.ic_ob_people);
        }
    }
}