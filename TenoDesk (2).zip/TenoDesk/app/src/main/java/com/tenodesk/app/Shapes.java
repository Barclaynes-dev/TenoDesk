package com.tenodesk.app;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

public final class Shapes {
    private Shapes() {}

    /** True right after the app is opened; the Home card art uses it once, then clears it. */
    public static boolean homePending = true;

    private static final String[] NAV = {
            // home
            "M10,20v-6h4v6h5v-8h3L12,3 2,12h3v8z",
            // tenants
            "M12,12c2.21,0 4,-1.79 4,-4s-1.79,-4 -4,-4 -4,1.79 -4,4 1.79,4 4,4zM12,14c-2.67,0 -8,1.34 -8,4v2h16v-2c0,-2.66 -5.33,-4 -8,-4z",
            // rooms
            "M3,13h8V3H3v10zM3,21h8v-6H3v6zM13,21h8V11h-8v10zM13,3v6h8V3h-8z",
            // bills
            "M18,17H6v-2h12V17zM18,13H6v-2h12V13zM18,9H6V7h12V9zM3,22l1.5,-1.5L6,22l1.5,-1.5L9,22l1.5,-1.5L12,22l1.5,-1.5L15,22l1.5,-1.5L18,22l1.5,-1.5L21,22V2l-1.5,1.5L18,2l-1.5,1.5L15,2l-1.5,1.5L12,2l-1.5,1.5L9,2L7.5,3.5L6,2L4.5,3.5L3,2V22z"};

    /** One bottom-bar icon that can draw itself. */
    public static DrawView navIcon(Context c, int index) {
        return new DrawView(c, 24f, 24f)
                .fill(NAV[index], c.getColor(R.color.td_text_secondary), 1.1f, 0f, 0.7f);
    }

    /** Swaps the three Home card pictures for versions that draw themselves. */
    public static void homeArt(View root) {
        Context c = root.getContext();
        boolean play = homePending && !Motion.isReduced(c);
        homePending = false;

        ViewGroup stats = root.findViewById(R.id.wStats);
        if (stats == null || stats.getChildCount() < 2) return;

        // 1. the growth line on the gold card
        ViewGroup goldCard = (ViewGroup) stats.getChildAt(0);
        DrawView growth = new DrawView(c, 160f, 100f)
                .area("M0,100 L0,78 L30,62 L55,70 L90,34 L120,46 L150,12 L150,100 Z",
                        0x26000000, 0.45f, 1f)
                .stroke("M0,78 L30,62 L55,70 L90,34 L120,46 L150,12",
                        0x66000000, 3f, 0f, 0.7f)
                .area("M150,12 m-6,0 a6,6 0 1,0 12,0 a6,6 0 1,0 -12,0",
                        0x66000000, 0.7f, 0.95f);
        swap(goldCard, growth, 1f, play, 750);

        // 2. the alert circle on the Overdue card
        DrawView alert = new DrawView(c, 60f, 60f)
                .stroke("M30,30 m-24,0 a24,24 0 1,0 48,0 a24,24 0 1,0 -48,0",
                        c.getColor(R.color.td_overdue), 4f, 0f, 0.65f)
                .stroke("M30,16 L30,34", c.getColor(R.color.td_overdue), 5f, 0.55f, 0.85f)
                .area("M30,43 m-3,0 a3,3 0 1,0 6,0 a3,3 0 1,0 -6,0",
                        c.getColor(R.color.td_overdue), 0.8f, 1f);
        swap((ViewGroup) root.findViewById(R.id.cardOverdue), alert, 0.35f, play, 900);

        // 3. the clock on the Due soon card
        DrawView clock = new DrawView(c, 60f, 60f)
                .stroke("M30,30 m-24,0 a24,24 0 1,0 48,0 a24,24 0 1,0 -48,0",
                        c.getColor(R.color.td_accent), 4f, 0f, 0.65f)
                .stroke("M30,16 L30,31 L40,37", c.getColor(R.color.td_accent), 4f, 0.55f, 1f);
        swap((ViewGroup) root.findViewById(R.id.cardDueSoon), clock, 0.35f, play, 1000);
    }

    private static void swap(ViewGroup parent, DrawView art, float alpha, boolean play, long delay) {
        if (parent == null || parent.getChildCount() == 0) return;
        View old = parent.getChildAt(0);
        if (!(old instanceof ImageView)) return;           // already swapped

        ViewGroup.LayoutParams lp = old.getLayoutParams();   // same size and position as before
        parent.removeViewAt(0);
        art.setAlpha(alpha);
        parent.addView(art, 0, lp);

        if (play) art.play(delay, 1100);
        else art.showComplete();
    }
}