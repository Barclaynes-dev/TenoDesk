package com.tenodesk.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DB_NAME = "tenodesk.db";
    private static final int DB_VERSION = 2;

    private static DatabaseHelper instance;

    public static synchronized DatabaseHelper get(Context context) {
        if (instance == null) instance = new DatabaseHelper(context);
        return instance;
    }

    public DatabaseHelper(Context context) {
        super(context.getApplicationContext(), DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE categories ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "name TEXT NOT NULL,"
                + "monthly_price INTEGER NOT NULL)");

        db.execSQL("CREATE TABLE rooms ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "category_id INTEGER NOT NULL REFERENCES categories(id),"
                + "room_number TEXT NOT NULL UNIQUE)");

        db.execSQL("CREATE TABLE tenants ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "name TEXT NOT NULL,"
                + "phone TEXT,"
                + "room_id INTEGER REFERENCES rooms(id),"
                + "move_in_month TEXT NOT NULL,"
                + "move_in_date TEXT,"
                + "active INTEGER NOT NULL DEFAULT 1)");

        db.execSQL("CREATE TABLE payments ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,"
                + "amount INTEGER NOT NULL,"
                + "date_paid TEXT NOT NULL,"
                + "month_covered TEXT NOT NULL)");

        db.execSQL("CREATE TABLE utility_bills ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "bill_type TEXT NOT NULL,"
                + "total_amount INTEGER NOT NULL,"
                + "date TEXT NOT NULL,"
                + "split_amount INTEGER NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            // tenants now remember the exact day they moved in
            db.execSQL("ALTER TABLE tenants ADD COLUMN move_in_date TEXT");
            db.execSQL("UPDATE tenants SET move_in_date = move_in_month || '-01'");
        }
    }

    private int count(String sql, String... args) {
        Cursor c = getReadableDatabase().rawQuery(sql, args);
        try {
            return c.moveToFirst() ? c.getInt(0) : 0;
        } finally {
            c.close();
        }
    }

    // ---------------------------------------------------------------- categories

    public long addCategory(String name, long monthlyPrice) {
        ContentValues v = new ContentValues();
        v.put("name", name);
        v.put("monthly_price", monthlyPrice);
        return getWritableDatabase().insert("categories", null, v);
    }

    public void updateCategory(long id, String name, long monthlyPrice) {
        ContentValues v = new ContentValues();
        v.put("name", name);
        v.put("monthly_price", monthlyPrice);
        getWritableDatabase().update("categories", v, "id=?", new String[]{String.valueOf(id)});
    }

    /** Only deletes a category that has no rooms. Returns false if it still has rooms. */
    public boolean deleteCategory(long id) {
        if (count("SELECT COUNT(*) FROM rooms WHERE category_id=?", String.valueOf(id)) > 0) {
            return false;
        }
        getWritableDatabase().delete("categories", "id=?", new String[]{String.valueOf(id)});
        return true;
    }

    public boolean categoryNameExists(String name, long excludeId) {
        return count("SELECT COUNT(*) FROM categories WHERE LOWER(name) = LOWER(?) AND id <> ?",
                name, String.valueOf(excludeId)) > 0;
    }

    public List<Category> getCategories() {
        List<Category> list = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT c.id, c.name, c.monthly_price, "
                        + "(SELECT COUNT(*) FROM rooms r WHERE r.category_id = c.id) "
                        + "FROM categories c ORDER BY c.name", null);
        try {
            while (c.moveToNext()) {
                Category cat = new Category();
                cat.id = c.getLong(0);
                cat.name = c.getString(1);
                cat.monthlyPrice = c.getLong(2);
                cat.roomCount = c.getInt(3);
                list.add(cat);
            }
        } finally {
            c.close();
        }
        return list;
    }

    // --------------------------------------------------------------------- rooms

    /** Creates "Single room 1", "Single room 2" and so on. Returns how many were created. */
    public int addRoomsAuto(long categoryId, String baseName, int howMany) {
        SQLiteDatabase db = getWritableDatabase();
        int created = 0;
        int number = 1;
        db.beginTransaction();
        try {
            while (created < howMany && number < 10000) {
                ContentValues v = new ContentValues();
                v.put("category_id", categoryId);
                v.put("room_number", baseName + " " + number);
                if (db.insertWithOnConflict("rooms", null, v, SQLiteDatabase.CONFLICT_IGNORE) != -1) {
                    created++;
                }
                number++;
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        return created;
    }

    /** Returns false if another room already has that name. */
    public boolean renameRoom(long roomId, String newName) {
        if (count("SELECT COUNT(*) FROM rooms WHERE room_number = ? AND id <> ?",
                newName, String.valueOf(roomId)) > 0) {
            return false;
        }
        ContentValues v = new ContentValues();
        v.put("room_number", newName);
        getWritableDatabase().update("rooms", v, "id=?", new String[]{String.valueOf(roomId)});
        return true;
    }

    public List<Room> getRooms() {
        List<Room> list = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT r.id, r.category_id, r.room_number, c.name, c.monthly_price, "
                        + "IFNULL(t.id, 0), t.name "
                        + "FROM rooms r JOIN categories c ON c.id = r.category_id "
                        + "LEFT JOIN tenants t ON t.room_id = r.id AND t.active = 1 "
                        + "ORDER BY c.name, r.id", null);
        try {
            while (c.moveToNext()) {
                Room room = new Room();
                room.id = c.getLong(0);
                room.categoryId = c.getLong(1);
                room.roomNumber = c.getString(2);
                room.categoryName = c.getString(3);
                room.monthlyPrice = c.getLong(4);
                room.tenantId = c.getLong(5);
                room.tenantName = c.getString(6);
                list.add(room);
            }
        } finally {
            c.close();
        }
        return list;
    }

    public List<Room> getVacantRooms() {
        List<Room> vacant = new ArrayList<>();
        for (Room r : getRooms()) {
            if (r.isVacant()) vacant.add(r);
        }
        return vacant;
    }

    /** Only deletes a vacant room. */
    public boolean deleteRoom(long roomId) {
        if (count("SELECT COUNT(*) FROM tenants WHERE room_id=? AND active=1", String.valueOf(roomId)) > 0) {
            return false;
        }
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("UPDATE tenants SET room_id = NULL WHERE room_id = ?", new Object[]{roomId});
        db.delete("rooms", "id=?", new String[]{String.valueOf(roomId)});
        return true;
    }

    // ------------------------------------------------------------------- tenants

    /** moveInDate looks like "2026-10-09". Returns -1 if the room is already occupied. */
    public long addTenant(String name, String phone, long roomId, String moveInDate) {
        if (count("SELECT COUNT(*) FROM tenants WHERE room_id=? AND active=1", String.valueOf(roomId)) > 0) {
            return -1;
        }
        ContentValues v = new ContentValues();
        v.put("name", name);
        v.put("phone", phone);
        v.put("room_id", roomId);
        v.put("move_in_date", moveInDate);
        v.put("move_in_month", RentEngine.firstCycleMonth(moveInDate, RentEngine.today()));
        v.put("active", 1);
        return getWritableDatabase().insert("tenants", null, v);
    }

    /** Returns false if the chosen room is occupied by someone else. */
    public boolean updateTenant(long id, String name, String phone, long roomId, String moveInDate) {
        if (count("SELECT COUNT(*) FROM tenants WHERE room_id=? AND active=1 AND id<>?",
                String.valueOf(roomId), String.valueOf(id)) > 0) {
            return false;
        }
        ContentValues v = new ContentValues();
        v.put("name", name);
        v.put("phone", phone);
        v.put("room_id", roomId);
        v.put("move_in_date", moveInDate);
        v.put("move_in_month", RentEngine.firstCycleMonth(moveInDate, RentEngine.today()));
        getWritableDatabase().update("tenants", v, "id=?", new String[]{String.valueOf(id)});
        return true;
    }

    /** The tenant leaves; the room becomes vacant. Payment history is kept. */
    public void moveOutTenant(long id) {
        ContentValues v = new ContentValues();
        v.put("active", 0);
        getWritableDatabase().update("tenants", v, "id=?", new String[]{String.valueOf(id)});
    }

    private static final String TENANT_SELECT =
            "SELECT t.id, t.name, t.phone, IFNULL(t.room_id, 0), IFNULL(r.room_number, ''), "
                    + "IFNULL(c.name, ''), IFNULL(c.monthly_price, 0), t.move_in_month, t.move_in_date "
                    + "FROM tenants t LEFT JOIN rooms r ON r.id = t.room_id "
                    + "LEFT JOIN categories c ON c.id = r.category_id "
                    + "WHERE t.active = 1 ";

    private Tenant readTenant(Cursor c) {
        Tenant t = new Tenant();
        t.id = c.getLong(0);
        t.name = c.getString(1);
        t.phone = c.getString(2);
        t.roomId = c.getLong(3);
        t.roomNumber = c.getString(4);
        t.categoryName = c.getString(5);
        t.monthlyRent = c.getLong(6);
        t.moveInMonth = c.getString(7);
        String date = c.getString(8);
        t.moveInDate = (date == null || date.isEmpty()) ? t.moveInMonth + "-01" : date;
        return t;
    }

    private void fillStatus(Tenant t) {
        RentEngine.evaluate(t, getPaidMonths(t.id));
    }

    public List<Tenant> getTenants() {
        List<Tenant> list = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery(TENANT_SELECT + "ORDER BY t.name", null);
        try {
            while (c.moveToNext()) list.add(readTenant(c));
        } finally {
            c.close();
        }
        for (Tenant t : list) fillStatus(t);
        return list;
    }

    public Tenant getTenant(long id) {
        Tenant t = null;
        Cursor c = getReadableDatabase().rawQuery(
                TENANT_SELECT + "AND t.id = ?", new String[]{String.valueOf(id)});
        try {
            if (c.moveToFirst()) t = readTenant(c);
        } finally {
            c.close();
        }
        if (t != null) fillStatus(t);
        return t;
    }

    // ------------------------------------------------------------------ payments

    public Set<String> getPaidMonths(long tenantId) {
        Set<String> set = new HashSet<>();
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT DISTINCT month_covered FROM payments WHERE tenant_id=?",
                new String[]{String.valueOf(tenantId)});
        try {
            while (c.moveToNext()) set.add(c.getString(0));
        } finally {
            c.close();
        }
        return set;
    }

    /**
     * The tick. Pays the OLDEST unpaid month at the tenant's monthly rent.
     * Returns false if the tenant is already fully paid up.
     */
    public boolean collectRent(long tenantId) {
        Tenant t = getTenant(tenantId);
        if (t == null || t.unpaidMonths.isEmpty()) return false;

        ContentValues v = new ContentValues();
        v.put("tenant_id", tenantId);
        v.put("amount", t.monthlyRent);
        v.put("date_paid", RentEngine.today());
        v.put("month_covered", t.unpaidMonths.get(0));
        getWritableDatabase().insert("payments", null, v);
        return true;
    }

    /** Undo for a mistaken tick: removes the most recent payment of this tenant. */
    public void undoLastPayment(long tenantId) {
        getWritableDatabase().execSQL(
                "DELETE FROM payments WHERE id = "
                        + "(SELECT MAX(id) FROM payments WHERE tenant_id = ?)",
                new Object[]{tenantId});
    }

    public List<Payment> getPayments(long tenantId) {
        List<Payment> list = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT id, tenant_id, amount, date_paid, month_covered "
                        + "FROM payments WHERE tenant_id=? ORDER BY id DESC",
                new String[]{String.valueOf(tenantId)});
        try {
            while (c.moveToNext()) {
                Payment p = new Payment();
                p.id = c.getLong(0);
                p.tenantId = c.getLong(1);
                p.amount = c.getLong(2);
                p.datePaid = c.getString(3);
                p.monthCovered = c.getString(4);
                list.add(p);
            }
        } finally {
            c.close();
        }
        return list;
    }
}