package com.tenodesk.app;

import android.app.Activity;
import android.content.Intent;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

/** Gallery, then crop, then save. Create it inside onCreate. */
public final class PhotoPicker {

    private final ActivityResultLauncher<Intent> cropLauncher;
    private final ActivityResultLauncher<String> pickLauncher;

    public PhotoPicker(ComponentActivity activity, Runnable onChanged) {
        cropLauncher = activity.registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) onChanged.run();
                });

        pickLauncher = activity.registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri == null) return;      // the person closed the gallery
                    if (ProfilePhoto.saveSource(activity, uri)) {
                        cropLauncher.launch(new Intent(activity, CropActivity.class));
                    } else {
                        Toast.makeText(activity,
                                "That picture could not be opened. Please try another one.",
                                Toast.LENGTH_LONG).show();
                    }
                });
    }

    public void start() {
        pickLauncher.launch("image/*");
    }
}