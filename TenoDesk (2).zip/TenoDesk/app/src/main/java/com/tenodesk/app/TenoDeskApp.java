package com.tenodesk.app;

import android.app.Application;

public class TenoDeskApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        ThemeManager.apply(this);   // restores the saved theme before any screen opens
    }
}