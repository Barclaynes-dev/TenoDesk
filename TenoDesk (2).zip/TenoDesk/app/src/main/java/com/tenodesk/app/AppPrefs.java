package com.tenodesk.app;

import android.content.Context;
import android.content.SharedPreferences;

public final class AppPrefs {
    private static final String PREFS = "tenodesk_prefs";
    private static final String KEY_ONBOARDING_DONE = "onboarding_done";
    private static final String KEY_NAME = "landlord_name";

    private AppPrefs() {}

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static boolean isOnboardingDone(Context c) {
        return prefs(c).getBoolean(KEY_ONBOARDING_DONE, false);
    }

    public static void setOnboardingDone(Context c) {
        prefs(c).edit().putBoolean(KEY_ONBOARDING_DONE, true).apply();
    }

    public static String getLandlordName(Context c) {
        return prefs(c).getString(KEY_NAME, "Landlord");
    }

    public static void setLandlordName(Context c, String name) {
        prefs(c).edit().putString(KEY_NAME, name).apply();
    }
}