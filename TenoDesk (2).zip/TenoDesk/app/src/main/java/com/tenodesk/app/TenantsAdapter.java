package com.tenodesk.app;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class TenantsAdapter extends RecyclerView.Adapter<TenantsAdapter.VH> {

    public interface Listener {
        void onTenantClick(Tenant tenant);
    }

    private final List<Tenant> items = new ArrayList<>();
    private final Listener listener;

    public TenantsAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submit(List<Tenant> newItems) {
        items.clear();
        items.addAll(newItems);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_tenant, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Tenant t = items.get(position);
        Context ctx = h.itemView.getContext();

        h.name.setText(t.name);
        h.sub.setText(t.roomNumber + "  \u00B7  " + Money.format(t.monthlyRent) + " / month");

        StatusUi.apply(h.badge, t);
        StatusUi.styleCard(h.itemView, t);
        StatusUi.styleExclaim(h.exclaim, t);

        h.bar.setProgress(t.progress);
        h.bar.setProgressTintList(ColorStateList.valueOf(StatusUi.levelColor(ctx, t)));

        h.left.setText("Joined " + DateUi.pretty(t.moveInDate)
                + "  \u00B7  Day " + t.dayOfCycle + " of " + t.cycleLength);
        h.right.setText((RentEngine.PAID.equals(t.status) ? "Renews " : "Due ")
                + DateUi.shortPretty(t.nextDueDate));

        h.itemView.setOnClickListener(v -> listener.onTenantClick(t));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        final TextView name, sub, badge, exclaim, left, right;
        final ProgressBar bar;

        VH(@NonNull View v) {
            super(v);
            name = v.findViewById(R.id.tenantName);
            sub = v.findViewById(R.id.tenantSub);
            badge = v.findViewById(R.id.tenantBadge);
            exclaim = v.findViewById(R.id.tenantExclaim);
            left = v.findViewById(R.id.tenantInfoLeft);
            right = v.findViewById(R.id.tenantInfoRight);
            bar = v.findViewById(R.id.tenantProgress);
        }
    }
}