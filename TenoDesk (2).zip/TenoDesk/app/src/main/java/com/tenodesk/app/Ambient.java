package com.tenodesk.app;

import android.app.Activity;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

public final class Ambient {
    private Ambient() {}

    /** Call right after setContentView. Puts the glowing background behind the screen. */
    public static void attach(Activity a) {
        ViewGroup content = a.findViewById(android.R.id.content);
        if (content.getChildCount() == 0) return;

        View original = content.getChildAt(0);
        content.removeView(original);
        original.setBackgroundColor(Color.TRANSPARENT);

        int match = ViewGroup.LayoutParams.MATCH_PARENT;
        FrameLayout frame = new FrameLayout(a);
        frame.addView(new AmbientBackground(a), new FrameLayout.LayoutParams(match, match));
        frame.addView(new GrainView(a), new FrameLayout.LayoutParams(match, match));
        frame.addView(original, new FrameLayout.LayoutParams(match, match));
        content.addView(frame, new FrameLayout.LayoutParams(match, match));
    }
}