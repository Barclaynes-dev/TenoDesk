package com.tenodesk.app;

public class BillShare {
    public long id;
    public long billId;
    public long tenantId;
    public String tenantName;
    public String phone;
    public String roomNumber;
}