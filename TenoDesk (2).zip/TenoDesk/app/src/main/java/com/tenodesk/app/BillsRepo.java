package com.tenodesk.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class BillsRepo {

    private final DatabaseHelper helper;

    public BillsRepo(Context context) {
        helper = DatabaseHelper.get(context);
    }

    /** Opens the database and makes sure the "who was in this bill" table exists. */
    private SQLiteDatabase db() {
        SQLiteDatabase db = helper.getWritableDatabase();
        db.execSQL("CREATE TABLE IF NOT EXISTS bill_shares ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "bill_id INTEGER NOT NULL REFERENCES utility_bills(id) ON DELETE CASCADE,"
                + "tenant_id INTEGER NOT NULL,"
                + "tenant_name TEXT NOT NULL,"
                + "phone TEXT,"
                + "room_number TEXT)");
        return db;
    }

    /** Each person's share, rounded UP to the nearest UGX 100 so the full bill is always covered. */
    public static long splitAmount(long total, int people) {
        if (people <= 0) return 0;
        long exact = (total + people - 1) / people;     // rounds up to a whole shilling
        return ((exact + 99) / 100) * 100;
    }

    /** True when the shares add up to a little more than the bill. */
    public static boolean wasRounded(long total, int people) {
        return people > 0 && splitAmount(total, people) * people != total;
    }

    public long addBill(String type, long total, String date, List<Tenant> tenants) {
        SQLiteDatabase db = db();
        long split = splitAmount(total, tenants.size());
        long id = -1;
        db.beginTransaction();
        try {
            ContentValues v = new ContentValues();
            v.put("bill_type", type);
            v.put("total_amount", total);
            v.put("date", date);
            v.put("split_amount", split);
            id = db.insert("utility_bills", null, v);

            for (Tenant t : tenants) {
                ContentValues s = new ContentValues();
                s.put("bill_id", id);
                s.put("tenant_id", t.id);
                s.put("tenant_name", t.name);
                s.put("phone", t.phone);
                s.put("room_number", t.roomNumber);
                db.insert("bill_shares", null, s);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        return id;
    }

    public List<Bill> getBills() {
        List<Bill> list = new ArrayList<>();
        Cursor c = db().rawQuery(
                "SELECT b.id, b.bill_type, b.total_amount, b.date, b.split_amount, "
                        + "(SELECT COUNT(*) FROM bill_shares s WHERE s.bill_id = b.id) "
                        + "FROM utility_bills b ORDER BY b.date DESC, b.id DESC", null);
        try {
            while (c.moveToNext()) {
                Bill b = new Bill();
                b.id = c.getLong(0);
                b.billType = c.getString(1);
                b.totalAmount = c.getLong(2);
                b.date = c.getString(3);
                b.splitAmount = c.getLong(4);
                b.shareCount = c.getInt(5);
                list.add(b);
            }
        } finally {
            c.close();
        }
        return list;
    }

    public List<BillShare> getShares(long billId) {
        List<BillShare> list = new ArrayList<>();
        Cursor c = db().rawQuery(
                "SELECT id, bill_id, tenant_id, tenant_name, phone, room_number "
                        + "FROM bill_shares WHERE bill_id = ? ORDER BY tenant_name",
                new String[]{String.valueOf(billId)});
        try {
            while (c.moveToNext()) {
                BillShare s = new BillShare();
                s.id = c.getLong(0);
                s.billId = c.getLong(1);
                s.tenantId = c.getLong(2);
                s.tenantName = c.getString(3);
                s.phone = c.getString(4);
                s.roomNumber = c.getString(5);
                list.add(s);
            }
        } finally {
            c.close();
        }
        return list;
    }

    public void deleteBill(long billId) {
        SQLiteDatabase db = db();
        String[] args = {String.valueOf(billId)};
        db.delete("bill_shares", "bill_id=?", args);
        db.delete("utility_bills", "id=?", args);
    }
}