package com.tenodesk.app;

import android.content.Context;

public final class HomeWidgets {
    private HomeWidgets() {}

    public static final String[] KEYS = {
            "w_stats", "w_chart", "w_attention", "w_upcoming", "w_vacant", "w_recent", "w_bill"};

    public static final String[] TITLES = {
            "Stats cards", "Collections chart", "Needs attention",
            "Due in the next 7 days", "Vacant rooms", "Recent payments", "Latest bill"};

    public static final String[] SUBTITLES = {
            "Money collected, overdue and due soon",
            "Bar chart of the last 7 days",
            "The tenants who need you first",
            "Who is about to be due this week",
            "Empty rooms and their rent",
            "The last payments you recorded",
            "Your most recent utility bill split"};

    public static boolean isOn(Context c, String key) {
        return c.getSharedPreferences("tenodesk_prefs", Context.MODE_PRIVATE).getBoolean(key, true);
    }

    public static void set(Context c, String key, boolean on) {
        c.getSharedPreferences("tenodesk_prefs", Context.MODE_PRIVATE)
                .edit().putBoolean(key, on).apply();
    }
}