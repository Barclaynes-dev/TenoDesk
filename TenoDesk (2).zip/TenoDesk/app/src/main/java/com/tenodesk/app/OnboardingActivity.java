package com.tenodesk.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

public class OnboardingActivity extends AppCompatActivity {

    private ViewPager2 pager;
    private TextView skip, cont;
    private LinearLayout dotsRow;
    private GradientBackdrop backdrop;
    private View[] dots;
    private OnboardingAdapter adapter;
    private PhotoPicker photoPicker;
    private int count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_onboarding);

        pager = findViewById(R.id.obPager);
        skip = findViewById(R.id.obSkip);
        cont = findViewById(R.id.obContinue);
        dotsRow = findViewById(R.id.obDots);
        backdrop = findViewById(R.id.backdrop);

        View content = findViewById(R.id.onboardingRoot);
        ViewCompat.setOnApplyWindowInsetsListener(content, (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.ime());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);

            // keyboard open? make room: hide Skip and the dots, and compact the name page
            int keyboard = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom;
            boolean typing = insets.isVisible(WindowInsetsCompat.Type.ime()) || keyboard > dp(120);
            skip.setAlpha(typing ? 0f : 1f);
            dotsRow.setVisibility(typing ? View.GONE : View.VISIBLE);
            if (adapter != null) adapter.setTyping(typing);
            return insets;
        });

        adapter = new OnboardingAdapter();
        adapter.setOnDone(this::onContinue);
        photoPicker = new PhotoPicker(this, adapter::refreshPhoto);
        adapter.setOnPhotoClick(photoPicker::start);
        count = adapter.getItemCount();
        pager.setAdapter(adapter);

        // parallax: every floating layer moves at its own speed, and rises as its page arrives
        pager.setPageTransformer((page, position) -> {
            float w = page.getWidth();
            float a = Math.min(1f, Math.abs(position));
            float eased = a * a;                      // eases into place, so it never snaps
            page.setAlpha(Math.max(0f, 1f - a * 1.2f));

            View title = page.findViewById(R.id.obTitle);
            View desc = page.findViewById(R.id.obDesc);
            if (title != null) title.setTranslationX(position * w * 0.18f);
            if (desc != null) desc.setTranslationX(position * w * 0.10f);

            ViewGroup container = page.findViewById(R.id.obHero);
            if (container != null && container.getChildCount() > 0
                    && container.getChildAt(0) instanceof ViewGroup) {
                ViewGroup root = (ViewGroup) container.getChildAt(0);
                for (int i = 0; i < root.getChildCount(); i++) {
                    View layer = root.getChildAt(i);
                    Object tag = layer.getTag();
                    float depth = tag instanceof Float ? (Float) tag : 0.3f;
                    float travel = dp(36) + depth * dp(150);
                    layer.setTranslationX(position * w * depth);
                    layer.setTranslationY(position > 0 ? travel * eased : -travel * 0.2f * eased);
                }
            }

            // the name page
            View card = page.findViewById(R.id.obCard);
            View icon = page.findViewById(R.id.obIcon);
            if (card != null) {
                float s = 1f - 0.06f * a;
                card.setScaleX(s);
                card.setScaleY(s);
            }
            if (icon != null) icon.setTranslationX(position * w * 0.30f);
        });

        buildDots();

        pager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageScrolled(int position, float offset, int offsetPixels) {
                backdrop.setPage(position + offset);     // the colours flow as you swipe
            }

            @Override
            public void onPageSelected(int position) {
                updateUi(position, true);
            }
        });

        skip.setOnClickListener(v -> goTo(count - 1));   // straight to the name page
        cont.setOnClickListener(v -> onContinue());

        updateUi(0, false);

        // the first slide's cards float up from below, before the first frame is drawn
        pager.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            private int tries = 0;

            @Override
            public boolean onPreDraw() {
                ViewGroup root = heroRootAt(0);
                if (root == null && ++tries < 10) return true;     // not laid out yet
                pager.getViewTreeObserver().removeOnPreDrawListener(this);
                if (root != null) HeroArt.enter(root);
                return true;
            }
        });

        if (!Motion.isReduced(this)) {
            content.setAlpha(0f);
            content.animate().alpha(1f).setDuration(450).start();
        }
    }

    /** The floating cards of one slide, or null when that slide is not on screen yet. */
    private ViewGroup heroRootAt(int position) {
        View rv = pager.getChildAt(0);
        if (!(rv instanceof RecyclerView)) return null;
        RecyclerView.LayoutManager lm = ((RecyclerView) rv).getLayoutManager();
        if (lm == null) return null;
        View page = lm.findViewByPosition(position);
        if (page == null) return null;
        ViewGroup container = page.findViewById(R.id.obHero);
        if (container == null || container.getChildCount() == 0) return null;
        View first = container.getChildAt(0);
        return first instanceof ViewGroup ? (ViewGroup) first : null;
    }

    /** A slow, smooth glide to another slide, instead of the quick default snap. */
    private void goTo(int target) {
        int current = pager.getCurrentItem();
        if (target == current || target < 0 || target >= count) return;
        if (Motion.isReduced(this) || pager.isFakeDragging()) {
            pager.setCurrentItem(target, true);
            return;
        }

        final int distance = pager.getWidth() * (target - current);
        final int[] previous = {0};
        final boolean[] started = {false};

        ValueAnimator glide = ValueAnimator.ofInt(0, distance);
        glide.setDuration(620L + 140L * (Math.abs(target - current) - 1));
        glide.setInterpolator(new AccelerateDecelerateInterpolator());
        glide.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animation) {
                started[0] = pager.beginFakeDrag();
                if (started[0]) pager.setUserInputEnabled(false);
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                if (started[0]) {
                    pager.endFakeDrag();
                    pager.setUserInputEnabled(true);
                } else {
                    pager.setCurrentItem(target, false);
                }
            }
        });
        glide.addUpdateListener(an -> {
            if (!started[0]) return;
            int now = (int) an.getAnimatedValue();
            pager.fakeDragBy(-(now - previous[0]));
            previous[0] = now;
        });
        glide.start();
    }

    private void onContinue() {
        int current = pager.getCurrentItem();
        if (current < count - 1) {
            goTo(current + 1);
            return;
        }
        // last page: the name is needed
        String name = adapter.getName();
        if (name.isEmpty()) {
            adapter.showNameError("Please type your name");
            shake(cont);
            return;
        }
        AppPrefs.setLandlordName(this, name);
        AppPrefs.setOnboardingDone(this);
        startActivity(new Intent(this, MainActivity.class));
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private void buildDots() {
        dots = new View[count];
        for (int i = 0; i < count; i++) {
            View d = new View(this);
            LinearLayout.LayoutParams lp =
                    new LinearLayout.LayoutParams(dp(i == 0 ? 22 : 8), dp(8));
            lp.setMargins(0, 0, dp(8), 0);
            d.setLayoutParams(lp);
            d.setBackgroundResource(i == 0 ? R.drawable.bg_dot_active : R.drawable.bg_dot_inactive);
            dotsRow.addView(d);
            dots[i] = d;
        }
    }

    private void updateUi(int page, boolean animate) {
        boolean motion = animate && !Motion.isReduced(this);
        for (int i = 0; i < count; i++) {
            boolean active = (i == page);
            dots[i].setBackgroundResource(
                    active ? R.drawable.bg_dot_active : R.drawable.bg_dot_inactive);
            int target = dp(active ? 22 : 8);
            if (motion) {
                animateWidth(dots[i], target);
            } else {
                ViewGroup.LayoutParams lp = dots[i].getLayoutParams();
                lp.width = target;
                dots[i].setLayoutParams(lp);
            }
        }
        boolean last = (page == count - 1);
        cont.setText(last ? "Let's go" : "Continue");
        skip.setVisibility(last ? View.INVISIBLE : View.VISIBLE);
    }

    private void animateWidth(View v, int to) {
        ViewGroup.LayoutParams lp = v.getLayoutParams();
        ValueAnimator a = ValueAnimator.ofInt(lp.width, to);
        a.setDuration(300);
        a.addUpdateListener(an -> {
            lp.width = (int) an.getAnimatedValue();
            v.setLayoutParams(lp);
        });
        a.start();
    }

    private void shake(View v) {
        float d = dp(14);
        ObjectAnimator.ofFloat(v, "translationX", 0, -d, d, -d * 0.6f, d * 0.6f, 0)
                .setDuration(380).start();
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics());
    }
}