package com.tenodesk.app;

import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.viewpager2.widget.ViewPager2;

public class OnboardingActivity extends AppCompatActivity {

    // a soft colour mood for each page: gold, violet, teal, gold
    private static final int[] MOODS = {0x40D4AF37, 0x406B4FD8, 0x4010A5A5, 0x40D4AF37};

    private ViewPager2 pager;
    private TextView skip, cont;
    private LinearLayout dotsRow;
    private View moodTint;
    private View[] dots;
    private OnboardingAdapter adapter;
    private int count;
    private int tintColor = MOODS[0];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_onboarding);

        View content = findViewById(R.id.onboardingRoot);
        ViewCompat.setOnApplyWindowInsetsListener(content, (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.ime());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        pager = findViewById(R.id.obPager);
        skip = findViewById(R.id.obSkip);
        cont = findViewById(R.id.obContinue);
        dotsRow = findViewById(R.id.obDots);
        moodTint = findViewById(R.id.moodTint);
        moodTint.setBackgroundColor(tintColor);

        adapter = new OnboardingAdapter();
        adapter.setOnDone(this::onContinue);
        count = adapter.getItemCount();
        pager.setAdapter(adapter);

        // parallax: icon, title and text slide at different speeds, the page fades and scales
        pager.setPageTransformer((page, position) -> {
            float w = page.getWidth();
            float a = Math.abs(position);
            page.setAlpha(Math.max(0f, 1f - a * 1.1f));

            View card = page.findViewById(R.id.obCard);
            View icon = page.findViewById(R.id.obIcon);
            View title = page.findViewById(R.id.obTitle);
            View desc = page.findViewById(R.id.obDesc);
            if (card != null) {
                float s = 1f - 0.06f * Math.min(1f, a);
                card.setScaleX(s);
                card.setScaleY(s);
            }
            if (icon != null) icon.setTranslationX(position * w * 0.30f);
            if (title != null) title.setTranslationX(position * w * 0.16f);
            if (desc != null) desc.setTranslationX(position * w * 0.08f);
        });

        buildDots();

        pager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                updateUi(position, true);
            }
        });

        skip.setOnClickListener(v -> pager.setCurrentItem(count - 1, true));   // straight to the name page
        cont.setOnClickListener(v -> onContinue());

        updateUi(0, false);

        // the whole screen rises in softly
        if (!Motion.isReduced(this)) {
            content.setAlpha(0f);
            content.setTranslationY(dp(28));
            content.animate().alpha(1f).translationY(0f).setDuration(520)
                    .setInterpolator(new DecelerateInterpolator(1.8f)).start();
        }
    }

    private void onContinue() {
        int current = pager.getCurrentItem();
        if (current < count - 1) {
            pager.setCurrentItem(current + 1, true);
            return;
        }
        // last page: the name is needed
        String name = adapter.getName();
        if (name.isEmpty()) {
            adapter.showNameError("Please type your name");
            shake(cont);
            return;
        }
        AppPrefs.setLandlordName(this, name);
        AppPrefs.setOnboardingDone(this);
        startActivity(new Intent(this, MainActivity.class));
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private void buildDots() {
        dots = new View[count];
        for (int i = 0; i < count; i++) {
            View d = new View(this);
            LinearLayout.LayoutParams lp =
                    new LinearLayout.LayoutParams(dp(i == 0 ? 22 : 8), dp(8));
            lp.setMargins(dp(4), 0, dp(4), 0);
            d.setLayoutParams(lp);
            d.setBackgroundResource(i == 0 ? R.drawable.bg_dot_active : R.drawable.bg_dot_inactive);
            dotsRow.addView(d);
            dots[i] = d;
        }
    }

    private void updateUi(int page, boolean animate) {
        boolean motion = animate && !Motion.isReduced(this);
        for (int i = 0; i < count; i++) {
            boolean active = (i == page);
            dots[i].setBackgroundResource(
                    active ? R.drawable.bg_dot_active : R.drawable.bg_dot_inactive);
            int target = dp(active ? 22 : 8);
            if (motion) {
                animateWidth(dots[i], target);
            } else {
                ViewGroup.LayoutParams lp = dots[i].getLayoutParams();
                lp.width = target;
                dots[i].setLayoutParams(lp);
            }
        }
        boolean last = (page == count - 1);
        cont.setText(last ? "Let's go" : "Continue");
        skip.setVisibility(last ? View.INVISIBLE : View.VISIBLE);
        applyMood(page, motion);
    }

    private void applyMood(int page, boolean animate) {
        int target = MOODS[Math.min(page, MOODS.length - 1)];
        if (!animate) {
            tintColor = target;
            moodTint.setBackgroundColor(target);
            return;
        }
        ValueAnimator a = ValueAnimator.ofObject(new ArgbEvaluator(), tintColor, target);
        a.setDuration(450);
        a.addUpdateListener(an -> {
            tintColor = (int) an.getAnimatedValue();
            moodTint.setBackgroundColor(tintColor);
        });
        a.start();
    }

    private void animateWidth(View v, int to) {
        ViewGroup.LayoutParams lp = v.getLayoutParams();
        ValueAnimator a = ValueAnimator.ofInt(lp.width, to);
        a.setDuration(250);
        a.addUpdateListener(an -> {
            lp.width = (int) an.getAnimatedValue();
            v.setLayoutParams(lp);
        });
        a.start();
    }

    private void shake(View v) {
        float d = dp(14);
        ObjectAnimator.ofFloat(v, "translationX", 0, -d, d, -d * 0.6f, d * 0.6f, 0)
                .setDuration(380).start();
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics());
    }
}