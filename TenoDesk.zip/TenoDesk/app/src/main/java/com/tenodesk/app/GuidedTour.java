package com.tenodesk.app;

import android.app.Activity;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import java.util.ArrayList;
import java.util.List;

/** The "How it works" guide: spotlights parts of the app one by one, moving between the tabs. */
public final class GuidedTour {

    public interface Host {
        int currentTab();

        void showTabNow(int index);

        void onTourFinished();
    }

    private static final class Step {
        final int tab;          // tab to open first, or -1 to stay where we are
        final int targetId;     // the part to spotlight, or 0 for a plain card in the middle
        final String title;
        final String body;
        final boolean legend;   // show the Paid / Due soon / Overdue colour guide

        Step(int tab, int targetId, String title, String body, boolean legend) {
            this.tab = tab;
            this.targetId = targetId;
            this.title = title;
            this.body = body;
            this.legend = legend;
        }
    }

    private static final int HOME = 0;
    private static final int TENANTS = 1;
    private static final int ROOMS = 2;
    private static final int BILLS = 3;

    private final Activity activity;
    private final Host host;
    private final TourOverlay overlay;
    private final List<Step> steps = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private int index = -1;
    private int token = 0;
    private boolean ended = false;

    public static GuidedTour start(Activity activity, Host host) {
        GuidedTour tour = new GuidedTour(activity, host);
        tour.begin();
        return tour;
    }

    private GuidedTour(Activity activity, Host host) {
        this.activity = activity;
        this.host = host;
        this.overlay = new TourOverlay(activity);
        buildSteps();
    }

    // ------------------------------------------------------------ the wording

    private void buildSteps() {
        steps.add(new Step(-1, 0, "Welcome to TenoDesk",
                "This short guide shows you how to use the app. It takes about one minute. "
                        + "You can skip it at any time.", false));

        steps.add(new Step(HOME, R.id.navBar, "Move around here",
                "These four buttons take you to Home, Tenants, Rooms and Bills. Tap one to open it.",
                false));

        steps.add(new Step(HOME, R.id.wStats, "Your money at a glance",
                "Here you see the rent collected this month, and how many tenants are late or almost due.",
                false));

        steps.add(new Step(ROOMS, R.id.btnAddCategory, "Start by adding your rooms",
                "Tap here. Type the kind of room, for example Single room, the monthly rent, "
                        + "and how many rooms you have. We make the rooms for you.", false));

        steps.add(new Step(ROOMS, 0, "Tap a room",
                "Tap an empty room to add the person who lives there. "
                        + "Tap a room that has a tenant to open their page.", false));

        steps.add(new Step(TENANTS, R.id.btnAddTenant, "Add your tenants",
                "You can also add a tenant here. Type their name and phone number, "
                        + "choose the room, and pick the day they moved in.", false));

        steps.add(new Step(TENANTS, 0, "The colours tell you who to follow up",
                "Every tenant has a card with a colour:", true));

        steps.add(new Step(TENANTS, 0, "When someone pays",
                "Open the tenant's page and tap Mark as paid. "
                        + "If you press it by mistake, tap Undo payment.", false));

        steps.add(new Step(BILLS, R.id.btnNewBill, "Share bills like water",
                "Tap here, type the bill amount, and choose who shares it. We divide it for you, "
                        + "and you can send each person their share by SMS.", false));

        steps.add(new Step(HOME, R.id.homeGear, "Settings",
                "Change your name or photo, choose what shows on Home, "
                        + "and open this guide again any time.", false));

        steps.add(new Step(-1, 0, "You are ready!",
                "Start by adding your rooms. TenoDesk will remind you when rent is almost due.", false));
    }

    // -------------------------------------------------------------- running

    private void begin() {
        ViewGroup content = activity.findViewById(android.R.id.content);
        content.addView(overlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        overlay.setTranslationZ(48f * activity.getResources().getDisplayMetrics().density);

        overlay.setOnNext(this::next);
        overlay.setOnBack(this::back);
        overlay.setOnSkip(this::skip);

        overlay.setAlpha(0f);
        overlay.animate().alpha(1f).setDuration(300).start();
        overlay.setOnReady(() -> goTo(0));
    }

    private void next() {
        goTo(index + 1);
    }

    private void back() {
        goTo(index - 1);
    }

    public void skip() {
        finish();
    }

    /** Removes the guide at once, without asking anything (used when the screen is closed). */
    public void abort() {
        ended = true;
        handler.removeCallbacksAndMessages(null);
        overlay.removeNow();
    }

    private void finish() {
        if (ended) return;
        ended = true;
        handler.removeCallbacksAndMessages(null);
        if (host.currentTab() != HOME) host.showTabNow(HOME);      // always end on Home
        overlay.dismiss(host::onTourFinished);
    }

    private void goTo(int target) {
        if (ended) return;
        if (target >= steps.size()) {
            finish();
            return;
        }
        final int i = Math.max(0, target);
        final Step step = steps.get(i);
        final boolean first = index == -1;
        final int myToken = ++token;
        index = i;

        overlay.hideCard(!first);

        long wait;
        if (step.tab >= 0 && step.tab != host.currentTab()) {
            host.showTabNow(step.tab);
            wait = Motion.isReduced(activity) ? 250 : 950;       // lets the new tab settle
        } else {
            wait = first ? 0 : 200;
        }

        handler.postDelayed(() -> {
            if (ended || myToken != token) return;
            if (activity.isFinishing() || activity.isDestroyed()) return;
            show(step, i);
        }, wait);
    }

    private void show(Step step, int i) {
        RectF target = null;
        if (step.targetId != 0) {
            View v = activity.findViewById(step.targetId);
            if (v != null && v.getVisibility() == View.VISIBLE && v.getWidth() > 0) {
                target = rectOf(v);
            }
        }
        boolean last = i == steps.size() - 1;
        String label = "STEP " + (i + 1) + " OF " + steps.size();
        String next = i == 0 ? "Show me" : (last ? "Let's start" : "Next");
        overlay.present(target, label, step.title, step.body, step.legend, next, i > 0, !last);
    }

    private RectF rectOf(View v) {
        int[] a = new int[2];
        int[] b = new int[2];
        v.getLocationInWindow(a);
        overlay.getLocationInWindow(b);
        float left = a[0] - b[0];
        float top = a[1] - b[1];
        return new RectF(left, top, left + v.getWidth(), top + v.getHeight());
    }
}