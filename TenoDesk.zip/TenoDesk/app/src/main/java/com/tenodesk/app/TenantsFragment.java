package com.tenodesk.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.util.Collections;
import java.util.List;

public class TenantsFragment extends Fragment implements TenantsAdapter.Listener {

    private DatabaseHelper db;
    private TenantsAdapter adapter;
    private TextView summary;
    private View empty;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_tenants, container, false);
        db = DatabaseHelper.get(requireContext());

        RecyclerView list = v.findViewById(R.id.tenantsList);
        list.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new TenantsAdapter(this);
        list.setAdapter(adapter);

        summary = v.findViewById(R.id.tenantsSummary);
        empty = v.findViewById(R.id.tenantsEmpty);
        v.findViewById(R.id.btnAddTenant).setOnClickListener(x -> showAddDialog());
        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        refresh();
    }

    /** Overdue first, then due soon, then active, then paid. */
    private int rank(Tenant t) {
        if (RentEngine.OVERDUE.equals(t.status)) return 0;
        if (RentEngine.DUE.equals(t.status)) return 1;
        if (RentEngine.ACTIVE.equals(t.status)) return 2;
        return 3;
    }

    private void refresh() {
        List<Tenant> list = db.getTenants();
        Collections.sort(list, (a, b) -> {
            int r = rank(a) - rank(b);
            if (r != 0) return r;
            if (a.daysLeft != b.daysLeft) return a.daysLeft - b.daysLeft;
            return a.name.compareToIgnoreCase(b.name);
        });
        adapter.submit(list);

        int overdue = 0;
        int soon = 0;
        for (Tenant t : list) {
            if (RentEngine.OVERDUE.equals(t.status)) overdue++;
            else if (RentEngine.DUE.equals(t.status)) soon++;
        }
        if (list.isEmpty()) {
            summary.setText("Nobody yet");
        } else {
            StringBuilder sb = new StringBuilder();
            sb.append(list.size()).append(list.size() == 1 ? " tenant" : " tenants");
            if (overdue > 0) sb.append("  \u00B7  ").append(overdue).append(" overdue");
            if (soon > 0) sb.append("  \u00B7  ").append(soon).append(" due soon");
            if (overdue == 0 && soon == 0) sb.append("  \u00B7  all on track");
            summary.setText(sb.toString());
        }
        empty.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onTenantClick(Tenant tenant) {
        Intent i = new Intent(requireContext(), TenantDetailActivity.class);
        i.putExtra("tenant_id", tenant.id);
        startActivity(i);
    }

    private void showAddDialog() {
        List<Room> vacant = db.getVacantRooms();
        if (vacant.isEmpty()) {
            toast("No empty rooms. Add rooms first in the Rooms tab.");
            return;
        }

        View view = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_tenant, null);
        TextView picker = view.findViewById(R.id.addRoomPicker);
        EditText name = view.findViewById(R.id.addName);
        EditText phone = view.findViewById(R.id.addPhone);
        TextView dateView = view.findViewById(R.id.addDate);

        final String[] date = {RentEngine.today()};
        dateView.setText(DateUi.pretty(date[0]));
        dateView.setOnClickListener(x -> DateUi.showPicker(requireContext(), date[0], picked -> {
            date[0] = picked;
            dateView.setText(DateUi.pretty(picked));
        }));

        final Room[] chosen = new Room[1];
        String[] labels = new String[vacant.size()];
        for (int i = 0; i < vacant.size(); i++) {
            labels[i] = vacant.get(i).roomNumber + "  \u00B7  "
                    + Money.format(vacant.get(i).monthlyPrice);
        }

        picker.setOnClickListener(x -> new MaterialAlertDialogBuilder(requireContext())
                .setTitle("Choose a room")
                .setItems(labels, (d, which) -> {
                    chosen[0] = vacant.get(which);
                    picker.setText(labels[which]);
                    picker.setTextColor(requireContext().getColor(R.color.td_text_primary));
                })
                .show());

        AlertDialog dialog = new MaterialAlertDialogBuilder(requireContext())
                .setTitle("Add tenant")
                .setView(view)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Add", null)
                .create();
        dialog.show();

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(x -> {
            if (chosen[0] == null) {
                toast("Choose a room first");
                return;
            }
            String n = name.getText().toString().trim();
            if (n.isEmpty()) {
                name.setError("Enter the tenant's name");
                return;
            }
            long id = db.addTenant(n, phone.getText().toString().trim(), chosen[0].id, date[0]);
            if (id == -1) {
                toast("That room already has a tenant");
                return;
            }
            dialog.dismiss();
            refresh();
        });
    }

    private void toast(String message) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
    }
}