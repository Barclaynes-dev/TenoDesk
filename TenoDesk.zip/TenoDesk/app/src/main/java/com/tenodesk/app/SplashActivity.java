package com.tenodesk.app;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SplashActivity extends AppCompatActivity {

    private static final String WORD = "TenoDesk";
    private static final long GO_NEXT_AFTER_MS = 2000;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable goNext = this::openNextScreen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        animateMark();
        animateWord();
        findViewById(R.id.splashTagline).animate()
                .alpha(1f).setStartDelay(1150).setDuration(450).start();

        handler.postDelayed(goNext, GO_NEXT_AFTER_MS);
    }

    private void animateMark() {
        ImageView mark = findViewById(R.id.splashMark);
        mark.setAlpha(0f);
        mark.setScaleX(0.7f);
        mark.setScaleY(0.7f);
        mark.animate()
                .alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(550)
                .setInterpolator(new DecelerateInterpolator(1.6f))
                .start();
    }

    private void animateWord() {
        LinearLayout row = findViewById(R.id.wordRow);
        float rise = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, 18, getResources().getDisplayMetrics());
        int white = ContextCompat.getColor(this, R.color.td_text_primary);
        int gold = ContextCompat.getColor(this, R.color.td_accent);

        for (int i = 0; i < WORD.length(); i++) {
            TextView letter = new TextView(this);
            letter.setText(String.valueOf(WORD.charAt(i)));
            letter.setTextSize(TypedValue.COMPLEX_UNIT_SP, 34);
            letter.setTypeface(Typeface.DEFAULT_BOLD);
            letter.setTextColor(i < 4 ? white : gold);   // "Teno" + "Desk"
            letter.setAlpha(0f);
            letter.setTranslationY(rise);
            row.addView(letter);

            letter.animate()
                    .alpha(1f).translationY(0f)
                    .setStartDelay(450 + i * 55L)
                    .setDuration(420)
                    .setInterpolator(new DecelerateInterpolator(1.8f))
                    .start();
        }
    }

    private void openNextScreen() {
        Class<?> next = AppPrefs.isOnboardingDone(this)
                ? MainActivity.class
                : OnboardingActivity.class;
        startActivity(new Intent(this, next));
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(goNext);
        super.onDestroy();
    }
}