package com.tenodesk.app;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_settings);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.settingsRoot), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        findViewById(R.id.settingsBack).setOnClickListener(v -> finish());

        buildProfile();
        buildAppearance();
        buildWidgets();
        buildMore();
    }

    // ---------------------------------------------------------------- sections

    private void buildProfile() {
        LinearLayout box = findViewById(R.id.settingsProfile);
        box.removeAllViews();
        View row = row(box, "Your name", "Shown in your greeting on Home", true);
        TextView value = row.findViewById(R.id.setValue);
        value.setText(AppPrefs.getLandlordName(this));
        value.setVisibility(View.VISIBLE);
        row.findViewById(R.id.setRoot).setOnClickListener(v ->
                NameDialog.show(this, this::buildProfile));
    }

    private void buildAppearance() {
        LinearLayout box = findViewById(R.id.settingsAppearance);

        View dark = row(box, "Dark mode", "Switch between dark and light", true);
        SwitchCompat darkSwitch = dark.findViewById(R.id.setSwitch);
        darkSwitch.setVisibility(View.VISIBLE);
        darkSwitch.setChecked(ThemeManager.isDark(this));
        darkSwitch.setOnCheckedChangeListener((b, checked) -> ThemeManager.setDark(this, checked));
        dark.findViewById(R.id.setRoot).setOnClickListener(v -> darkSwitch.toggle());

        View motion = row(box, "Reduce motion",
                "Stops the moving background and animations. It also switches on by itself in battery saver.",
                false);
        SwitchCompat motionSwitch = motion.findViewById(R.id.setSwitch);
        motionSwitch.setVisibility(View.VISIBLE);
        motionSwitch.setChecked(getSharedPreferences("tenodesk_prefs", Context.MODE_PRIVATE)
                .getBoolean("reduce_motion", false));
        motionSwitch.setOnCheckedChangeListener((b, checked) ->
                getSharedPreferences("tenodesk_prefs", Context.MODE_PRIVATE)
                        .edit().putBoolean("reduce_motion", checked).apply());
        motion.findViewById(R.id.setRoot).setOnClickListener(v -> motionSwitch.toggle());
    }

    private void buildWidgets() {
        LinearLayout box = findViewById(R.id.settingsWidgets);
        for (int i = 0; i < HomeWidgets.KEYS.length; i++) {
            final String key = HomeWidgets.KEYS[i];
            View row = row(box, HomeWidgets.TITLES[i], HomeWidgets.SUBTITLES[i], i == 0);
            SwitchCompat sw = row.findViewById(R.id.setSwitch);
            sw.setVisibility(View.VISIBLE);
            sw.setChecked(HomeWidgets.isOn(this, key));
            sw.setOnCheckedChangeListener((b, checked) -> HomeWidgets.set(this, key, checked));
            row.findViewById(R.id.setRoot).setOnClickListener(v -> sw.toggle());
        }
    }

    private void buildMore() {
        LinearLayout box = findViewById(R.id.settingsMore);

        View replay = row(box, "Replay intro", "See the welcome screens again", true);
        replay.findViewById(R.id.setRoot).setOnClickListener(v -> {
            getSharedPreferences("tenodesk_prefs", Context.MODE_PRIVATE)
                    .edit().putBoolean("onboarding_done", false).apply();
            Intent i = new Intent(this, OnboardingActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
        });

        View version = row(box, "Version", null, false);
        TextView value = version.findViewById(R.id.setValue);
        value.setText(versionName());
        value.setVisibility(View.VISIBLE);
    }

    // ----------------------------------------------------------------- helpers

    private View row(LinearLayout box, String title, String sub, boolean first) {
        View row = getLayoutInflater().inflate(R.layout.item_setting_row, box, false);
        ((TextView) row.findViewById(R.id.setTitle)).setText(title);
        TextView s = row.findViewById(R.id.setSub);
        if (sub != null) {
            s.setText(sub);
            s.setVisibility(View.VISIBLE);
        }
        row.findViewById(R.id.setDivider).setVisibility(first ? View.GONE : View.VISIBLE);
        box.addView(row);
        return row;
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            return "1.0";
        }
    }
}