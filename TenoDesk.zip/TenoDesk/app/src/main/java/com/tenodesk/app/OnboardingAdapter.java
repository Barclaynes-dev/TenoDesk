package com.tenodesk.app;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class OnboardingAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_INFO = 0;
    private static final int TYPE_NAME = 1;

    private final int[] icons = {
            R.drawable.ic_ob_home, R.drawable.ic_ob_people, R.drawable.ic_ob_receipt};

    private final String[] titles = {
            "Every shilling,\ntracked.",
            "Know who\nhas paid.",
            "Split bills\nfairly."};

    private final String[] descs = {
            "Manage tenants, rent and shared utility bills \u2014 all from your phone, even offline.",
            "See who is almost due or overdue at a glance, and mark rent as paid in one tap.",
            "Divide water or electricity between your tenants, evenly or only those who share."};

    private String name = "";
    private EditText nameField;
    private Runnable onDone;

    public void setOnDone(Runnable onDone) {
        this.onDone = onDone;
    }

    public String getName() {
        return name.trim();
    }

    public void showNameError(String message) {
        if (nameField != null) {
            nameField.setError(message);
            nameField.requestFocus();
        }
    }

    @Override
    public int getItemViewType(int position) {
        return position < titles.length ? TYPE_INFO : TYPE_NAME;
    }

    @Override
    public int getItemCount() {
        return titles.length + 1;   // the slides, plus the name page
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        if (viewType == TYPE_NAME) {
            return new NameVH(inflater.inflate(R.layout.item_onboarding_name, parent, false));
        }
        return new InfoVH(inflater.inflate(R.layout.item_onboarding, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof InfoVH) {
            InfoVH h = (InfoVH) holder;
            h.icon.setImageResource(icons[position]);
            h.title.setText(titles[position]);
            h.desc.setText(descs[position]);
        } else {
            NameVH h = (NameVH) holder;
            nameField = h.field;
            if (!h.field.getText().toString().equals(name)) h.field.setText(name);
        }
    }

    static class InfoVH extends RecyclerView.ViewHolder {
        final ImageView icon;
        final TextView title, desc;

        InfoVH(@NonNull View v) {
            super(v);
            icon = v.findViewById(R.id.obIcon);
            title = v.findViewById(R.id.obTitle);
            desc = v.findViewById(R.id.obDesc);
        }
    }

    class NameVH extends RecyclerView.ViewHolder {
        final EditText field;

        NameVH(@NonNull View v) {
            super(v);
            field = v.findViewById(R.id.obNameInput);
            field.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int a, int b, int c) {}

                @Override
                public void onTextChanged(CharSequence s, int a, int b, int c) {}

                @Override
                public void afterTextChanged(Editable s) {
                    name = s.toString();
                }
            });
            field.setOnEditorActionListener((tv, actionId, event) -> {
                if (actionId == EditorInfo.IME_ACTION_DONE && onDone != null) {
                    onDone.run();
                    return true;
                }
                return false;
            });
        }
    }
}