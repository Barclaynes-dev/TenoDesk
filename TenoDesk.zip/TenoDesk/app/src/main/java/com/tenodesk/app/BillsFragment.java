package com.tenodesk.app;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BillsFragment extends Fragment implements BillsAdapter.Listener {

    private DatabaseHelper db;
    private BillsRepo repo;
    private BillsAdapter adapter;
    private View empty;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_bills, container, false);
        db = DatabaseHelper.get(requireContext());
        repo = new BillsRepo(requireContext());

        RecyclerView list = v.findViewById(R.id.billsList);
        list.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new BillsAdapter(this);
        list.setAdapter(adapter);

        empty = v.findViewById(R.id.billsEmpty);
        v.findViewById(R.id.btnNewBill).setOnClickListener(x -> showNewBillDialog());
        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        List<Bill> bills = repo.getBills();
        adapter.submit(bills);
        empty.setVisibility(bills.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onBillClick(Bill bill) {
        showBillSheet(bill);
    }

    // ------------------------------------------------------------- new bill

    private void showNewBillDialog() {
        List<Tenant> tenants = db.getTenants();
        if (tenants.isEmpty()) {
            toast("Add tenants first, then you can split a bill between them.");
            return;
        }
        Collections.sort(tenants, (a, b) -> a.name.compareToIgnoreCase(b.name));

        View view = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_new_bill, null);
        EditText typeIn = view.findViewById(R.id.billTypeInput);
        EditText amountIn = view.findViewById(R.id.billAmountInput);
        TextView dateView = view.findViewById(R.id.billDateInput);
        LinearLayout listBox = view.findViewById(R.id.billTenants);
        TextView preview = view.findViewById(R.id.billPreview);

        // quick pick chips
        int[] chipIds = {R.id.chipWater, R.id.chipElectricity, R.id.chipGarbage, R.id.chipSecurity};
        String[] chipNames = {"Water", "Electricity", "Garbage", "Security"};
        for (int i = 0; i < chipIds.length; i++) {
            final String name = chipNames[i];
            view.findViewById(chipIds[i]).setOnClickListener(x -> {
                typeIn.setText(name);
                typeIn.setSelection(name.length());
            });
        }

        // date
        final String[] date = {RentEngine.today()};
        dateView.setText(DateUi.pretty(date[0]));
        dateView.setOnClickListener(x -> DateUi.showPicker(requireContext(), date[0], picked -> {
            date[0] = picked;
            dateView.setText(DateUi.pretty(picked));
        }));

        // live "each pays" line
        final List<CheckBox> boxes = new ArrayList<>();
        final Runnable updatePreview = () -> {
            long total = parseLong(amountIn);
            int n = 0;
            for (CheckBox cb : boxes) {
                if (cb.isChecked()) n++;
            }
            if (n == 0) {
                preview.setText("Choose at least one tenant");
            } else if (total <= 0) {
                preview.setText(n + (n == 1 ? " tenant selected" : " tenants selected"));
            } else {
                String text = "Each of " + n + (n == 1 ? " tenant pays " : " tenants pays ")
                        + Money.format(BillsRepo.splitAmount(total, n));
                if (BillsRepo.wasRounded(total, n)) {
                    text += "\n(rounded up to the nearest UGX 100)";
                }
                preview.setText(text);
            }
        };

        amountIn.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {}

            @Override
            public void afterTextChanged(Editable s) {
                updatePreview.run();
            }
        });

        // one tick box per tenant, all ticked at the start
        int primary = requireContext().getColor(R.color.td_text_primary);
        int accent = requireContext().getColor(R.color.td_accent);
        for (Tenant t : tenants) {
            CheckBox cb = new CheckBox(requireContext());
            cb.setText(t.name + "  \u00B7  " + t.roomNumber);
            cb.setTextColor(primary);
            cb.setTextSize(15);
            cb.setChecked(true);
            cb.setButtonTintList(ColorStateList.valueOf(accent));
            cb.setPadding(dp(8), dp(10), 0, dp(10));
            cb.setTag(t);
            cb.setOnCheckedChangeListener((b, checked) -> updatePreview.run());
            listBox.addView(cb);
            boxes.add(cb);
        }

        view.findViewById(R.id.billToggleAll).setOnClickListener(x -> {
            boolean allChecked = true;
            for (CheckBox cb : boxes) {
                if (!cb.isChecked()) allChecked = false;
            }
            for (CheckBox cb : boxes) cb.setChecked(!allChecked);
        });

        updatePreview.run();

        AlertDialog dialog = new MaterialAlertDialogBuilder(requireContext())
                .setTitle("New bill")
                .setView(view)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save bill", null)
                .create();
        dialog.show();

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(x -> {
            String type = typeIn.getText().toString().trim();
            long total = parseLong(amountIn);

            List<Tenant> chosen = new ArrayList<>();
            for (CheckBox cb : boxes) {
                if (cb.isChecked()) chosen.add((Tenant) cb.getTag());
            }

            if (type.isEmpty()) {
                typeIn.setError("Enter what the bill is for, for example Water");
                return;
            }
            if (total <= 0) {
                amountIn.setError("Enter the total amount");
                return;
            }
            if (chosen.isEmpty()) {
                toast("Choose at least one tenant");
                return;
            }

            repo.addBill(type, total, date[0], chosen);
            dialog.dismiss();
            refresh();
            toast("Bill saved");
        });
    }

    // ------------------------------------------------------------ bill details

    private void showBillSheet(Bill bill) {
        BottomSheetDialog sheet = new BottomSheetDialog(requireContext());
        View v = LayoutInflater.from(requireContext()).inflate(R.layout.sheet_bill, null);
        sheet.setContentView(v);
        ((View) v.getParent()).setBackgroundColor(Color.TRANSPARENT);

        ((TextView) v.findViewById(R.id.sheetBillTitle)).setText(bill.billType + " bill");
        ((TextView) v.findViewById(R.id.sheetBillSub)).setText(
                DateUi.pretty(bill.date) + "  \u00B7  Total " + Money.format(bill.totalAmount));
        ((TextView) v.findViewById(R.id.sheetBillEach)).setText(
                "Each pays " + Money.format(bill.splitAmount));

        List<BillShare> shares = repo.getShares(bill.id);
        LinearLayout box = v.findViewById(R.id.sheetShares);
        for (BillShare s : shares) {
            View row = LayoutInflater.from(requireContext())
                    .inflate(R.layout.item_bill_share, box, false);
            ((TextView) row.findViewById(R.id.shareName)).setText(s.tenantName);
            ((TextView) row.findViewById(R.id.shareRoom)).setText(s.roomNumber);
            ((TextView) row.findViewById(R.id.shareAmount)).setText(Money.format(bill.splitAmount));
            row.findViewById(R.id.shareSms).setOnClickListener(x -> sendSms(bill, s));
            box.addView(row);
        }

        v.findViewById(R.id.btnShareBill).setOnClickListener(x -> shareSummary(bill, shares));
        v.findViewById(R.id.btnDeleteBill).setOnClickListener(x ->
                new MaterialAlertDialogBuilder(requireContext())
                        .setTitle("Delete this " + bill.billType + " bill?")
                        .setMessage("It will be removed from your list.")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Delete", (d, w) -> {
                            repo.deleteBill(bill.id);
                            sheet.dismiss();
                            refresh();
                        })
                        .show());

        sheet.show();
        sheet.getBehavior().setState(BottomSheetBehavior.STATE_EXPANDED);
    }

    private void sendSms(Bill bill, BillShare s) {
        if (s.phone == null || s.phone.isEmpty()) {
            toast("No phone number saved for " + s.tenantName);
            return;
        }
        String first = s.tenantName.trim().split(" ")[0];
        String message = "Hello " + first + ", your share of the " + bill.billType
                + " bill (" + DateUi.pretty(bill.date) + ") is "
                + Money.format(bill.splitAmount) + ". Thank you.";
        Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(s.phone)));
        i.putExtra("sms_body", message);
        try {
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            toast("No messaging app found on this phone");
        }
    }

    private void shareSummary(Bill bill, List<BillShare> shares) {
        StringBuilder sb = new StringBuilder();
        sb.append(bill.billType).append(" bill, ").append(DateUi.pretty(bill.date)).append("\n");
        sb.append("Total: ").append(Money.format(bill.totalAmount)).append("\n");
        sb.append("Each pays: ").append(Money.format(bill.splitAmount)).append("\n\n");
        for (BillShare s : shares) {
            sb.append("- ").append(s.tenantName).append(" (").append(s.roomNumber).append(")\n");
        }
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, sb.toString());
        startActivity(Intent.createChooser(send, "Share bill"));
    }

    // ----------------------------------------------------------------- helpers

    private long parseLong(EditText field) {
        try {
            return Long.parseLong(field.getText().toString().trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    private void toast(String message) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
    }
}