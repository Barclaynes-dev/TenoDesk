package com.tenodesk.app;

import android.content.Context;
import android.os.PowerManager;
import android.provider.Settings;

public final class Motion {
    private Motion() {}

    /** True when animations should be skipped: battery saver, system animations off, or the Settings switch. */
    public static boolean isReduced(Context c) {
        if (c.getSharedPreferences("tenodesk_prefs", Context.MODE_PRIVATE)
                .getBoolean("reduce_motion", false)) {
            return true;
        }
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        if (pm != null && pm.isPowerSaveMode()) return true;

        float scale = Settings.Global.getFloat(
                c.getContentResolver(), Settings.Global.ANIMATOR_DURATION_SCALE, 1f);
        return scale == 0f;
    }
}