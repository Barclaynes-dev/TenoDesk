package com.tenodesk.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.CornerPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.core.graphics.ColorUtils;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/** The full-screen layer of the guide: dim, spotlight with a soft glow, an arrow, and the explanation card. */
public class TourOverlay extends FrameLayout {

    private final Paint scrimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arrowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path scrimPath = new Path();
    private final Path arrowPath = new Path();

    // the spotlight rectangle, and the two ends of its slide from one target to the next
    private final RectF hole = new RectF();
    private final RectF holeFrom = new RectF();
    private final RectF holeTo = new RectF();
    private float radius, radiusFrom, radiusTo;

    private boolean arrowOn;
    private float arrowDir = 1f;      // 1 = card is below the target, -1 = card is above it
    private float arrowX, arrowTipY, arrowBaseY;

    private float pulse = 1f;
    private ValueAnimator pulseAnimator, moveAnimator;
    private Runnable onReady;

    private final View card;
    private final TextView stepText, titleText, bodyText, skipBtn, backBtn, nextBtn;
    private final View legend;

    public TourOverlay(Context context) {
        super(context);
        setWillNotDraw(false);
        setClickable(true);      // taps on the dim layer do nothing, so nobody presses the app by mistake
        setFocusable(true);

        int accent = context.getColor(R.color.td_accent);

        scrimPaint.setColor(0xA6000000);                   // how dark the rest of the screen gets (A6 = 65%)
        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setStrokeWidth(dp(2f));
        ringPaint.setColor(accent);
        glowPaint.setStyle(Paint.Style.STROKE);
        glowPaint.setColor(accent);
        arrowPaint.setColor(ColorUtils.setAlphaComponent(context.getColor(R.color.td_frost_hi), 255));
        arrowPaint.setPathEffect(new CornerPathEffect(dp(3f)));

        card = LayoutInflater.from(context).inflate(R.layout.view_tour_card, this, false);
        stepText = card.findViewById(R.id.tourStep);
        titleText = card.findViewById(R.id.tourTitle);
        bodyText = card.findViewById(R.id.tourBody);
        legend = card.findViewById(R.id.tourLegend);
        skipBtn = card.findViewById(R.id.tourSkip);
        backBtn = card.findViewById(R.id.tourBack);
        nextBtn = card.findViewById(R.id.tourNext);
        addView(card, new LayoutParams(dpi(320), LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START));
        card.setAlpha(0f);
    }

    // ------------------------------------------------------------------ wiring

    public void setOnNext(Runnable r) {
        nextBtn.setOnClickListener(v -> r.run());
    }

    public void setOnBack(Runnable r) {
        backBtn.setOnClickListener(v -> r.run());
    }

    public void setOnSkip(Runnable r) {
        skipBtn.setOnClickListener(v -> r.run());
    }

    public void setOnReady(Runnable r) {
        if (getWidth() > 0 && getHeight() > 0) {
            post(r);
        } else {
            onReady = r;
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w > 0 && h > 0 && onReady != null) {
            Runnable r = onReady;
            onReady = null;
            post(r);
        }
    }

    // ----------------------------------------------------------------- showing

    /** Fades the card out and shrinks the spotlight away, ready for the next step. */
    public void hideCard(boolean animate) {
        arrowOn = false;
        card.animate().cancel();
        if (animate && !Motion.isReduced(getContext())) {
            card.animate().alpha(0f).setDuration(140).start();
        } else {
            card.setAlpha(0f);
        }
        collapse();
        invalidate();
    }

    /**
     * Shows one step. target is the part of the screen to spotlight (in this view's own
     * coordinates), or null to show a centred card with no spotlight.
     */
    public void present(RectF target, String step, String title, String body, boolean legendOn,
                        String nextLabel, boolean showBack, boolean showSkip) {
        stepText.setText(step);
        titleText.setText(title);
        bodyText.setText(body);
        legend.setVisibility(legendOn ? View.VISIBLE : View.GONE);
        nextBtn.setText(nextLabel);
        backBtn.setVisibility(showBack ? View.VISIBLE : View.GONE);
        skipBtn.setVisibility(showSkip ? View.VISIBLE : View.INVISIBLE);

        int w = getWidth();
        int h = getHeight();
        int cardW = Math.min(w - dpi(40), dpi(360));

        LayoutParams lp = (LayoutParams) card.getLayoutParams();
        lp.width = cardW;
        card.setLayoutParams(lp);
        card.measure(MeasureSpec.makeMeasureSpec(cardW, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));
        int cardH = card.getMeasuredHeight();

        float[] safe = safeInsets();
        float minY = safe[0] + dp(12f);
        float maxY = h - safe[1] - dp(12f);
        float cardX = (w - cardW) / 2f;
        float cardY;

        RectF newHole = new RectF();
        float newRadius = 0f;

        if (target == null) {
            arrowOn = false;
            cardY = (h - cardH) / 2f;
        } else {
            float pad = dp(8f);
            newHole.set(target.left - pad, target.top - pad, target.right + pad, target.bottom + pad);
            newRadius = Math.min(dp(20f), newHole.height() / 2f);

            float gap = dp(26f);                                  // room for the arrow
            float spaceBelow = maxY - (newHole.bottom + gap);
            float spaceAbove = (newHole.top - gap) - minY;
            boolean below;
            if (spaceBelow >= cardH) below = true;
            else if (spaceAbove >= cardH) below = false;
            else below = spaceBelow >= spaceAbove;

            cardY = below ? newHole.bottom + gap : newHole.top - gap - cardH;
            cardY = Math.max(minY, Math.min(cardY, maxY - cardH));

            arrowOn = true;
            arrowDir = below ? 1f : -1f;
            arrowX = clamp(newHole.centerX(), cardX + dp(30f), cardX + cardW - dp(30f));
            arrowTipY = below ? newHole.bottom + dp(4f) : newHole.top - dp(4f);
            arrowBaseY = below ? cardY + dp(1f) : cardY + cardH - dp(1f);
        }

        card.setTranslationX(cardX);
        card.setTranslationY(cardY);

        // slide the spotlight to its new place
        if (moveAnimator != null) moveAnimator.cancel();
        if (hole.width() < 1f && newHole.width() >= 1f) {         // growing out of nothing
            holeFrom.set(newHole.centerX(), newHole.centerY(), newHole.centerX(), newHole.centerY());
            radiusFrom = 0f;
        } else {
            holeFrom.set(hole);
            radiusFrom = radius;
        }
        if (newHole.width() < 1f) {                                // no spotlight on this step
            holeTo.set(hole.centerX(), hole.centerY(), hole.centerX(), hole.centerY());
            radiusTo = 0f;
        } else {
            holeTo.set(newHole);
            radiusTo = newRadius;
        }
        runMove(420);

        card.animate().cancel();
        if (Motion.isReduced(getContext())) {
            card.setAlpha(1f);
        } else {
            card.setAlpha(0f);
            card.animate().alpha(1f).setStartDelay(120).setDuration(280).start();
        }
        invalidate();
    }

    private void collapse() {
        if (hole.width() < 1f) return;
        if (moveAnimator != null) moveAnimator.cancel();
        holeFrom.set(hole);
        radiusFrom = radius;
        holeTo.set(hole.centerX(), hole.centerY(), hole.centerX(), hole.centerY());
        radiusTo = 0f;
        runMove(240);
    }

    private void runMove(long duration) {
        if (Motion.isReduced(getContext())) {
            applyHole(1f);
            return;
        }
        moveAnimator = ValueAnimator.ofFloat(0f, 1f);
        moveAnimator.setDuration(duration);
        moveAnimator.setInterpolator(new DecelerateInterpolator(1.8f));
        moveAnimator.addUpdateListener(a -> applyHole((float) a.getAnimatedValue()));
        moveAnimator.start();
    }

    private void applyHole(float t) {
        hole.left = lerp(holeFrom.left, holeTo.left, t);
        hole.top = lerp(holeFrom.top, holeTo.top, t);
        hole.right = lerp(holeFrom.right, holeTo.right, t);
        hole.bottom = lerp(holeFrom.bottom, holeTo.bottom, t);
        radius = lerp(radiusFrom, radiusTo, t);
        invalidate();
    }

    public void dismiss(Runnable done) {
        stopPulse();
        animate().alpha(0f).setDuration(260).withEndAction(() -> {
            removeNow();
            if (done != null) done.run();
        }).start();
    }

    public void removeNow() {
        stopPulse();
        if (moveAnimator != null) moveAnimator.cancel();
        if (getParent() instanceof ViewGroup) ((ViewGroup) getParent()).removeView(this);
    }

    // ------------------------------------------------------------------ pulsing

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        startPulse();
    }

    @Override
    protected void onDetachedFromWindow() {
        stopPulse();
        if (moveAnimator != null) moveAnimator.cancel();
        super.onDetachedFromWindow();
    }

    private void startPulse() {
        if (pulseAnimator != null) return;
        if (Motion.isReduced(getContext())) {
            pulse = 1f;
            return;
        }
        pulseAnimator = ValueAnimator.ofFloat(0f, 1f);
        pulseAnimator.setDuration(1100);
        pulseAnimator.setRepeatCount(ValueAnimator.INFINITE);
        pulseAnimator.setRepeatMode(ValueAnimator.REVERSE);
        pulseAnimator.setInterpolator(new AccelerateDecelerateInterpolator());
        pulseAnimator.addUpdateListener(a -> {
            pulse = (float) a.getAnimatedValue();
            invalidate();
        });
        pulseAnimator.start();
    }

    private void stopPulse() {
        if (pulseAnimator != null) {
            pulseAnimator.cancel();
            pulseAnimator = null;
        }
    }

    // ------------------------------------------------------------------ drawing

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        boolean hasHole = hole.width() > dp(2f);

        // the dim layer, with the spotlight cut out
        scrimPath.reset();
        scrimPath.setFillType(Path.FillType.EVEN_ODD);
        scrimPath.addRect(0f, 0f, w, h, Path.Direction.CW);
        if (hasHole) scrimPath.addRoundRect(hole, radius, radius, Path.Direction.CW);
        canvas.drawPath(scrimPath, scrimPaint);

        if (hasHole) {
            // a soft glow made of a few widening, fading outlines
            for (int i = 4; i >= 1; i--) {
                float grow = dp(2.6f * i);
                glowPaint.setStrokeWidth(dp(4f));
                glowPaint.setAlpha((int) (255 * (0.22f - 0.04f * i) * (0.55f + 0.45f * pulse)));
                canvas.drawRoundRect(hole.left - grow, hole.top - grow, hole.right + grow,
                        hole.bottom + grow, radius + grow, radius + grow, glowPaint);
            }
            ringPaint.setAlpha((int) (255 * (0.75f + 0.25f * pulse)));
            canvas.drawRoundRect(hole, radius, radius, ringPaint);
        }

        // the arrow, nodding gently toward the thing it points at
        float cardAlpha = card.getAlpha();
        if (arrowOn && cardAlpha > 0.02f) {
            float nod = dp(5f) * pulse;
            float tipY = arrowTipY - arrowDir * nod;
            float half = dp(12f);
            arrowPath.reset();
            arrowPath.moveTo(arrowX - half, arrowBaseY);
            arrowPath.lineTo(arrowX, tipY);
            arrowPath.lineTo(arrowX + half, arrowBaseY);
            arrowPath.close();
            arrowPaint.setAlpha((int) (255 * cardAlpha));
            canvas.drawPath(arrowPath, arrowPaint);
        }
    }

    // ------------------------------------------------------------------ helpers

    private float[] safeInsets() {
        WindowInsetsCompat wi = ViewCompat.getRootWindowInsets(this);
        if (wi != null) {
            Insets b = wi.getInsets(WindowInsetsCompat.Type.systemBars());
            return new float[]{b.top, b.bottom};
        }
        return new float[]{dp(28f), dp(48f)};
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    private int dpi(float v) {
        return (int) (dp(v) + 0.5f);
    }
}