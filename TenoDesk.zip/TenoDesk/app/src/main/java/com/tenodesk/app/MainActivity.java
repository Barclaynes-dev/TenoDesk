package com.tenodesk.app;


import androidx.core.view.WindowCompat;
import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

public class MainActivity extends AppCompatActivity {

    private ImageView[] tabs;
    private int current = -1;

    private final ActivityResultLauncher<String> notificationPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> { });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_main);

        // keep the screen out from under the status and navigation bars
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.mainRoot), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        tabs = new ImageView[]{
                findViewById(R.id.navHome),
                findViewById(R.id.navTenants),
                findViewById(R.id.navRooms),
                findViewById(R.id.navBills)};

        for (int i = 0; i < tabs.length; i++) {
            final int index = i;
            tabs[i].setOnClickListener((View v) -> select(index));
        }

        if (savedInstanceState == null) {
            select(0);
        } else {
            current = savedInstanceState.getInt("tab", 0);
            highlight();
        }

        askForNotifications();
    }

    /** Lets other screens switch tabs, for example "See all" on Home. */
    public void openTab(int index) {
        select(index);
    }

    private Fragment createFragment(int index) {
        if (index == 0) return new HomeFragment();
        if (index == 1) return new TenantsFragment();
        if (index == 2) return new RoomsFragment();
        return new BillsFragment();
    }

    private void select(int index) {
        if (index == current) return;
        current = index;
        getSupportFragmentManager().beginTransaction()
                .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
                .replace(R.id.fragmentContainer, createFragment(index))
                .commit();
        highlight();
    }

    private void highlight() {
        int active = getColor(R.color.td_accent);
        int idle = getColor(R.color.td_text_secondary);
        for (int i = 0; i < tabs.length; i++) {
            tabs[i].setColorFilter(i == current ? active : idle);
        }
    }

    /** Android 13 and above ask permission before an app may show notifications. We ask once, politely. */
    private void askForNotifications() {
        if (Build.VERSION.SDK_INT < 33) return;
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED) return;

        SharedPreferences prefs = getSharedPreferences("tenodesk_prefs", Context.MODE_PRIVATE);
        if (prefs.getBoolean("asked_notifications", false)) return;
        prefs.edit().putBoolean("asked_notifications", true).apply();

        new MaterialAlertDialogBuilder(this)
                .setTitle("Rent reminders")
                .setMessage("TenoDesk can remind you when a tenant's rent is almost due or overdue, "
                        + "and in the last week of each month. Allow notifications on the next screen.")
                .setNegativeButton("Not now", null)
                .setPositiveButton("Continue", (d, w) ->
                        notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS))
                .show();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("tab", current);
    }
}